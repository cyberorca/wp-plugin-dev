<?php
include_once WPDEPOSIT_PATH . '/models/abstract.php';
require_once ABSPATH . 'wp-admin/includes/upgrade.php';

class updatesModel extends wpdepositAbstractModel  {

    protected $_versions = '';
    const DEPOSIT_HISTORY_TABLE = 'deposit_history';
    const PAYMENT_OPTIONS_TABLE = 'payment_options';

    public function __construct() {
        parent::__construct();

        $this->_versions = array(
            '1.0', '1.1', '1.2', '1.3', '1.4', 
            '1.5', '1.6', '1.7', 
            '1.8', '1.8.7', '1.8.9',
	        '1.9', '1.9.1', '1.9.2', '1.9.3', '1.9.4', '1.9.7'
        );
        $this->_depositHistoryTable = $this->_wpdb->prefix . self::DEPOSIT_HISTORY_TABLE;
        $this->_depositPaymentOptionsTable = $this->_wpdb->prefix . self::PAYMENT_OPTIONS_TABLE;
    }

    public function firstInstall() {
        global $wp_roles, $wp_version;
		
        // Check for capability
        if (!current_user_can('activate_plugins')) {
            return;
        }

        if (!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_depositHistoryTable . "'")) {
                $sql = "CREATE TABLE " . $this->_depositHistoryTable . " (
              `id` int(11) NOT NULL AUTO_INCREMENT,
                  `userid` int(11) NOT NULL,
                  `unique_code` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
                  `amount` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
                  `status` int(1) NOT NULL,
                  PRIMARY KEY (`id`)
                );";
                dbDelta($sql);
        }

        if (!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_depositPaymentOptionsTable . "'")) {
                $sql = "CREATE TABLE " . $this->_depositPaymentOptionsTable . " (
              `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                  `price` int(11) DEFAULT NULL,
                  `points` int(11) DEFAULT NULL,
                  `bonus` int(11) DEFAULT NULL,
                  `default_convertion` tinyint(4) NOT NULL DEFAULT '0',
                  PRIMARY KEY (`id`)
                );";
                dbDelta($sql);
        }

        if (!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix.TransactionModel::TABLE_NAME . "'")) {
               $sql = "CREATE TABLE `".$this->_wpdb->prefix.TransactionModel::TABLE_NAME."` (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `user_id` int(11) unsigned DEFAULT NULL,
                `item_id` int(11) unsigned DEFAULT NULL,
                `amount` decimal(10,2) DEFAULT NULL,
                `addon` varchar(50) DEFAULT NULL,
                `message` varchar(225) DEFAULT NULL,
                `withdrawable` int(1) unsigned DEFAULT NULL,
                `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
                `status` varchar(100) DEFAULT NULL,
                PRIMARY KEY (`id`)
              ) DEFAULT CHARSET=utf8;";
            dbDelta($sql);
        }

        if (!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix.WithdrawalModel::TABLE_NAME . "'")) {
               $sql = "CREATE TABLE `".$this->_wpdb->prefix.WithdrawalModel::TABLE_NAME."` (
                `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
                `user_id` int(11) unsigned DEFAULT NULL,
                `amount` decimal(10,2) NOT NULL,
                `payment_gateway` varchar(50) NOT NULL DEFAULT '',
                `message` varchar(225) DEFAULT NULL,
                `status` varchar(50) DEFAULT NULL,
                `source` varchar(50) DEFAULT NULL,
                `created_ts` datetime NOT NULL,
                `processed_ts` datetime DEFAULT NULL,
                PRIMARY KEY (`id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
            dbDelta($sql);
        }

        //add default options
        add_option(WPDEPOSIT_NAME . '_plugin_version', WPDEPOSIT_VERSION);
        add_option(WPDEPOSIT_NAME . '_credit_type', 'money');
        add_option(WPDEPOSIT_NAME . '_points_name_single', 'point');
        add_option(WPDEPOSIT_NAME . '_points_name_plural', 'points');
        add_option(WPDEPOSIT_NAME . '_convertion_rate', 10);
        add_option(WPDEPOSIT_NAME . '_test_mode', 1);
        add_option(WPDEPOSIT_NAME . '_currency', '$');
        add_option(WPDEPOSIT_NAME . '_pdf_document_footer', 'You can put your disclaimer here or any other info you wish to provide in the generated pdf');
        add_option(WPDEPOSIT_NAME . '_confirm_deposit_message', 'You are being forwarded to the payment gateway.');
        add_option(WPDEPOSIT_NAME . '_custom_deposit_limit', 0);
        //#todo: add default mail templates
        add_option(WPDEPOSIT_NAME . '_success_mail_content', 'Dear {USERNAME}

You successfully deposited {AMOUNT} on your account, thank you for the deposit.

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_error_mail_content', 'Dear {USERNAME}

We are sorry to hear you cancelled the deposit transaction. If any problem occurred please Contact us.

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_user_donation_email_content', 'Dear {DONATION_RECEIVER}

{DONATER} just donated {DONATION} to your account.

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_admin_donation_email_content', 'Dear Admin

{DONATER} just donated {DONATION} to {DONATION_RECEIVER}.

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_REJECTED, 'Dear {USERNAME}

Withdrawal rejected ({AMOUNT})

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED, 'Dear {USERNAME}

Withdrawal success ({AMOUNT})

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_deposit_log', 0);
        add_option(WPDEPOSIT_NAME . '_withdrawals_setting', WithdrawalModel::SETTING_DISABLED, array());
    }

    public function updateDb($currentVersion, $pluginVersion) {

        $cIndexVersion = array_search($currentVersion, $this->_versions);
        $pIndexVersion = array_search($pluginVersion, $this->_versions);

        for($i = ($cIndexVersion+1) ; $i <= $pIndexVersion; $i++)
        {
            switch($this->_versions[$i])
            {
                case '1.2':
                    self::updateDbTo_1_2();
                break;
                case '1.3':
                    self::updateDbTo_1_3();
                break;
                case '1.7':
                    self::updateDbTo_1_7();
                break;
                case '1.8':
                    self::updateDbTo_1_8();
                break;
                case '1.8.7':
                    self::updateDbTo_1_8_7();
                break;
                case '1.8.9':
                    self::updateDbTo_1_8_9();
                break;
                case '1.9.0':
                    self::updateDbTo_1_9();
                break;
	            case '1.9.2':
                    break;
	            case '1.9.3':
		            self::updateDbTo_1_9_2();
		            break;
	            case '1.9.4':
		            self::updateDbTo_1_9_2();
		            break;
                case '1.9.7':
                    self::updateDbTo_1_9_7();
                    break;
            }
        }
        update_option(WPDEPOSIT_NAME . '_plugin_version', WPDEPOSIT_VERSION);
    }

    public function updateDbTo_1_2() {
        $sql = "ALTER TABLE `".$this->_wpdb->prefix."_deposit_history` ADD `status` INT(1) NOT NULL AFTER `amount`";
        $this->_wpdb->query($sql);
    }

    public function updateDbTo_1_3() {
        $sql = "ALTER TABLE `".$this->_wpdb->prefix."_deposit_history` ADD `entrance_id` VARCHAR(150) NOT NULL AFTER `unique_code`";
        $this->_wpdb->query($sql);
    }
    
    public function updateDbTo_1_7() {
        $sql = "ALTER TABLE `".$this->_wpdb->prefix."_payment_options` CHANGE `price` `price` VARCHAR( 8 ) NULL DEFAULT NULL";
        $this->_wpdb->query($sql);
        $sql = "ALTER TABLE `".$this->_wpdb->prefix."_payment_options` CHANGE `points` `points` VARCHAR( 8 ) NULL DEFAULT NULL ";
        $this->_wpdb->query($sql);
        add_option(WPDEPOSIT_NAME . '_credit_type', 'money');
        add_option(WPDEPOSIT_NAME . '_convertion_rate', 10);
        //$this->_convertCreditsToPoints();
    }
    
    public function updateDbTo_1_8() {
        $sql = "CREATE TABLE `".$this->_wpdb->prefix."_wpd_transactions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `item_id` int(11) unsigned DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `addon` varchar(50) DEFAULT NULL,
  `message` varchar(225) DEFAULT NULL,
  `withdrawable` int(1) unsigned DEFAULT NULL,
  `created_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) DEFAULT CHARSET=utf8;";
        dbDelta($sql);
        add_option(WPDEPOSIT_NAME . '_custom_deposit_limit', 0);
        add_option(WPDEPOSIT_NAME . '_points_name_single', 'point');
        add_option(WPDEPOSIT_NAME . '_points_name_plural', 'points');
    }

    public function updateDbTo_1_8_7(){
        add_option(WPDEPOSIT_NAME . '_deposit_log', 0);
    }
    
    public function updateDbTo_1_8_9(){
        add_option(WPDEPOSIT_NAME . '_user_donation_email_content', 'Dear {DONATION_RECEIVER}

{DONATER} just donated {DONATION} to your account.

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_admin_donation_email_content', 'Dear Admin

{DONATER} just donated {DONATION} to {DONATION_RECEIVER}.

Yours sincerely
{SITENAME}
{SITEURL}');
    }
    
    public function updateDbTo_1_9() {
        //remove convertation rate
        delete_option(WPDEPOSIT_NAME . '_convertion_rate');
        
        //add withdraw table
        $sql = "CREATE TABLE `".$this->_wpdb->prefix.WithdrawalModel::TABLE_NAME."` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_gateway` varchar(50) NOT NULL DEFAULT '',
  `message` varchar(225) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_ts` datetime NOT NULL,
  `processed_ts` datetime DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        dbDelta($sql);
        add_option(WPDEPOSIT_NAME . '_withdrawals_setting', WithdrawalModel::SETTING_DISABLED, array());
        add_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_REJECTED, 'Dear {USERNAME}

Withdrawal rejected ({AMOUNT})

Yours sincerely
{SITENAME}
{SITEURL}');
        add_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED, 'Dear {USERNAME}

Withdrawal success ({AMOUNT})

Yours sincerely
{SITENAME}
{SITEURL}');
    }

    public function updateDbTo_1_9_2() {
        $sql = "ALTER TABLE `" . $this->_wpdb->prefix . "payment_options` ADD `bonus` INT NOT NULL AFTER `points`;";
        $this->_wpdb->query($sql);
    }

    public function updateDbTo_1_9_7() {
        $sql = "ALTER TABLE `" . $this->_wpdb->prefix . "payment_options` ADD `default_convertion` TINYINT NOT NULL DEFAULT '0' AFTER `bonus`;";
        $this->_wpdb->query($sql);
    }
}
