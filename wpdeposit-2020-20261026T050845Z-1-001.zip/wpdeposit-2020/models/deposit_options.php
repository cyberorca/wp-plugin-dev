<?php

include_once WPDEPOSIT_PATH . '/models/abstract.php';
include_once WPDEPOSIT_PATH . '/models/user.php';

class DepositOptionsModel extends wpdepositAbstractModel {
    const TABLE_NAME = 'deposit_history';
    const USER_TABLE_NAME = 'users';

    public function __construct() {
        parent::__construct();
        
        $this->_table = $this->_wpdb->prefix . self::TABLE_NAME;
        $this->_userTable = $this->_wpdb->base_prefix . self::USER_TABLE_NAME;
    }

	public function getAllDeposits()
	{
		return $this->_wpdb->get_row("SELECT * FROM " . $this->_table );
	}


	public function getTotalDepositAmount()
	{
		return $this->_wpdb->get_row("SELECT sum(amount) as total_amount FROM " . $this->_table );
	}

	public function getTotalCount()
	{
		return $this->_wpdb->get_row("SELECT count(id) as total FROM " . $this->_table);
	}

    public function getAll($limit = 1)
    {
        return $this->_wpdb->get_row("SELECT id FROM " . $this->_table . " LIMIT " . $limit );
    }

    /**
     * undocumented function
     *
     * @return void
     * @author Christophe Debruel
     * */
    public function getPaymentDetailsByUniqueId($uniqueId) {
        return $this->_wpdb->get_row("SELECT * FROM " . $this->_table . " WHERE unique_code = '" . $uniqueId . "'");
    }

    public function getDepositHistory() {
        return $this->_wpdb->get_results("SELECT " . $this->_table . ".*, " . $this->_userTable . ".user_nicename 
            FROM " . $this->_table . "
            INNER JOIN " . $this->_userTable . " ON (" . $this->_table . ".userid = " . $this->_userTable . ".ID)");
    }

    public function getDepositHistoryByUsername($username) {
        $username = wp_kses($username, array());
        return $this->_wpdb->get_results("SELECT " . $this->_table . ".*, " . $this->_userTable . ".user_nicename 
            FROM " . $this->_table . "
            INNER JOIN " . $this->_userTable . " ON (" . $this->_table . ".userid = " . $this->_userTable . ".ID)
            WHERE " . $this->_userTable . ".user_nicename LIKE '%" . $username . "%' 
            ");
    }

    public function getDepositHistoryByUniqueCode($uniqueCode) {
        $uniqueCode = wp_kses($uniqueCode, array());
        return $this->_wpdb->get_results("SELECT " . $this->_table . ".*, " . $this->_userTable . ".user_nicename 
            FROM " . $this->_table . "
            INNER JOIN " . $this->_userTable . " ON (" . $this->_table . ".userid = " . $this->_userTable . ".ID)
            WHERE " . $this->_table . ".unique_code LIKE '%" . $uniqueCode . "%' 
            ");
    }

    /**
     * undocumented function
     *
     * */
    public function getPaymentHistoryByUserId($userId) {
        return $this->_wpdb->get_results("SELECT * FROM " . $this->_table . " WHERE userid = '" . $userId . "'");
    }

    public function updateUserDeposits($params, $convert) {
        if (isset($params['status']) && $params['status'] == 1) {
            $userModel = new UserModel();   
            if($userModel->incrementBalance($params['amount'], $params['userid'], $convert)) {
                $this->_logger->log('[DEPOSIT] incrementing balance');
            } else {
                $this->_logger->log('[DEPOSIT] problem incrementing balance', 'error');
            }
            
        }
        $result = $this->_wpdb->insert($this->_table, array(
            'userid' => $params['userid'],
            'unique_code' => $params['txn_id'],
            'amount' => $params['amount'],
            'status' => isset($params['status']) ? $params['status'] : 1,
            ));
        if (!$result) {
            $this->_logger->log('[DEPOSIT] Could not insert into deposit history', 'error');
            return false;
        } else {
            $this->_logger->log('[DEPOSIT] Insert into deposit history');
        }
        return true;
    }

    public function completePayment($params)
    {
            $userModel = new UserModel();
            if (!$params['amount']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - Deposit amount not set');
            }
            if (!$params['userid']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - User id not set');
            }
            if (!$params['unique_code']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - Unique transaction code not set');
            }
            if ($this->_wpdb->update($this->_table, array('status' => 1), array('userid' => $params['userid']))) {
                    $userModel->incrementBalance($params['amount']);
                    return true;
            } else {
                    return false;
            }
    }

    public function cancelPayment($params)
    {
            $userModel = new UserModel();
            if (!$params['unique_code']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - Unique transaction code not set');
            }
            if ($this->_wpdb->query('DELETE FROM ' . $this->_table . ' WHERE unique_code="' . $params['unique_code'] . '"')) {
                    return true;
            } else {
                    return false;
            }
    }

    public function markDepositCompleted($params)
    {
            $userModel = new UserModel($params['userid']);
            if (!$params['amount']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - Deposit amount not set');
            }
            if (!$params['userid']) {
                    throw new exception(__CLASS__ . '::' . __FUNCTION__ . ' - User id not set');
            }
            $userModel->incrementBalance($params['amount']);
            $this->_logger->log(sprintf('[DEPOSIT] incrementing balance: %s for userid %s', $params['amount'].WPD_CURRENCY, $params['userid']));

            return $this->_wpdb->query('UPDATE ' . $this->_table . ' SET status = 1 WHERE unique_code="' . $params['unique_code'] . '"');
    }

    public function markDepositSuspend()
    {
            $unique_code = wp_kses($_POST['unique_code'], array());
            return $this->_wpdb->query('UPDATE ' . $this->_table . ' SET status = 0 WHERE unique_code="' . $unique_code . '"');
    }
}
