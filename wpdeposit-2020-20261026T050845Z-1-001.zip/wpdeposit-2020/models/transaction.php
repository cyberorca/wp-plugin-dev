<?php

require_once WPDEPOSIT_PATH .'/models/abstract.php';

class TransactionModel extends wpdepositAbstractModel {
    
    protected $_id = null;
    
    const TABLE_NAME = 'wpd_transactions';
    
    
    public function __construct($id = null) {
        parent::__construct();
        $this->_table =  $this->_wpdb->prefix.self::TABLE_NAME;
    }
    
    /**
     * @param int $userId
     * @param decimal $amount
     * @param string $addon
     * @param string $message
     */
    public function logTransaction($userId, $itemId, $amount, $addon, $message)
    {
        do_action('wpds_log_transaction_before');
        $result = $this->_wpdb->insert($this->_table, array(
            'user_id'   => $userId,
            'item_id'   => $itemId,
            'amount'    => $amount,
            'addon'     => $addon,
            'message'   => $message,
        ));
        do_action('wpds_log_transaction_after', $result);
        return $result;
    }
    
    /**
     */
    public function getForUser($userId)
    {
        return $this->_wpdb->get_results($this->_wpdb->prepare(
        "SELECT * FROM ".$this->_table." WHERE user_id = %d",
        $userId
        ));
    }
    
    /**
     */
    public function getAll()
    {
        return $this->_wpdb->get_results("SELECT t.*, u.user_nicename as buyer_username, u.id as buyer_id 
        FROM ".$this->_table." as t 
        LEFT JOIN ".$this->_wpdb->base_prefix."users as u ON u.id = t.user_id 
        ORDER BY t.created_ts DESC");
    }
    
    /**
     */
    public function getAllByUsers($filter)
    {
        return $this->_wpdb->get_results("SELECT t.*, u.user_nicename as buyer_username, u.id as buyer_id 
        FROM ".$this->_table." as t 
        LEFT JOIN ".$this->_wpdb->base_prefix."users as u ON u.id = t.user_id 
        WHERE u.user_nicename LIKE '%" . $filter . "%' 
        ORDER BY t.created_ts DESC
        ");
    }
    
    /**
     */
    public function getAllByType($filter)
    {
        return $this->_wpdb->get_results("SELECT t.*, u.user_nicename as buyer_username, u.id as buyer_id 
        FROM ".$this->_table." as t 
        LEFT JOIN ".$this->_wpdb->base_prefix."users as u ON u.id = t.user_id 
        WHERE t.addon LIKE '%" . $filter . "%' 
        ORDER BY t.created_ts DESC
        ");
    }
    
}