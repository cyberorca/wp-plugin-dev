<?php

require_once WPDEPOSIT_PATH .'/models/abstract.php';

class RewardsModel extends wpdepositAbstractModel {
    
    
    public function __construct($id = null) {
        parent::__construct();
        
    }
    
    public function updateRewards()
    {
        do_action('wpds_update_reward_amounts');
        if (isset($_POST['form']) && is_array($_POST['form'])) {
            $rewardValues = array();
            foreach($_POST['form'] as $usValue){
                if (!preg_match('/point_type/', $usValue['name'])) {
                    $rewardValues[$usValue['name']]['value'] = $usValue['value'];
                } else {
                    $rewardValues[str_replace('_point_type', '', $usValue['name'])]['type'] = $usValue['value'];
                }
            }
            unset($rewardValues['sbm_rewards']);
            $serializedForm = serialize($rewardValues);
            update_option('wpds_reward_values', $serializedForm);
        }
        
    }
    
    public function addReward()
    {
        do_action('wpds_add_extra_rewards');
        if (isset($_POST['form']) && is_array($_POST['form'])) {
            $newActionHook = array();
            $rewardList = $this->getExtraRewardValues(); //get list to before adding new reward
            if (empty($rewardList)) {
                $rewardList['actions'] = array();
            }
            foreach($_POST['form'] as $usValue){
                if ($usValue['name'] != 'sbm_add_extra_rewards') {
                    $newActionHook[$usValue['name']] = $usValue['value'];
                }
            }
            $rewardList['actions'][] = $newActionHook;
            $serializedForm = serialize($rewardList);
            update_option('wpds_extra_rewards', $serializedForm);
            return $newActionHook;
        }
        
    }
    
    public function getExtraRewardValues($raw = false)
    {
        do_action('wpds_get_extra_rewards');
        $values = get_option('wpds_extra_rewards');
        if (empty($values)) {
            return false;
        }
        /**
         * Either return the list as stored in the optione (serialized) or unserialize first and return array
         */
        if ($raw) {
            return $values;
        } else {
            /**
             * clean up array first to make it easier to use it's values
             */
            $usValues = unserialize($values);
            return $usValues;
        }
    }
    
    public function getRewardValues($raw = false)
    {
        do_action('wpds_get_reward_amounts');
        $values = get_option('wpds_reward_values');
        if (empty($values)) {
            return false;
        }
        /**
         * Either return the list as stored in the optione (serialized) or unserialize first and return array
         */
        if ($raw) {
            return $values;
        } else {
            /**
             * clean up array first to make it easier to use it's values
             */
            $usValues = unserialize($values);
            return $usValues;
        }
    }

	public function getByHookName($hook) {
        $extraRewards = $this->getExtraRewardValues();
        foreach($extraRewards['actions'] as $hookReward){
            if($hookReward['action_hook'] == $hook){
                return $hookReward;
            }
        }
	}

	public function editExtraReward($data) {
        $extraRewards = $this->getExtraRewardValues();
        foreach($extraRewards['actions'] as $key => $hookReward){
            if($hookReward['action_hook'] == $data['original_hook']){
                $extraRewards['actions'][$key] = array(
                    'action_hook' => $data['action_hook'],
                    'action_hook_point_type' => $data['action_hook_point_type'],
                    'action_hook_value' => $data['action_hook_value'],
                );
            }
        }
        $extraRewards = serialize($extraRewards);
        update_option('wpds_extra_rewards', $extraRewards);
        return true;
	}

    public function deleteExtraReward($hook)
    {
        $extraRewards = $this->getExtraRewardValues();
        //loop over existing rewards
        foreach($extraRewards['actions'] as $key => $hookReward){
            //add all hooks except the one to delete in the new list
            if($hookReward['action_hook'] == $hook){
                unset($extraRewards['actions'][$key]);
            }
        }
        //save new list
        $extraRewards = serialize($extraRewards);
        update_option('wpds_extra_rewards', $extraRewards);
        return true;
    }
}