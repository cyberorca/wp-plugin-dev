<?php

class wpdepositAbstractModel {
    
    CONST STATUS_ACTIVE         = 1;
    CONST STATUS_DELETED        = 2;
    CONST STATUS_NOT_PUBLISHED  = 3;
    
    /**
     *
     * @var wpdb 
     */
    protected $_wpdb;
    
    /**
     * current logged in wordpress user
     */
    protected $_user;
    
    protected $_wpelements;

    /**
     * @var WpdepositActionLogger
     */
    public $_logger;

    public function __construct() {
        require (ABSPATH . WPINC . '/pluggable.php');
        global $wpdb, $current_user;
	    wp_get_current_user();
        $this->_user = $current_user;
        $this->_wpdb = $wpdb;
        $this->_wpelements = new WP_elements();
        $this->_logger = new WpdepositActionLogger(WPDEPOSIT_PATH . '/deposit_log.txt');
    }
    
    protected function getValueFromArray($k, $a) {
        return isset($a[$k]) ? $a[$k] : null;
    }
    
    
}