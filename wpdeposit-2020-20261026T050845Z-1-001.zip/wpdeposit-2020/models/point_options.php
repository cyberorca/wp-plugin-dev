<?php
/* @todo still need this class? */
include_once WPDEPOSIT_PATH . '/models/abstract.php';
include_once WPDEPOSIT_PATH . '/models/updates.php';

class PointOptionsModel extends wpdepositAbstractModel {
    
    public function __construct() {
        parent::__construct();
    }
    
    public function updateSettings() {
        if(!isset($_POST['credit_type']) || empty($_POST['credit_type'])){
            throw new Exception(__('Money type cannot be empty!', WPDEPOSIT_NAME));
        }
        $credit_type = wp_kses($_POST['credit_type'], array());
        update_option(WPDEPOSIT_NAME . '_credit_type', wp_kses($_POST['credit_type'], array()));
        update_option(WPDEPOSIT_NAME . '_new_points_conversion', 1);
        return true;
    }

}