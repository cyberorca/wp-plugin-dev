<?php
include_once WPDEPOSIT_PATH . '/models/abstract.php';

class SettingsOptionsModel extends wpdepositAbstractModel {
    
    
    public function __construct() {
        parent::__construct();
    }

    public function updateGatewaySettings() {
        foreach($_POST as $key => $value)
        {
            if ($key != 'action') {//action is also passed as a post value but we don't need to save it
                if ($key == 'active_gateways' && is_array($value) && !empty($value)) {
                    foreach($value as $activeGateway){
                        update_option(WPDEPOSIT_NAME . '_gateway_' . $activeGateway, 'checked');
                    }
                } elseif ($key == 'unactive_gateways' && is_array($value) && !empty($value)) {
                    foreach($value as $unActiveGateway){
                        update_option(WPDEPOSIT_NAME . '_gateway_' . $unActiveGateway, 'unchecked');
                    }
                } else {
                    update_option(WPDEPOSIT_NAME . '_' . $key, wp_kses($value, array()));
                }
            }
        }
        return true;
    }

    public function updateTestOptionsSettings()
    {
        update_option(WPDEPOSIT_NAME . '_test_mode', wp_kses($_POST['test_mode'], array()));
    }

    public function updateSettings()
    {
        update_option(WPDEPOSIT_NAME . '_points_name_single', wp_kses($_POST['points_name_single'], array()));
        update_option(WPDEPOSIT_NAME . '_points_name_plural', wp_kses($_POST['points_name_plural'], array()));
        update_option(WPDEPOSIT_NAME . '_currency', wp_kses($_POST['currency'], array()));
        update_option(WPDEPOSIT_NAME . '_currency_position', wp_kses($_POST['currency_position'], array()));
        update_option(WPDEPOSIT_NAME . '_custom_currency_code', wp_kses($_POST['custom_currency_code'], array()));
        update_option(WPDEPOSIT_NAME . '_custom_currency', wp_kses($_POST['custom_currency'], array()));
        update_option(WPDEPOSIT_NAME . '_company_name', wp_kses($_POST['company_name'], array()));
        update_option(WPDEPOSIT_NAME . '_company_address', wp_kses($_POST['company_address'], array()));
        update_option(WPDEPOSIT_NAME . '_company_number', wp_kses($_POST['company_number'], array()));
        update_option(WPDEPOSIT_NAME . '_company_phone_number', wp_kses($_POST['company_phone_number'], array()));
        update_option(WPDEPOSIT_NAME . '_pdf_document_footer', wp_kses($_POST['pdf_document_footer'], array()));
        update_option(WPDEPOSIT_NAME . '_success_page', wp_kses($_POST['deposit_success_page'], array()));
        update_option(WPDEPOSIT_NAME . '_cancel_page', wp_kses($_POST['deposit_cancel_page'], array()));
        update_option(WPDEPOSIT_NAME . '_failure_page', wp_kses($_POST['deposit_failure_page'], array()));
        update_option(WPDEPOSIT_NAME . '_expired_page', wp_kses($_POST['deposit_expired_page'], array()));
        update_option(WPDEPOSIT_NAME . '_open_page', wp_kses($_POST['deposit_open_page'], array()));
        update_option(WPDEPOSIT_NAME . '_confirm_deposit_message', wp_kses($_POST['deposit_confirm_message'], array()));
        update_option(WPDEPOSIT_NAME . '_custom_deposit_limit', wp_kses($_POST['custom_deposit_limit'], array()));
        update_option(WPDEPOSIT_NAME . '_disable_styles', wp_kses($_POST['disable_styles'], array()));
        update_option(WPDEPOSIT_NAME . '_deposit_log', wp_kses($_POST['deposit_log'], array()));
        update_option(WPDEPOSIT_NAME . '_withdrawals_setting', wp_kses($_POST['withdrawals'], array()));
        return true;
    }
    
    public function settingAddImage()
    {
        return self::updateGatewaySettings();
    }

    public function updateMailtemplateSettings()
    {
        update_option(WPDEPOSIT_NAME . '_success_mail_content', wp_kses($_POST['success_mail_template'], array()));
        update_option(WPDEPOSIT_NAME . '_error_mail_content', wp_kses($_POST['error_mail_template'], array()));
        update_option(WPDEPOSIT_NAME . '_user_donation_content_enable', wp_kses($_POST['user_donation_content_enable'], array()));
        update_option(WPDEPOSIT_NAME . '_user_donation_email_content', wp_kses($_POST['user_donation_email_content'], array()));
        update_option(WPDEPOSIT_NAME . '_admin_donation_content_enable', wp_kses($_POST['admin_donation_content_enable'], array()));
        update_option(WPDEPOSIT_NAME . '_admin_donation_email_content', wp_kses($_POST['admin_donation_email_content'], array()));
        update_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_REJECTED, wp_kses($_POST['withdrawal_reject_email_content'], array()));
        update_option(WPDEPOSIT_NAME . '_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED, wp_kses($_POST['withdrawal_finished_email_content'], array()));
        return true;
    }
    
    public function getTemplateContent($templateName)
    {
        return get_option(WPDEPOSIT_NAME . $templateName);
    }

    public function savePointFields()
    {
        if($_POST['type'] == 'show') {
            $pointFields = 'on';
        } else {
            $pointFields = 'off';
        }
        update_option(WPDEPOSIT_NAME . '_show_point_fields', wp_kses($pointFields, array()));
    }
    
}//end of class