<?php
include_once WPDEPOSIT_PATH . '/models/abstract.php';

class PaymentOptionsModel extends wpdepositAbstractModel {
    
    const TABLE_NAME = 'payment_options';
    
    public function __construct() {
        parent::__construct();
        $this->_table =  $this->_wpdb->prefix.self::TABLE_NAME;
    }
    
    /**
     * Insert a payment option
     * 
     * @param array $data
     * @return boolean $success 
     */
    public function add($data) {
        if (WPD_CREDIT_TYPE == 'points') {
            $bindParams = array('%s', '%s', '%s', '%s');
        } else {
            $bindParams = array('%s', '%s', '%s');
        }
	    if($data['default_convertion'] == 1){
		    //reset all default convertion settings
		    $this->_wpdb->update($this->_table,
			    array(
				    'default_convertion' => 0
			    ),
			    array(
				    'default_convertion' => 1
			    ));
	    }
        return (bool) $this->_wpdb->insert($this->_table, $data, $bindParams);
    }
    
    /**
     * Edit a payment option
     * 
     * @param int $id
     * @param array $data
     * @return boolean $success 
     */
    public function edit($id, $data) {
        if (WPD_CREDIT_TYPE == 'points') {
            $bindParams = array('%s', '%s', '%s', '%s');
        } else {
            $bindParams = array('%s', '%s', '%s');
        }
	    if($data['default_convertion'] == 1){
		    //reset all default convertion settings
		    $this->_wpdb->update($this->_table,
			    array(
				    'default_convertion' => 0
			    ),
			    array(
				    'default_convertion' => 1
			    ));
	    }
        return (bool) $this->_wpdb->update($this->_table, $data, array('id' => (int) $id), $bindParams, array('%d'));
    }
    
    /**
     * Delete a payment option
     * 
     * @param int $id
     * @return boolean $success 
     */
    public function delete($id) {
        return (bool) $this->_wpdb->query("DELETE FROM ".$this->_table." WHERE id = '".(int) $id."'");
    }
    
    /**
     * Get all payment options
     * 
     * @return array $results 
     */
    public function getOverview() {
        return $this->_wpdb->get_results("SELECT id, price, points, bonus, default_convertion FROM ".$this->_table." ORDER BY price ASC");
    }
    
    /**
     * Get a payment option by id
     * 
     * @param int $id
     * @return array $results 
     */
    public function getForId($id) {
        return $this->_wpdb->get_row("SELECT id, price, points, bonus, default_convertion FROM ".$this->_table." WHERE id = '".$id."'", ARRAY_A);
    }

	/**
     * Get a payment option by amount
     *
     * @param int $id
     * @return array $results
     */
    public function getByAmount($amount) {
        return $this->_wpdb->get_row("SELECT id, price, points, bonus, default_convertion FROM ".$this->_table." WHERE price = '".$amount."'", ARRAY_A);
    }

	/**
     * Get a payment option by points
     *
     * @param int $id
     * @return array $results
     */
    public function getByPoints($points) {
        return $this->_wpdb->get_row("SELECT id, price, points, bonus, default_convertion FROM ".$this->_table." WHERE points = '".$points."'", ARRAY_A);
    }

	/**
	 * Get default payment option
	 *
	 * @param int $id
	 * @return array $results
	 */
	public function getDefault() {
		return $this->_wpdb->get_row("SELECT id, price, points, bonus, default_convertion FROM ".$this->_table." WHERE default_convertion = 1", ARRAY_A);
	}
}