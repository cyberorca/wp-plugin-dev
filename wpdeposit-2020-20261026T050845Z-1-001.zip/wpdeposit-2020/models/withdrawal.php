<?php

require_once WPDEPOSIT_PATH .'/models/abstract.php';

class WithdrawalModel extends wpdepositAbstractModel {
    
    protected $_id = null;
    
    const TABLE_NAME = 'wpd_withdrawals';

    const STATUS_WAITING = 'waiting';
    const STATUS_CANCELED = 'canceled';
    const STATUS_REJECTED = 'rejected';
    const STATUS_PROCESSED = 'processed';

    const SETTING_DISABLED = 'disabled';
    const SETTING_EVERYTHING = 'everything';
    const SETTING_EARNINGS_ONLY = 'earnings_only';
    const SETTING_DEPOSITS_ONLY = 'deposits_only';

    public function __construct($id = null) {
        parent::__construct();
        $this->_table =  $this->_wpdb->prefix.self::TABLE_NAME;

        $this->_id = $id;
    }

    public function getForId($id) {
        return $this->_wpdb->get_row(
            $this->_wpdb->prepare("SELECT * FROM ".$this->_table." WHERE id = %d", $id)
        );
    }

    /**
     * @param int $userId
     * @param decimal $amount
     * @param string $paymentGateway
     * @param string $status
     * @param string $message
     */
    public function addWithdrawal($userId, $amount, $paymentGateway, $status, $source, $message = '')
    {
        $now = new \DateTime();
        do_action('wpds_add_withdrawal_before');
        $result = $this->_wpdb->insert($this->_table, array(
            'user_id'               => $userId,
            'amount'                => $amount,
            'payment_gateway'       => $paymentGateway,
            'message'               => $message,
            'status'                => $status,
            'source'                => $source,
            'created_ts'            => $now->format('c'),
        ));
        do_action('wpds_add_withdrawal_after', $result);
        return $result;
    }

    public function cancelWithdrawal($withdrawalId, $userId)
    {
        return $this->updateWithdrawalStatus($withdrawalId, $userId, self::STATUS_CANCELED);
    }

    public function updateWithdrawalStatus($withdrawalId, $userId, $status)
    {
        $result = $this->_wpdb->update(
            $this->_table,
            array(
                'status' => $status,
            ),
            array (
                'id' => $withdrawalId,
                'user_id' => $userId,
            )
        );
        return $result;
    }
    
    /**
     */
    public function getForUser($userId)
    {
        return $this->_wpdb->get_results(
            $this->_wpdb->prepare(
                "SELECT * FROM ".$this->_table." WHERE user_id = %d ORDER BY created_ts DESC",
                 $userId
            )
        );
    }
    
    /**
     */
    public function getAll()
    {
        return $this->_wpdb->get_results(
            "SELECT t.*, u.user_nicename as buyer_username, u.id as buyer_id
            FROM ".$this->_table." as t
            LEFT JOIN ".$this->_wpdb->base_prefix."users as u ON u.id = t.user_id
            ORDER BY t.created_ts DESC"
        );
    }
    
    /**
     */
    public function getAllByUsers($filter)
    {
        return $this->_wpdb->get_results(
            "SELECT t.*, u.user_nicename as buyer_username, u.id as buyer_id
            FROM ".$this->_table." as t
            LEFT JOIN ".$this->_wpdb->base_prefix."users as u ON u.id = t.user_id
            WHERE u.user_nicename LIKE '%" . $filter . "%'
            ORDER BY t.created_ts DESC
            "
        );
    }
    
}