<?php

require_once WPDEPOSIT_PATH .'/models/abstract.php';

class UserModel extends wpdepositAbstractModel {

    protected $_id = null;

    const TABLE_NAME = 'users';
    const USER_AMOUNT = '_user_amount';
    const USER_POINTS = '_user_points';
    const REWARDS_AMOUNT = '_rewards_amount';


    public function __construct($id = null) {
        parent::__construct();
        if ($id == null) {
            $this->_id = self::getCurrentUser()->ID;
        } else {
            $this->_id = $id;
        }
        $this->_table =  $this->_wpdb->base_prefix.self::TABLE_NAME;
    }

    /*=================================================================
                            GET FUNCTIONS
    =================================================================*/

    public static function getCurrentUser() {
        global $current_user;
	    wp_get_current_user();
        return $current_user;
    }

    public function getId()
    {
        return $this->_id;
    }


    /**
    * @todo Move to own controller? 
    */
    public function donateToUser($id, $amount, $toUser){
        $userModel = new UserModel();
        $user = $userModel->getCurrentUser();
        $transactionModel = new TransactionModel();
        $this->incrementBalance($amount, $id);
        $transactionModel->logTransaction($userModel->getId(), 0, $amount*-1, 'donation', 'Donated ' . $amount . ' to <strong>' . $toUser->display_name  . '</strong>');

        //send email to user
        if (WPDEPOSIT_ENABLE_USER_ENABLE) {
            $message = WPDEPOSIT_USER_DONATION_MAIL;
            $message = str_replace('{DONATION_RECEIVER}', $toUser->display_name, $message);
            $message = str_replace('{DONATER}', $user->display_name, $message);
            $message = str_replace('{DONATION}', $amount, $message);
            $message = str_replace('{SITENAME}', get_bloginfo('blog_name'), $message);
            $message = str_replace('{SITEURL}', get_bloginfo('url'), $message);
            wp_mail( $toUser->user_email, __('You have received a donation', WPDEPOSIT_NAME), $message );
        }

        //send mail to admin. if specified in settings
        if (WPDEPOSIT_ENABLE_ADMIN_ENABLE) {
            $message = WPDEPOSIT_ADMIN_DONATION_MAIL;
            $message = str_replace('{DONATION_RECEIVER}', $toUser->display_name, $message);
            $message = str_replace('{DONATER}', $user->display_name, $message);
            $message = str_replace('{DONATION}', $amount, $message);
            $message = str_replace('{SITENAME}', get_bloginfo('blog_name'), $message);
            $message = str_replace('{SITEURL}', get_bloginfo('url'), $message);
            wp_mail( get_bloginfo('admin_email'), __('A user donated on your website', WPDEPOSIT_NAME), $message );
        }
        return true;
    }

    /**
     * This function returns either the amount of points or the total amount of credits. This is the main function
     * that needs to be called to display the actual balance of a user
     * @param int $id
     * @param type $type
     * @return float
     */
    public function getBalance($id = null, $type = false, $balanceType = null) {
        if ($id == null) {
            $id = $this->_id;
        }
        if (WPD_CREDIT_TYPE == 'points') {
            //return the amount of points a user has
            $totalBalance = $this->getPointsBalance($id);
        } else {
            //return the regular balance and the awarded balance together
            if ($balanceType == null) {
                $totalBalance = $this->getRegularBalance($id, $type) + $this->getRewardBalance();
            } else {
                if ($balanceType == 'wpdeposit_user_amount') {
                    $totalBalance = $this->getRegularBalance($id, $type);
                } else {
                    $totalBalance = $this->getRewardBalance();
                }
            }
        }
        return $totalBalance;
    }

    

/*=================================================================
                        POINTS FUNCTIONS
=================================================================*/

    /**
     * Get the points balance of the current logged in user
     * @return string $balance
     */
    public function getPointsBalance($id) {
        $balance = get_user_meta($id, WPDEPOSIT_NAME.self::USER_POINTS, true);
        if (empty($balance)) {
            $balance = 0;
        }
        return round($balance, 2);
    }

    /**
     * Update points to given amount (Will overwrite whatever value is in the db!)
     *
     * @param int $points
     * @return boolean
     */
    public function updatePointsBalance($points, $affordCheck = false) {
	    if($affordCheck && !$this->canAfford($points)){
		    return false;
	    }
	    return (bool) update_user_meta($this->_id, WPDEPOSIT_NAME.self::USER_POINTS, $points);
    }

    /**
     * Regular balance
     *
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    public function decrementPointsBalance($amount, $id = null) {
        return $this->decrementBalanceForType(WPDEPOSIT_NAME.self::USER_POINTS, $amount, $id);
    }

    public function incrementPointsBalance($amount, $id = null) {
        return $this->incrementBalanceForType(WPDEPOSIT_NAME.self::USER_POINTS, $amount, $id);
    }

/*=================================================================
                        BALANCE FUNCTIONS
=================================================================*/

    /**
     * Get the regular balance of the current logged in user (does not include the rewarded balance)
     * @return string $balance
     */
    public function getRegularBalance($id = null, $type = false) {
        if ($id == null) {
            $id = $this->_id;
        }
        $balance = get_user_meta($id, WPDEPOSIT_NAME.self::USER_AMOUNT, true);
        if (empty($balance)) {
            $balance = 0;
        }
        return round($balance, 2);
    }

    /**
     * Get the reward balance of the current logged in user (does not include the regular balance)
     * @return string $balance
     */
    public function getRewardBalance() {
        $balance = get_user_meta($this->_id, WPDEPOSIT_NAME.self::REWARDS_AMOUNT, true);
        if (empty($balance)) {
            $balance = 0;
        }
        return round($balance, 2);
    }

    /**
     * Update Regular balance to given amount (Will overwrite whatever value is in the db!)
     *
     * @param int $amount
     * @return boolean
     */
    public function updateRegularBalance($amount) {
        if (floatval($amount)) {
            return (bool) update_user_meta($this->_id, WPDEPOSIT_NAME.self::USER_AMOUNT, $amount);
        } else {
            throw new \Exception(__('Amount is not a number', WPDEPOSIT_NAME));
        }
    }

    /**
     * Update Reward balance to given amount (Will overwrite whatever value is in the db!)
     *
     * @param int $amount
     * @return boolean
     */
    public function updateRewardBalance($amount) {
        if (floatval($amount)) {
            return (bool) update_user_meta($this->_id, WPDEPOSIT_NAME.self::REWARDS_AMOUNT, $amount);
        } else {
            throw new \Exception(__('Amount is not a number', WPDEPOSIT_NAME));
        }

    }

    /**
     * Increment the balance of the user
     *
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    public function incrementBalance($amount, $id = null, $convert = false) {
        if (WPD_CREDIT_TYPE == 'points') {
	        /*
	         * if true, convert credit to points
	         */
            if($convert){
				$paymentModel = new PaymentOptionsModel();
	            $paymentOption = $paymentModel->getByAmount($amount);

	            /*
	             * if amount does not match an existing payment option
	             */
	            if(empty($paymentOption)){
		            /*
		             * Get default payment option to convert credits to points
		             */
		            $paymentOption = $paymentModel->getDefault();
		            /*
		             * Check if a default payment options was set
		             */
		            if(empty($paymentOption)){
			            $this->_logger->log('[ERROR] No default payment option was created. Cannot convert with unkown information. Update payment options settings');
		                return false;
		            }
		            /*
		             * Check if default payment options has a specified amount of points. otherwise can't convert
		             */
		            if(empty($paymentOption['points'])){
			            $this->_logger->log('[ERROR] The default payment option has no points defined. Could not calculate the points to donate for ' . $amount . ' credits');
			            return false;
		            }
		            $points = ($paymentOption['points'] / $paymentOption['price']) * $amount;
	            } else {
		            $points = $paymentOption['points'];
	            }
            }
            return $this->incrementPointsBalance($points, $id);
        } else {
            return $this->incrementRegularBalance($amount, $id);
        }

    }

    /**
     * Reward balance
     *
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    public function incrementRewardBalance($amount, $id = null) {
        return $this->incrementBalanceForType(WPDEPOSIT_NAME.self::REWARDS_AMOUNT, $amount, $id);
    }

    public function incrementRegularBalance($amount, $id = null) {
        /*
         * check if payment option has a bonus
         */
        $payment = new PaymentOptionsController();
        $paymentOptions = $payment->getPaymentOptionByAmount($amount);
        if($paymentOptions && !empty($paymentOptions['bonus'])){
            $amount += $paymentOptions['bonus'];
        }
        /*
         * increment balance
         */
        return $this->incrementBalanceForType(WPDEPOSIT_NAME.self::USER_AMOUNT, $amount, $id);
    }

    public function decrementBalance($amount, $id = null)
    {
        if ($this->canAfford((int) $amount) === false) {
            throw new \Exception(__('Not enough on this balance', WPDEPOSIT_NAME));
        }

        if (WPD_CREDIT_TYPE == 'points') {
            return $this->decrementPointsBalance($amount);
        }

        $regularBalance = $this->getRegularBalance();

        if ($regularBalance >= $amount) {
            return $this->decrementRegularBalance($amount);
        }

        // Not enough balance on regular balance, so take everything from it
        // and take the rest from the reward balance
        $this->decrementRegularBalance($regularBalance);

        $amountFromRewardBalance = $amount - $regularBalance;

        return $this->decrementRewardBalance($amountFromRewardBalance);
    }

    /**
     * Regular balance
     *
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    public function decrementRegularBalance($amount, $id = null) {
        return $this->decrementBalanceForType(WPDEPOSIT_NAME.self::USER_AMOUNT, $amount, $id);
    }

    /**
     * Regular balance
     *
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    public function decrementRewardBalance($amount, $id = null) {
        return $this->decrementBalanceForType(WPDEPOSIT_NAME.self::REWARDS_AMOUNT, $amount, $id);
    }

/*=================================================================
                        HELPER FUNCTIONS
=================================================================*/

    public function getCanWithdrawAmount()
    {
        if (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_EVERYTHING) {
            $canWithdrawalAmount = $this->getBalance();
        } elseif (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_DEPOSITS_ONLY) {
            $canWithdrawalAmount = $this->getRegularBalance();
        } elseif (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_EARNINGS_ONLY) {
            $canWithdrawalAmount = $this->getRewardBalance();
        } else {
            $canWithdrawalAmount = 0;
        }

        return $canWithdrawalAmount;
    }

    public function canAfford($amount) {
        if (!floatval($amount)) {
            throw new \Exception(__('Not a number', WPDEPOSIT_NAME));
        }

        if ($this->getBalance() >= $amount) {
            return true;
        }

        return false;
    }

    public function canWithdraw($amount) {
        if (!floatval($amount)) {
            throw new \Exception(__('Not a number', WPDEPOSIT_NAME));
        }

        if ($this->getCanWithdrawAmount() >= $amount) {
            return true;
        }

        return false;
    }

    /**
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    private function decrementBalanceForType($balanceType, $amount, $id = null) {
        if ($id == null) {
            $id = $this->_id;
        }
        $currentBalance = $this->getBalance($id, false, $balanceType);

        //$amount = floatval($amount);
        if (!floatval($amount)) {
            throw new \Exception(__('Tried to decrement balance with amount that is not a number', WPDEPOSIT_NAME));
        }

        if ($amount < 0) {
            throw new \Exception(__('Increment amount can not be negative', WPDEPOSIT_NAME));
        }

        if ($currentBalance < $amount) {
            throw new \Exception('Not enough balance to decrement '.$amount);
        }

        $this->_logger->log(sprintf('[DEBUG] Decrement "%s" with amount "%s" for user with id "%s". Balance was "%s".', $balanceType, $amount, $id, $currentBalance));
        $updatedAmount = $currentBalance - $amount;
	    update_user_meta($id, $balanceType, $updatedAmount);
        return true;
    }


    /**
     * @param decimal $amount
     * @param int $id
     * @return boolean
     * @throws Exception
     */
    private function incrementBalanceForType($balanceType, $amount, $id = null) {
        if ($id == null) {
            $id = $this->_id;
        }
        $currentBalance = $this->getBalance($id, false, $balanceType);

        $amount = floatval($amount);
        if (!floatval($amount)) {
            $this->_logger->log('Tried to increment balance with amount that is not a number', 'error');
            throw new \Exception(__('Tried to increment balance with amount that is not a number '.$amount, WPDEPOSIT_NAME));
        }

        if ($amount < 0) {
            throw new \Exception(__('Increment amount can not be negative', WPDEPOSIT_NAME));
        }

        $updateCreditsResult = update_user_meta($id, $balanceType, $currentBalance + $amount);
        if (!$updateCreditsResult){
            $this->_logger->log('Could not update user meta (user id: ' . $id . ')', 'error');
        }
        return true;
    }

    
}
