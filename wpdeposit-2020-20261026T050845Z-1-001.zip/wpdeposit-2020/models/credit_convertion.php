<?php

require_once WPDEPOSIT_PATH .'/models/abstract.php';

class CreditConvertionModel extends wpdepositAbstractModel {
    
    
    public function __construct($id = null) {
        parent::__construct();
        
    }
    
    
    
}