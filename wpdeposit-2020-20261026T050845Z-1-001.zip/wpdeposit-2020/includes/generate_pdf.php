<?php
require_once('../../../../wp-blog-header.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/classes/fpdf.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/controllers/deposit_options.php');

class PDF extends FPDF
{
	public function openTable($header, $w)
	{
		//colors, etc,...
		$this->SetFillColor(108,108,108);
		$this->SetTextColor(255);
		$this->SetDrawColor(0, 0, 0);
		$this->SetLineWidth(.3);
		$this->SetFont('','B');
		//header tables
		for($i=0;$i<count($header);$i++)
			$this->Cell($w[$i],7,$header[$i],1,0,'C',1);
		$this->ln();
		//let's restore the colors
		$this->SetFillColor(224,235,255);
		$this->SetTextColor(0);
		$this->SetFont('');
		
	}
	
	public function addDepositDetailRow($row, $w)
	{
		$fill=0;
		$this->Cell($w[0], 6, $row->unique_code, 1, 0, 'L', $fill);
		$this->Cell($w[1], 6, $row->amount, 1, 0, 'L', $fill);
		$this->Ln();
		$fill=!$fill;
	}
	
	public function addDepositDetailRows($rows, $w)
	{
		$fill=0;
		foreach ($rows as $row) {
			$this->Cell($w[0], 6, $row->unique_code, 'LRB', 0, 'LB', $fill);
			$this->Cell($w[1], 6, $row->amount, 'LRB', 0, 'LB', $fill);
			$this->Ln();
		}
		$fill=!$fill;
	}
	
	public function closeTable()
	{
		
	}
}
$deposit = new DepositOptionsController();
if (isset($_GET['uid']) && !empty($_GET['uid'])) {
	$uid = wp_kses($_GET['uid'], array());
	$rows = $deposit->getDepositDetail($uid);
	$history = false;
} else {
	$rows = $deposit->getDepositHistory();
	$history = true;
}

	$companyName = get_option(WPDEPOSIT_NAME . '_company_name');
	$companyAddress = get_option(WPDEPOSIT_NAME . '_company_address');
	$companyNumber = get_option(WPDEPOSIT_NAME . '_company_number');
	$documentFooter = get_option(WPDEPOSIT_NAME . '_pdf_document_footer');
	global $current_user;
	wp_get_current_user();
	$user_name = $current_user->user_login;
	$pdf= new PDF('P', 'mm', 'A4');
	$header = array('Uraian','Jumlah');
	$table_width = array(150,30,50);
	$pdf->AddPage();
	$pdf->SetFont('Arial', '', 8);
	$pdf->Cell(40, 10, $companyName);
	$pdf->Ln(3);
	$pdf->Cell(40, 10, $companyAddress);
	$pdf->Ln(3);
	$pdf->Cell(40, 10, $companyNumber);
	$pdf->Ln(20);
	$pdf->SetFont('Arial', 'B', 14);
	$pdf->Cell(40, 10, ''.$user_name. '-transfer ke BNI 0537233638 an SMITA CATUR S');
	$pdf->Ln(20);
	$pdf->SetFont('Arial', 'B', 12);
	$pdf->Ln(10);
	$pdf->openTable($header, $table_width);
	if ($history) {
		$pdf->addDepositDetailRows($rows, $table_width);
	} else {
		$pdf->addDepositDetailRow($rows, $table_width);
	}
	$pdf->Ln(10);
	$pdf->SetFont('Arial', '', 10);
	$pdf->Cell(40,40, $documentFooter);
	$pdf->Output('deposit_history_' . time() . '.pdf', 'I');
?>