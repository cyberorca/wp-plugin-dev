<?php
require_once('../../../../wp-blog-header.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/controllers/deposit_options.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME .'/models/user.php');

global $current_user;
wp_get_current_user();
get_header();
if (!is_user_logged_in()) {
    echo '<div id="main">
        <div id="primary">
            <div role="main" id="content">
            <h1 class="entry-title">' . __('Access Denied', WPDEPOSIT_NAME) . '</h2>
            <p>' . __('You need to be ', WPDEPOSIT_NAME) . '<a href="' . home_url() . '/wp-login.php">' . __('logged in', WPDEPOSIT_NAME) . '</a>' . __('to access this page.', WPDEPOSIT_NAME) . '</p>
            </div>
        </div>
    </div>
    ';
} else { 

	$user_name = $current_user->user_login;
	$deposit = new DepositOptionsController();
	
	$docInfo = array(
		'company_name'			=>		get_option(WPDEPOSIT_NAME . '_company_name'),
		'company_address'		=>		get_option(WPDEPOSIT_NAME . '_company_address'),
		'company_number'		=>		get_option(WPDEPOSIT_NAME . '_company_number'),
		'document_footer'		=>		get_option(WPDEPOSIT_NAME . '_pdf_document_footer'),
		'bank_iban'			=>		get_option(WPDEPOSIT_NAME . '_bank_iban'),
	); 

	if (isset($_GET['tid']) && !empty($_GET['tid'])) {
		$tid = wp_kses($_GET['tid'], array());
		$rows = $deposit->getDepositDetail($tid);
		$controller = new UserController;
		$balancedInfo = $controller->getBalanceInfo();
		$dateNow = date('F j, Y');
	} else {
		_e("We could not generate the pdf invoice. If you keep getting this message, contact the site administrator", WPDEPOSIT_NAME);
		exit;
	}
	
?>    
    <style>
	
    .invoice-box{
        max-width:800px;
        margin:auto;
        padding:30px;
        border:1px solid #eee;
        box-shadow:0 0 10px rgba(0, 0, 0, .15);
        font-size:16px;
        line-height:24px;
        font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color:#555;
    }
    
    .invoice-box table{
        width:100% !important;
        line-height:inherit !important;
        text-align:left !important;
    }
    
    .invoice-box table td{
        padding:5px !important;
        vertical-align:top !important;
    }
    
    .invoice-box table tr td:nth-child(2){
        text-align:right !important;
    }
    
    .invoice-box table tr.top table td{
        padding-bottom:20px !important;
    }
    
    .invoice-box table tr.top table td.title{
        font-size:45px !important;
        line-height:45px !important;
        color:#333 !important;
    }
    
    .invoice-box table tr.information table td{
        padding-bottom:40px !important;
    }
    
    .invoice-box table tr.heading td{
        background:#eee !important;
        border-bottom:1px solid #ddd !important;
        font-weight:bold !important;
    }
    
    .invoice-box table tr.details td{
        padding-bottom:20px !important;
    }
    
    .invoice-box table tr.item td{
        border-bottom:1px solid #eee !important;
    }
    
    .invoice-box table tr.item.last td{
        border-bottom:none !important;
    }
    
    .invoice-box table tr.total td:nth-child(2){
        border-top:2px solid #eee !important;
        font-weight:bold !important;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td{
            width:100% !important;
            display:block !important;
            text-align:center !important;
        }
        
        .invoice-box table tr.information table td{
            width:100% !important;
            display:block !important;
            text-align:center !important;
        }
    }
    </style>

    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                <!--img src="http://nextstepwebs.com/images/logo.png" style="width:100%; max-width:300px;"-->
								<?php echo $docInfo['company_name'];?>
                            </td>
                            
                            <td>
                                Invoice #: <?php echo $rows->unique_code;?><br>
                                Created: <?php echo $dateNow;?><br>
                                Due: -
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                                <?php echo $docInfo['company_name'];?><br>
                                <?php echo $docInfo['company_address'];?><br>
                                <?php echo $docInfo['company_number'];?>
                            </td>
                            
                            <td>
                                <br>
                                CEO<br>
                               
                                <?php bloginfo('userid');?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Cara Pembayaran
                </td>
                
                <td>
                    Transfer Bank
                </td>
            </tr>
            
            <tr class="details">
                <td>
                    Transfer ke BNI 0537233638 a.n SMITA CATUR S
                </td>
                
                <td>
                    Rp. <?php echo $rows->amount;?>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Item
                </td>
                
                <td>
                    Jumlah
                </td>
            </tr>
            
            <tr class="item last">
                <td>
                    Deposit
                </td>
                
                <td>
                    Rp. <?php echo $rows->amount;?>
                </td>
            </tr>
            
            
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: Rp. <?php echo $rows->amount;?><br/>
				   saldo saat ini: Rp. <?php echo $balancedInfo;?>
                </td>
            </tr>
			<tr>
				<td></td>
				<td>
				<?php echo $docInfo['document_footer'];?>
				</td>
			</tr>
        </table>
    </div>
    <?php 
	}
	get_footer();
	?>
	
	
