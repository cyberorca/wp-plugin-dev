<?php

//function multiple_upload($name = 'userfile', $upload_dir = 'sources/images/', $allowed_types = 'gif|jpg|jpeg|jpe|png', $size)
//{
//    $CI =& get_instance();
//
//    $config['upload_path']   = realpath($upload_dir);
//    $config['allowed_types'] = $allowed_types;
//    $config['max_size']      = $size;
//    $config['overwrite']     = FALSE;
//    $config['encrypt_name']  = FALSE;
//
//
//    $CI->upload->initialize($config);
//    $errors = FALSE;
//
//    if(!$CI->upload->do_upload($name)):
//            $errors = TRUE;
//    else:
//            // Build a file array from all uploaded files
//            $files = $CI->upload->data();
//    endif;
//
//
//    // There was errors, we have to delete the uploaded files
//    if($errors):                   
//            @unlink($files['full_path']);
//            return false;
//    else:
//            return $files;
//    endif;
//
//}




////modified version of jeffrey way's zip extract tutorial
//function upload_batch_images($name = 'userfile', $upload_dir = 'sources/images/', $allowed_types = 'gif|jpg|jpeg|jpe|png', $size) 
//{
//	$CI =& get_instance();
//        $realpath = $upload_dir."images-".rand(1111111111,9999999999);
//        $config['upload_path']   = $realpath;
//        $config['allowed_types'] = $allowed_types;
//        $config['max_size']      = $size;
//        $config['overwrite']     = FALSE;
//        $config['encrypt_name']  = TRUE;
//		
//	$CI->upload->initialize($config);
//	
//	if(mkdir($realpath)):
//            if($CI->upload->do_upload($name)):
//                $files = $CI->upload->data();	
//                if(openZip($realpath."/".$files['file_name'], $realpath)):
//                    @unlink($files['full_path']);
//                    return $realpath;
//                else:
//                    @unlink($files['full_path']);
//                    return false;
//                endif;
//            endif;
//	else:
//            return false;
//	endif;
//
//}



//function d_external_img($src) 
//{
//	$error = false;
//	
//	//create unique id, with time() it will always be unique because time is unique
//	$t = time();
//	$r = rand(000,999);
//	$filename = $t."-tutimage-".$r;
//	
//	//get image information
//	list($width, $height, $type, $attr) = getimagesize($src);
//	switch($type):
//            case 1:
//                $e = ".gif";
//            break;
//            case 2:
//                $e = ".jpg";
//            break;
//            case 3:
//                $e = ".png";
//            break;
//            default:
//                $error = true;
//            break;
//	endswitch;
//	
//	//download the file
//	if($error == false):
//            $path = 'sources/tutorials/'.$filename.$e;
//            if($ch = curl_init($src)):
//                $fp = fopen($path, 'wb');
//                curl_setopt($ch, CURLOPT_FILE, $fp);
//                curl_setopt($ch, CURLOPT_HEADER, 0);
//                curl_exec($ch);
//                curl_close($ch);
//                fclose($fp);
//            else:
//                return false;
//            endif;
//            return $filename.$e;
//	else:
//            return false;
//	endif;
//
//}


function openZip($file_to_open, $zip_target) 
{
	$zip = new ZipArchive();
	$x = $zip->open($file_to_open);
	if ($x === true):
            $zip->extractTo($zip_target);
            $zip->close();
            return true;
	else:
            return false;
	endif;
}


function delete_directory($dirname) 
{
   if (is_dir($dirname))
      $dir_handle = opendir($dirname);
   if (!$dir_handle)
      return false;
   while($file = readdir($dir_handle)) {
      if ($file != "." && $file != "..") {
         if (!is_dir($dirname."/".$file))
            unlink($dirname."/".$file);
         else
            delete_directory($dirname.'/'.$file);    
      }
   }
   closedir($dir_handle);
   rmdir($dirname);
   return true;
}

function get_files($item_folder)
{
    if (is_dir($item_folder))
    {
        $handle = opendir($item_folder);
        $i=0;
        $images = array();
        while (false !== ($file = readdir($handle))):
            if ($file != "." && $file != ".." && $file != ".DS_Store" && $file != ".svn"):
                $images[] = $file;
            endif;
            $i++;
        endwhile;
        closedir($handle);
        return $images;
    } else {
        return 'no files in this folder';
    }
}


function get_image_thumb_showcase($item_folder, $title)
{
    if (is_dir($item_folder))
    {
        $handle = opendir($item_folder);
        $i=0;
        while (false !== ($file = readdir($handle))):
            //i smaller then 3 on localhost but smaller then 1 on live server (for some reason...)
            if ($file != "." && $file != ".." && $i<3):
                $img_preview = base_url().$item_folder.$file;
                ?>
                <a href="<?php echo $img_preview;?>">
                    <img class="item_preview" src="<?php echo $img_preview; ?>" alt="<?php echo $title; ?>"  title="<?php echo $title; ?>" />
                </a>
                <?php
            endif;
            $i++;
        endwhile;
        closedir($handle);
    }
}
