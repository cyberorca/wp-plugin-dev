<?php
require_once('../../../../wp-blog-header.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/controllers/gateways/ideal_options.php');

$deposit = new WPD_Ideal_Gateway();
$result = $deposit->processPayment();

if ($result == 'success') {
	$page = get_page( get_option(WPDEPOSIT_NAME . '_success_page') );
} elseif ($result == 'cancel') {
	$page = get_page( get_option(WPDEPOSIT_NAME . '_cancel_page') );
} elseif ($result == 'failure') {
	$page = get_page( get_option(WPDEPOSIT_NAME . '_failure_page') );
} elseif ($result == 'expired') {
	$page = get_page( get_option(WPDEPOSIT_NAME . '_expired_page') );
} elseif ($result == 'open') {
	$page = get_page( get_option(WPDEPOSIT_NAME . '_open_page') );
}
$url = get_bloginfo('url') . '/?page_id=' . $page->ID; //if permalinks is on it will redirect to the pretty url automatically
header('Location: ' . $url);