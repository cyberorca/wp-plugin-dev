<?php
$pluginPath = str_replace('includes', '', realpath(dirname(__FILE__)));
$wp_url = str_replace('wp-content/plugins/wpdeposit/includes', "", dirname(__FILE__));
include_once($wp_url . 'wp-load.php');

if (!empty($_FILES)) {
    $tempFile = $_FILES['Filedata']['tmp_name'];
    $targetPath = $_POST['fileFolder'];
    $targetFile =  $targetPath . $_FILES['Filedata']['name'];
    $fileTypes  = str_replace('*.','',$_POST['fileext']);
    $fileTypes  = str_replace(';',',',$fileTypes);
    $typesArray = explode(',',$fileTypes);
    $fileParts  = pathinfo($_FILES['Filedata']['name']);
    
    if (!in_array($fileParts['extension'], $typesArray)) {
        echo json_encode(array('success' => false, 'message' => 'Invalid file type'));
        exit;
    }
    $imageFolderName = time() . '-' . $fileParts['filename'];
    $imageFolderTarget = $targetPath . $imageFolderName;

        if (move_uploaded_file($tempFile, $targetFile)) {
            if (mkdir($imageFolderTarget, 0755, true)) {
                if (openZip($targetFile, $imageFolderTarget)) {
                    echo json_encode(array('success' => true, 'message' => 'file uploaded successfully', 'file_data' => $fileParts, 'image_folder' => $imageFolderName));
                } else {
                    echo json_encode(array('success' => false, 'message' => 'Could not extract'));
                }
                @unlink($targetFile);
            } else {
                
            }
        } else {
            echo json_encode(array('success' => false, 'message' => 'We could not upload the file.', 'file_data' => $fileParts));
        }

} else {
    echo json_encode(array('success' => false, 'message' => 'no files returned'));
}
exit;