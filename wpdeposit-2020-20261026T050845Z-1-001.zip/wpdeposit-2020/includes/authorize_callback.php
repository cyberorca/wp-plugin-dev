<?php
require_once('../../../../wp-blog-header.php');
require_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/controllers/gateways/authorize_options.php');

$obj = new WPD_Authorize_Gateway();
$obj->processPayment();

include_once(ABSPATH. 'wp-content/plugins/' . WPDEPOSIT_NAME . '/views/deposit/authorize_feedback.php');