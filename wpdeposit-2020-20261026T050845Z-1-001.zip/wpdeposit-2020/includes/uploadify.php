<?php
if (!empty($_FILES)) {
    $tempFile = $_FILES['Filedata']['tmp_name'];
    $targetPath = $_POST['fileFolder'];
    $targetFile =  $targetPath . $_FILES['Filedata']['name'];
    $fileTypes  = str_replace('*.','',$_POST['fileext']);
    $fileTypes  = str_replace(';',',',$fileTypes);
    $typesArray = explode(',',$fileTypes);
    $fileParts  = pathinfo($_FILES['Filedata']['name']);
    if (in_array($fileParts['extension'], $typesArray)) {
        if (move_uploaded_file($tempFile, $targetFile)) {
            echo json_encode(array('success' => true, 'message' => 'file uploaded successfully', 'file_data' => $fileParts));
        } else {
            echo json_encode(array('success' => false, 'message' => 'We could not upload the file.', 'file_data' => $fileParts));
        }
    } else {
        echo json_encode(array('success' => false, 'message' => 'Invalid file type'));
    }
} else {
    echo json_encode(array('success' => false, 'message' => 'no files returned'));
}
exit;