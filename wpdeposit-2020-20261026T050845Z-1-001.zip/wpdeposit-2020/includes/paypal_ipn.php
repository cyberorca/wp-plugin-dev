<?php
$wp_url = str_replace('wp-content/plugins/wpdeposit/includes', "", dirname(__FILE__));
include_once($wp_url . 'wp-load.php');
require_once(ABSPATH. 'wp-content/plugins/wpdeposit/controllers/gateways/paypal_options.php');
$obj = new WPD_Paypal_Gateway();
$obj->processPayment();