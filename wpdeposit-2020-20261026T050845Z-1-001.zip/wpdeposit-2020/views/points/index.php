<div class="feedback"></div><!-- .feedback -->
<?php echo $this->_wpelements->openForm('', 'POST', false, 'wpdeposit_points_form'); ?>
    <table class="form-table credit_type_table_form">
        <?php
            $options = array(array('value' => 'money', 'option' => 'Money'), array('value' => 'points', 'option' => POINTS_NAME_PLURAL));
            echo $this->_wpelements->select_field($options, WPDEPOSIT_NAME . '_credit_type', __('type', WPDEPOSIT_NAME), array(
                'default' => get_option(WPDEPOSIT_NAME . '_credit_type')
            ));
        ?>
    </table>
<p class="submit_block"><input type="submit" name="sbm_settings" value="<?php _e('Update Settings', WPDEPOSIT_NAME); ?>" id="sbm_settings" class="button-primary" />
</p>
<?php do_action('wpds_add_points_fields'); ?>
<?php echo $this->_wpelements->closeForm();  ?>
<script type="text/javascript" charset="utf-8">
    jQuery(document).ready(function($) {
        depositCount = <?php echo $depositsCount; ?>;
        <?php if(isset($paymentOptions) && !empty($paymentOptions)): ?>
            paymentOptions = <?php echo json_encode($paymentOptions); ?>;
        <?php else: ?>
            paymentOptions = null;
        <?php endif; ?>
        creditType = '<?php echo WPD_CREDIT_TYPE ?>';
    });
</script>