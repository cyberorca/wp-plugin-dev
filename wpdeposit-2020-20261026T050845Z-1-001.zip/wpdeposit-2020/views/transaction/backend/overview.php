<div class="feedback"><?php echo (isset($feedback) && !empty($feedback))? $feedback : '' ; ?></div>
<?php
if (is_user_logged_in()):
    if (count($transactions) == 0):
        echo '<p>' . __('You have no transactions', WPDEPOSIT_NAME) . '</p>';
    else:
        ?>
        <p>
        <?php $wpelements->filter_options(array(
            'select_list' => array('users' => 'Users', 'type' => 'Type')
        )); ?>
        </p>
        <table class="widefat deposit_list">
            <thead>
                <tr>
                    <th width="200" ><?php _e('Date', WPDEPOSIT_NAME); ?></th>
                    <th width="200" ><?php _e('User', WPDEPOSIT_NAME); ?></th>
                    <th width="200" ><?php _e('Type/add-on', WPDEPOSIT_NAME); ?></th>
                    <th width="100" ><?php _e('Amount', WPDEPOSIT_NAME); ?></th>
                    <th><?php _e('Message', WPDEPOSIT_NAME); ?></th>
                    <?php do_action('wpds_add_backend_transaction_list_column_title'); ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $transaction): ?>
                    <tr class="">
                        <td><?php echo $transaction->created_ts; ?></td>
                        <td><?php echo $transaction->buyer_username; ?></td>
                        <td><?php echo $transaction->addon; ?></td>
                        <td><strong><?php echo WPD_CURRENCY .' '. $transaction->amount; ?></strong></td>
                        <td><?php echo $transaction->message; ?></td>
                        <?php do_action('wpds_add_backend_transaction_list_column_content'); ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php 
else:
    echo '<a href="' . wp_login_url() . '" title="' . __('Login', WPDEPOSIT_NAME) . '">' . __('Please login to view your transactions', WPDEPOSIT_NAME) . '</a>';
endif;