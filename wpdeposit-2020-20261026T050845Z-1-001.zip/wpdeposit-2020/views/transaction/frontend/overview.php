
<link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<?php
$cookie_name = 'test';
if(isset($_COOKIE[$cookie_name])) {
    
   $data = [];
    foreach ($transactions as $transaction){
        //preg_match('/(http).*/', $transaction->message, $matches);
        //echo $transaction->amount . "<br/>";
        //echo $transaction->message . "<br/>";
        preg_match('/(ID\s+[0-9]+|ID[0-9]+)([a-zA-Z\- \.\,\-]+)([0-9\,\.]+)(APPROVE|TRANSAKSI\sSUKSES).*(http.*)/i',$transaction->message, $matchesIdName);
        //if(count($matches) > 0){
            if(count($matchesIdName) > 0){
                echo $transaction->message . "<br>";
                echo "<pre>";
                print_r($matchesIdName);
                echo "</pre>";
            }
        //}
     }
    //$dtTables = json_encode($data);
    /* 
?>

        <table id="transaction">
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Jumlah</th>
                    <th>Pesan</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
<script>
const $ = jQuery;
$(document).ready( function () {
    var data = <?php echo $dtTables; ?>
    
    $('#transaction').DataTable( {
        data: data
    });
    
} );

</script>

<?php*/

}

if (is_user_logged_in()):
    if (count($transactions) == 0):
        echo '<p>' . __('You have no transactions', WPDEPOSIT_NAME) . '</p>';
    else:
            $data = [];
            foreach ($transactions as $transaction){
                preg_match('/(ID\s+[0-9]+|ID[0-9]+)([a-zA-Z\- \.\,\-]+)([0-9\,\.]+)(APPROVE|TRANSAKSI\sSUKSES).*(http.*)/i', $transaction->message, $matches);
                if(count($matches) > 0){
                    $button =  '<button class="btn-struk" data-url="'.$matches[5].'">STRUK</button>';
                    $message = $matches[1] . " " . $matches[2] . " " . $matches[3];
                }else{
                    $button =  '-';
                    $message = $transaction->message;
                }
                
                $data[] = [
                            date("d-m-Y",strtotime($transaction->created_ts)),
                            "<b>".WPD_CURRENCY .' '. number_format($transaction->amount,2,',','.')."</b>",
                            $button,
                            $message
                          ];
             }
            $dtTables = json_encode($data);
        ?>
          <div class="border border-primary rounded mt-5 p-4">
            <table id="transaction" class="table table-striped table-hover dt-responsive nowrap">
            <thead>
                <tr>
                    <th style="width:20%;">Tanggal</th>
                    <th style="width:30%;">Jumlah</th>
                    <th style="width:100%;">Struk</th>
                    <th>Pesan</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        </div>
        <script>
            const $ = jQuery;
            $(document).ready( function () {
                var data = <?php echo $dtTables; ?>;
                var table = $('#transaction').DataTable( {
                    data: data,
                    autoWidth: false,
                    columnDefs: [
            			{ targets: [0], className:'text-center bg-warning' },
            			{ targets: [1, 2], className:'text-left bg-light' },
            		],
                });
                
                 $('#transaction tbody').on('click', 'button', function (e) {
                    window.location.href = $(this).data('url');
                 });
                
            } );
        </script>
    <?php endif; ?>
<?php 
else:
    echo '<a href="' . wp_login_url() . '" title="' . __('Login', WPDEPOSIT_NAME) . '">' . __('Please login to view your transactions', WPDEPOSIT_NAME) . '</a>';
endif;
?>
<script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></scrip>