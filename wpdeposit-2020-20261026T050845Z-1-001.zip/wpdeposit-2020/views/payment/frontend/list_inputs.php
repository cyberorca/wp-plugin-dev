<div class="feedback"></div><!-- .feedback -->
<div class="loadform"></div><!-- .loadform -->
<div class="dialog"></div><!-- .loadform -->
<div class="payment_result"></div>
<?php
$userController = new UserController();
$data = array();
$data['wpelements'] = $this->_wpelements;
$data['usercontroller'] = $userController;
$data['paymentoptions'] = $paymentOptions;
$data['paymentgatewaylist'] = $paymentGatewayList;
$this->_wpelements->loadView(array('path' => ABSPATH . 'wp-content/themes/' . get_template() . '/wpdeposit/deposit_form.php', 'original_path' => WPDEPOSIT_PATH . '/views/payment/frontend/deposit_form.php'), $data);
?>
