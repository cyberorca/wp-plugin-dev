<?php
$wpelements = $data['wpelements'];
$userController = $data['usercontroller'];
$paymentOptions = $data['paymentoptions'];
$paymentGatewayList = $data['paymentgatewaylist'];
?>
<div class="deposit_amount">
    <?php _e('Saldo Deposit:', WPDEPOSIT_NAME); ?> 
    <strong>
        <?php echo the_credit_type_text(true, null, true); ?>
    </strong>
</div>
<?php if(WPD_CREDIT_TYPE == 'money'): ?>
<h2><?php _e('nilai deposit', WPDEPOSIT_NAME); ?>:</h2>
<?php else: ?>
<h2><?php _e('jumlah deposit ' . POINTS_NAME_PLURAL . ' transfer', WPDEPOSIT_NAME); ?>:</h2>
<?php endif; ?>
<?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_deposit_money');
    if (count($paymentOptions) == 0):
        echo '<p>' . __('No options found', WPDEPOSIT_NAME) . '</p>';
    else:
	$i = 1;
	foreach ($paymentOptions as $paymentOption): ?>
            <?php $inpId = WPDEPOSIT_NAME . '_' . $paymentOption->price; ?>
            <p class="payment_option">
                <?php if(WPD_CREDIT_TYPE == 'money'): ?>
                    <input type="radio" name="deposit_amount" class="deposit_amount" <?php echo ($i == 1)? 'checked' : '' ; ?> value="<?php echo $paymentOption->price; ?>" />
                    <label for="<?php echo $inpId; ?>"><?php echo the_credit_type_text(true, $paymentOption->price, true); ?></label>
                <?php else: ?>
                    <?php $points = $paymentOption->points; ?>
                    <input type="radio" name="deposit_amount" class="deposit_amount" <?php echo ($i == 1)? 'checked' : '' ; ?> value="<?php echo $paymentOption->price; ?>" />
                    <label for="<?php echo $inpId; ?>"><?php echo $points . ' ' . POINTS_NAME_PLURAL; ?><small><?php echo __('For', WPDEPOSIT_NAME) . ' ' . WPD_CURRENCY . $paymentOption->price; ?> </small></label>
                <?php endif; ?>
            </p>
            <?php $i++; ?>
	<?php endforeach;?>
        <h2><?php _e('ATAU', WPDEPOSIT_NAME); ?></h2>
        <p><?php _e('tambahkan 3 digit kode dibelakang untuk otomatis', WPDEPOSIT_NAME); ?>
        </p>
        <p>
            <input type="text"id="deposit_custom_amount" name="deposit_custom_amount" class="deposit_custom_amount" value="" /> 
            <?php if(WPD_CREDIT_TYPE != 'money') : echo POINTS_NAME_PLURAL; endif; ?>
        </p>
        <h2><?php _e('Pilih Bank:', WPDEPOSIT_NAME); ?></h2>
        <div class="payment_gateways">
            <?php echo $paymentGatewayList; ?>
        </div>
        <p class="payment_block"><input type="submit" name="sbm_add_payment" value="<?php _e('TOPUP', WPDEPOSIT_NAME); ?>" id="sbm_add_payment">
        </p>
<?php endif; ?>
<?php echo $wpelements->closeForm();  ?>