<?php if(WPD_CREDIT_TYPE != 'points'): ?>
    <?php if(WPD_SHOW_POINT_FIELDS): ?>
        <a href="#" class="hide-point-fields"><?php _e('Hide point fields', WPDEPOSIT_NAME); ?></a>
    <?php else: ?>
        <a href="#" class="show-point-fields"><?php _e('Show point fields', WPDEPOSIT_NAME); ?></a>
    <?php endif; ?>
<?php endif ?>
<?php echo $this->_wpelements->openForm('', 'POST', false, 'wpdeposit_po_form'); ?>
    <p class="input_block">
        <label for="wpdeposit_price"><?php _e('Money amount', WPDEPOSIT_NAME); ?>:</label> 
        <input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_price', ''); ?>" id="wpdeposit_price" name="wpdeposit_price" />
    </p>
    <?php if(WPD_SHOW_POINT_FIELDS): ?>
        <p class="input_block">
            <label for="wpdeposit_points"><?php _e('Points', WPDEPOSIT_NAME); ?>:</label>
            <input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_points', ''); ?>" id="wpdeposit_points" name="wpdeposit_points" />
        </p>
    <?php endif; ?>
	<p class="input_block">
		<label for="wpdeposit_bonus"><?php _e('Bonus', WPDEPOSIT_NAME); ?>: <small>(optional)</small></label>
		<input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_bonus', 0); ?>" id="wpdeposit_bonus" name="wpdeposit_bonus" />
		<small class="help_block">Award bonus credits/points to users when depositing.</small>
	</p>
    <p class="input_block">
        <label for="wpdeposit_default_convertion"><?php _e('Default payment option', WPDEPOSIT_NAME); ?>:</label>
        <?php $defaultConvertionValue = $this->_wpelements->set_form_value('wpdeposit_default_convertion', 0); ?>
        <select id="wpdeposit_default_convertion" name="wpdeposit_default_convertion" >
            <option value="0" <?php echo ($defaultConvertionValue == '0')? 'selected' : '' ?>>No</option>
            <option value="1" <?php echo ($defaultConvertionValue == '1')? 'selected' : '' ?>>Yes</option>
        </select>
    </p>
    <input type="hidden" size="80" value="" id="wpdeposit_id" name="wpdeposit_id">
    <p class="input_block">
        <input type="submit" class="button-primary " size="80" value="<?php _e('Add', WPDEPOSIT_NAME); ?>" id="wpdeposit_po_submit" name="submit" />
    </p>
<?php echo $this->_wpelements->closeForm();  ?>
