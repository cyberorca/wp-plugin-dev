<div class="feedback"></div><!-- .feedback -->
<div class="wpdeposit_form_wrap" id="wpdeposit_po_form_wrap">
    <?php include_once 'form.php'; ?>
    <div id="wpdeposit_po_form_e_wrap" style="display: none;">
        <?php echo $this->_wpelements->openForm('', 'POST', false, 'wpdeposit_po_form_edit'); ?>
        <p class="input_block">
            <label for="wpdeposit_price_e"><?php _e('Money amount', WPDEPOSIT_NAME); ?>:</label> 
            <input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_price', ''); ?>" id="wpdeposit_price_e" name="wpdeposit_price_e" />
        </p>
        <?php if(WPD_SHOW_POINT_FIELDS): ?>
            <p class="input_block">
                <label for="wpdeposit_points_e"><?php _e('Points', WPDEPOSIT_NAME); ?>:</label> 
                <input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_points', ''); ?>" id="wpdeposit_points_e" name="wpdeposit_points_e" />
            </p>
        <?php endif; ?>
        <input type="hidden" size="80" value="" id="wpdeposit_id_e" name="wpdeposit_id_e">
	    <p class="input_block">
		    <label for="wpdeposit_bonus_e"><?php _e('Bonus', WPDEPOSIT_NAME); ?>: <small>(optional)</small></label>
		    <input class="required number" type="text" size="10" value="<?php echo $this->_wpelements->set_form_value('wpdeposit_bonus', 0); ?>" id="wpdeposit_bonus_e" name="wpdeposit_bonus_e" />
		    <small class="help_block"><?php _e('Award bonus credits/points to users when depositing.', WPDEPOSIT_NAME) ?></small>
	    </p>
        <p class="input_block">
            <label for="wpdeposit_default_convertion_e"><?php _e('Default payment option', WPDEPOSIT_NAME); ?>:</label>
            <?php $defaultConvertionValue = $this->_wpelements->set_form_value('wpdeposit_default_convertion', 0); ?>
            <select id="wpdeposit_default_convertion_e" name="wpdeposit_default_convertion_e" >
                <option value="0" <?php echo ($defaultConvertionValue == '0')? 'selected' : '' ?>>No</option>
                <option value="1" <?php echo ($defaultConvertionValue == '1')? 'selected' : '' ?>>Yes</option>
            </select>
        </p>
        <p class="input_block">
            <input type="submit" class="button-primary " size="80" value="<?php _e('Edit', WPDEPOSIT_NAME); ?>" id="wpdeposit_po_submit" name="submit">
            <button id="edit_payment_option_cancel" class="button-primary "><?php _e('Cancel', WPDEPOSIT_NAME); ?></button>
        </p>
        <?php echo $this->_wpelements->closeForm(); ?>
    </div>
</div>
<div class="wpdeposit_list_wrap" id="payment_options">
    <?php include_once 'list.php' ?>
</div>