<?php
$defaultOption = false;
if (count($paymentOptions) != 0){
    foreach ($paymentOptions as $paymentOption){
        if($paymentOption->default_convertion == '1'){
	        $defaultOption = true;
        }
    }
}
?>
<hr />
<h2><?php _e('Your payment options', WPDEPOSIT_NAME); ?></h2>
<?php
if (count($paymentOptions) == 0):
    echo '<p>' . __('No payment options added yet.', WPDEPOSIT_NAME) . '</p>';
else: ?>
    <?php if(!$defaultOption): ?>
        <div class="message error">
            <p><?php _e('You have no default payment option. This is needed for converting points.', WPDEPOSIT_NAME); ?></p>
        </div>
    <?php endif; ?>
    <table class="widefat">
        <thead>
            <tr>
                <th><?php _e('Price', WPDEPOSIT_NAME); ?></th>
                <?php if(WPD_SHOW_POINT_FIELDS): ?>
                    <th><?php _e('Points', WPDEPOSIT_NAME); ?></th>
                <?php endif; ?>
                <th><?php _e('Bonus', WPDEPOSIT_NAME); ?></th>
                <th><?php _e('Default', WPDEPOSIT_NAME); ?></th>
                <th><?php _e('Actions', WPDEPOSIT_NAME); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($paymentOptions as $paymentOption): ?>
                <tr>
                    <td><?php echo WPD_CURRENCY . $paymentOption->price; ?></td>
                    <?php if(WPD_SHOW_POINT_FIELDS): ?>
                        <td><?php echo $paymentOption->points; ?></td>
                    <?php endif; ?>
	                <td><?php echo $paymentOption->bonus; ?></td>
	                <td><?php echo ($paymentOption->default_convertion == '1')? 'Default' : '-'; ?></td>
                    <td class="action">
                        <a title="po-<?php echo $paymentOption->id; ?>" class="edit_payment_option" href="#"><?php _e('edit', WPDEPOSIT_NAME); ?></a> | 
                        <a title="po-<?php echo $paymentOption->id; ?>" class="delete_payment_option" href="#"><?php _e('delete', WPDEPOSIT_NAME); ?></a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
