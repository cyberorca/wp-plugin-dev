<h2><?php _e('Payment was processed successfully', WPDEPOSIT_NAME); ?></h2>
<p>
<?php _e('We received your payment and your account has been updated.', WPDEPOSIT_NAME);?>
<?php _e('You can now', WPDEPOSIT_NAME);?> 
<a href="<?php echo home_url(); ?>"><?php _e('go back', WPDEPOSIT_NAME); ?></a> <?php _e('to our site.', WPDEPOSIT_NAME); ?></p>