<?php
$content = '';
if (count($rows) == 0):
	$content .= '<p>You have no deposit history.</p>';
else:
	$content .= '<p>';
		$content .= '<a href="' . WPDEPOSIT_URL . '/includes/generate_pdf.php">';
			$content .= __('Save complete history as pdf', WPDEPOSIT_NAME);
		$content .= '</a>';
		$content .= '</p>';
	$content .= '<table class="widefat deposit_list">';
	$content .= '<thead>';
		$content .= '<tr>';
			$content .= '<th>'. __('Unique code', WPDEPOSIT_NAME) . '</th>';
			$content .= '<th>'. __('Amount', WPDEPOSIT_NAME) . '</th>';
			$content .= '<th>'. __('Status', WPDEPOSIT_NAME) . '</th>';
			do_action('wpds_add_deposit_history_colum_title');
			$content .= '<th>'. __('PDF', WPDEPOSIT_NAME) . '</th>';
		$content .= '</tr>';
		$content .= '</thead>';
		$content .= '<tbody>';
		foreach ($rows as $row):
			$content .= '<tr>';
				$content .= '<td>' . $row->unique_code . '</td>';
				$content .= '<td><strong>' . WPD_CURRENCY . $row->amount . '</strong></td>';
				$content .= '<td>';
					$content .= '<strong>';
						if ($row->status == 1):
							$content .= __('Completed', WPDEPOSIT_NAME);
						else:
							$content .= __('Pending confirmation', WPDEPOSIT_NAME);
						endif;
					$content .= '</strong>';
				$content .= '</td>';
				do_action('wpds_add_deposit_history_colum_content');
				$content .= '<td>';
					$content .= '<a href="' . WPDEPOSIT_URL . '/includes/generate_pdf.php?uid=' . $row->unique_code . '">';
						$content .= __('Generate PDF', WPDEPOSIT_NAME);
					$content .= '</a>';
				$content .= '</td>';
			$content .= '</tr>';
		endforeach;
		$content .= '</tbody>';
	$content .= '</table>';
endif;