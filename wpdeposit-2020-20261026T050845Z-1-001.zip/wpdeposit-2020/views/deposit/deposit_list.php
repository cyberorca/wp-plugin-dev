<div class="feedback"><?php echo (isset($feedback) && !empty($feedback))? $feedback : '' ; ?></div>
<?php
do_action('wpds_deposit_list_view_before');
if (!isset($rows) || count($rows) == 0):
    echo '<p>' . __('No deposits found', WPDEPOSIT_NAME) . '.</p>';
else: ?>
    <p>
    <?php $wpelements->filter_options(array(
        'select_list' => array('users' => 'Users', 'unique_code' => 'Unique code')
    )); ?>
    </p>
    <table class="widefat deposit_list">
        <thead>
            <tr>
                <th><?php _e('Username', WPDEPOSIT_NAME); ?></th>
                <th><?php _e('Unique code', WPDEPOSIT_NAME); ?></th>
                <th><?php _e('Amount', WPDEPOSIT_NAME); ?></th>
                <th><?php _e('Status', WPDEPOSIT_NAME); ?></th>
                <?php do_action('wpds_add_deposit_list_column_title'); ?>
                <th><?php _e('Actions', WPDEPOSIT_NAME); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr class="deposit_list_row">
                    <td><?php echo $row->user_nicename; ?></td>
                    <td><?php echo $row->unique_code; ?></td>
                    <td><strong><?php echo WPD_CURRENCY . $row->amount; ?></strong></td>
                    <?php $class = ($row->status == 0) ? 'orange' : 'green'; ?>	
                    <?php $status = ($row->status == 0) ? 'Pending' : 'Completed'; ?>
                    <td id="status_<?php echo $row->unique_code; ?>" class="status_column <?php echo $class; ?>">
                        <strong><?php echo $status; ?></strong>	
                    </td>
                    <?php do_action('wpds_add_deposit_list_column_content'); ?>
                    <td id="action_<?php echo $row->unique_code; ?>" class="actions">
                        <?php if ($row->status == 0): ?>	
                            <a href="javascript:void(0);" class="completedeposit" id="<?php echo $row->unique_code; ?>" title="<?php _e('Mark as completed', WPDEPOSIT_NAME); ?>">
                                <img src="<?php echo WPDEPOSIT_URL; ?>/resources/images/check.png" alt="<?php _e('Mark as completed', WPDEPOSIT_NAME); ?>" />
                            </a>	
                        <?php endif; ?>	
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>	
<?php do_action('wpds_deposit_list_view_after'); ?>