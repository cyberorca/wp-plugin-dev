<?php 
if ( is_user_logged_in() ) :
$userController = new UserController();
//We need to put the content in a variable and return it.
//Otherwise the page content (above the shortcode) will be pushed under the shortcode (until a better solution is found)
$donate = '<div class="feedback"></div>';
$donate .= do_action('wpds_donate_to_user_view_before');
$donate .= '<p>' . __('You currently have:', WPDEPOSIT_NAME) . ' <strong class="user_balance">' . the_credit_type_text(true, $userController->getBalanceInfo(true), true) . '</strong></p>';
$donate .= $wpelements->openForm('', 'post', false, 'frm_donate_to_user');
$donate .= '<p>';
    $donate .= '<label for="inp_donate_to_username">' . __('Merchant', WPDEPOSIT_NAME) . '</label> ';
    $donate .= '<input class="required" type="text" name="inp_donate_to_username" id="inp_donate_to_username" /> <small>' . __('masukkan nama merchant', WPDEPOSIT_NAME) . '</small>';
$donate .= '</p>';
$donate .= '<p>';
    $donate .= '<label for="inp_donate_amount">' . __('Jumlah Rp.', WPDEPOSIT_NAME) . '</label> ';
    $donate .= '<input class="required" type="text" name="inp_donate_amount" id="inp_donate_amount" size="4" />';
$donate .= '</p>';
do_action('wpds_add_donate_fields');
$donate .= '<p>';
    $donate .= '<input type="submit" name="sbm_donate_to_user" id="sbm_donate_to_user" value="' . __('Bayar', WPDEPOSIT_NAME) . '" />';
$donate .= '</p>';
$donate .= $wpelements->closeForm();
$donate .= do_action('wpds_donate_to_user_view_after');
else:
    $donate = __('You must be logged in to donate!', WPDEPOSIT_NAME);
endif;