<?php if(isset($missingTable) && !empty($missingTable)): ?>
<div class="error" id="message">
	<p><?php _e('Following tables/columns are missing:', WPDEPOSIT_NAME) ?></p>
	<ul>
		<?php foreach($missingTable as $mt): ?>
			<li><strong><?php echo $mt; ?></strong></li>
		<?php endforeach; ?>
	</ul>
</div>
<?php endif; ?>