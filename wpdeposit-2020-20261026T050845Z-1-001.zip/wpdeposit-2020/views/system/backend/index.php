<?php
	include_once "db_check.php";
?>
<p>
	<?php _e('When contacting us please provide the following information:', WPDEPOSIT_NAME); ?>
</p>
<table cellpadding="5">
	<tr>
        <td><strong><?php echo _e('Admin Email', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php bloginfo('admin_email'); ?></td>
	</tr>
	<tr>
        <td><strong><?php echo _e('Home', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php echo home_url(); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('HTML Type', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php bloginfo('html_type'); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('Language', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php bloginfo('language'); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('Name', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php bloginfo('name'); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('Version', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php bloginfo('version'); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('WP url', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php echo home_url(); ?></td>
    </tr>
	<tr>
        <td><strong><?php echo _e('Deposit mode', WPDEPOSIT_NAME) ?>:</strong></td>
		<td><?php echo (get_option(WPDEPOSIT_NAME . '_test_mode') == 1)? 'Testing' : 'Not testing'; ?></td>
	</tr>
</table>

<div class="icon32 icon32-posts-post" id="icon-edit"><br></div><h2>Last 50 log lines:</h2>
<p id="lastlogs"><?php if ($logs): ?>
    <?php echo nl2br($logs); ?>
    <p><small><?php _e('More logs can be found in file:', WPDEPOSIT_NAME); ?> <?php echo $pathToLog; ?></small></p>
<?php else: ?>
	<?php _e('No logs available, go to the settings page to turn on logging.', WPDEPOSIT_NAME); ?>
<?php endif; ?></p>
