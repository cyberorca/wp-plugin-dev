<p>
    <?php _e('Below you can specify how much points/credits a user will receive when performing certain actions.', WPDEPOSIT_NAME) ?>
    <br />
    <?php _e('* 0 = inactive', WPDEPOSIT_NAME); ?>
</p>
<div class="feedback"></div><!-- .feedback -->
<h2 class="nav-tab-wrapper">
    <a id="tab_1" class="nav-tab" href="javascript:void(0);"><?php _e('Rewards', WPDEPOSIT_NAME); ?></a>
    <a id="tab_2" class="nav-tab" href="javascript:void(0);"><?php _e('Extra rewards', WPDEPOSIT_NAME); ?></a>
</h2>
<div class="tab_box box_tab_1">
    <?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_rewards_form'); ?>
    <?php foreach($this->_actionList as $action): ?>
        <div class="reward_block">
            <h3>
                <?php echo $action['title']; ?> 
                <?php if(isset($action['url']) && !empty($action['url'])): ?>
                    <small>(<a href="<?php echo $action['url']; ?>" target="_blank"><?php _e('View plugin', WPDEPOSIT_NAME); ?></a>)</small>
                <?php endif; ?>
            </h3>
            <table class="form-table">
            <?php foreach($action['items'] as $item): ?>
                <tr>
                    <td>
                        <label for="inp_<?php echo $item['action']; ?>"><?php echo $item['label']; ?></label> 
                    </td>
                    <td>
                        <input size="3" type="text" name="<?php echo $item['action']; ?>" id="inp_<?php echo $item['action']; ?>" value="<?php echo $item['amount']['value']; ?>" />
                        <?php echo $this->selectPointTypeHtml($item['action'], $item['amount']['type']); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </table>
        </div>
    <?php endforeach; ?>
    <div class="clear"></div>
    <p class="submit_block">
        <input type="submit" name="sbm_rewards" value="<?php _e('Update Rewards', WPDEPOSIT_NAME); ?>" id="sbm_rewards" class="button-primary" />
    </p>
    <?php echo $wpelements->closeForm();  ?>
</div><!-- .box_tab_1 -->
<div class="tab_box box_tab_2">
    <p><?php _e("If you are using a plugin which isn't supported yet by WPdeposit you can add custom rewards below. This requires the external plugin to have custom action hooks.", WPDEPOSIT_NAME); ?></p>
    <div class="extra_rewards_wrapper">
        <div class="extra_rewards">
	        <div id="extra_reward_edit_form" style="display: none;">
                <?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_edit_extra_rewards_form'); ?>
                <h3>Edit extra reward</h3>
		        <input type="hidden" name="original_hook" id="original_hook" value="" />
		        <table class="form-table">
			        <tr>
				        <td style="width:120px;">
					        <label for="inp_action_hook"><?php _e('Action hook name', WPDEPOSIT_NAME); ?></label>
				        </td>
				        <td>
					        <input type="text" name="action_hook" id="inp_action_hook" value="" />
				        </td>
			        </tr>
			        <tr>
				        <td>
					        <label for="inp_action_hook_value_type"><?php _e('Type', WPDEPOSIT_NAME); ?></label>
				        </td>
				        <td>
					        <?php echo $this->selectPointTypeHtml('action_hook'); ?>
				        </td>
			        </tr>
			        <tr>
				        <td>
					        <label for="inp_action_hook_value"><?php _e('Amount', WPDEPOSIT_NAME); ?></label>
				        </td>
				        <td>
					        <input size="3" type="text" name="action_hook_value" id="inp_action_hook_value" value="" />
				        </td>
			        </tr>
		        </table>
                <p><input type="submit" name="edit_extra_reward" value="Edit" class="button-primary" /></p>
                <?php echo $wpelements->closeForm();  ?>
	        </div>
            <?php if(isset($extraRewards) && !empty($extraRewards)): ?>
                <table class="widefat extra_reward_list">
                    <tr>
                        <th><?php _e('Action hook name', WPDEPOSIT_NAME); ?></th>
                        <th><?php _e('Type', WPDEPOSIT_NAME); ?></th>
                        <th><?php _e('Amount', WPDEPOSIT_NAME); ?></th>
                        <th><?php _e('Actions', WPDEPOSIT_NAME); ?></th>
                    </tr>
                    <?php foreach($extraRewards['actions'] as $eReward): ?>
                    <tr>
                        <td><?php echo $eReward['action_hook'] ?></td>
                        <td><?php echo $eReward['action_hook_point_type'] ?></td>
                        <td><?php echo $eReward['action_hook_value'] ?></td>
                        <td>
                            <a href="#" class="edit_reward" data-hook="<?php echo $eReward['action_hook']; ?>"><?php _e('Edit', WPDEPOSIT_NAME); ?></a> |
                            <a href="#" class="delete_reward" data-hook="<?php echo $eReward['action_hook']; ?>"><?php _e('Delete', WPDEPOSIT_NAME); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>
        <?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_add_extra_rewards_form'); ?>
        <div class="extra_reward_field">
            <table class="form-table">
                <tr>
                    <td style="width:120px;">
                        <label for="inp_action_hook"><?php _e('Action hook name', WPDEPOSIT_NAME); ?></label> 
                    </td>
                    <td>
                        <input type="text" name="action_hook" id="inp_action_hook" value="" />
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="inp_action_hook_value_type"><?php _e('Type', WPDEPOSIT_NAME); ?></label> 
                    </td>
                    <td>
                        <?php echo $this->selectPointTypeHtml('action_hook'); ?>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="inp_action_hook_value"><?php _e('Amount', WPDEPOSIT_NAME); ?></label> 
                    </td>
                    <td>
                        <input size="3" type="text" name="action_hook_value" id="inp_action_hook_value" value="" />
                    </td>
                </tr>
            </table>
        </div>
        <div class="clear"></div>
        <p class="submit_block">
            <input type="submit" name="sbm_add_extra_rewards" value="<?php _e('Add extra Reward', WPDEPOSIT_NAME); ?>" id="sbm_add_extra_rewards" class="button-primary" />
        </p>
        <?php echo $wpelements->closeForm();  ?>
    </div>

</div><!-- .box_tab_21 -->