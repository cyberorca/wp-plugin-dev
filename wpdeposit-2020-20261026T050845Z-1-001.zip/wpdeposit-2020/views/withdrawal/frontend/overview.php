<?php
if (is_user_logged_in()):
    echo $withdrawalRequest;

    if (count($withdrawals) == 0):
        echo '<p>' . __('You have no withdrawals', WPDEPOSIT_NAME) . '</p>';
    else:
        ?>
        <table class="widefat deposit_list">
            <thead>
                <tr>
                    <th><?php _e('Date', WPDEPOSIT_NAME); ?></th>
                    <th><?php _e('Amount', WPDEPOSIT_NAME); ?></th>
                    <th><?php _e('Status', WPDEPOSIT_NAME); ?></th>
                    <th></th>
                    <?php do_action('wpds_add_fronted_withdrawal_list_column_title'); ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($withdrawals as $withdrawal): ?>
                    <tr class="">
                        <td><?php echo $withdrawal->created_ts; ?></td>
                        <td><strong><?php echo WPD_CURRENCY .' '. $withdrawal->amount; ?></strong></td>
                        <td><?php echo $withdrawal->status; ?></td>
                        <?php
                            $pageLink = get_page_link($pageId);
                            $cancelUrl = add_query_arg(array('action' => 'cancel', 'withdrawalId' => $withdrawal->id), $pageLink);
                        ?>
                        <td>
                            <?php if ($withdrawal->status == WithdrawalModel::STATUS_WAITING): ?>
                            <a href="<?php echo $cancelUrl; ?>" class="button-primary">Cancel withdrawal</a>
                            <?php endif; ?>
                        </td>
                        <?php do_action('wpds_add_frontend_withdrawal_list_column_content'); ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php 
else:
    echo '<a href="' . wp_login_url() . '" title="' . __('Login', WPDEPOSIT_NAME) . '">' . __('Please login to view your withdrawals', WPDEPOSIT_NAME) . '</a>';
endif;
