<?php
if (is_user_logged_in()):
    if ($withdrawalsEnabled == false):
        echo "<p>".__('Withdrawal requests are disabled', WPDEPOSIT_NAME)."<p>";
        $withdrawalRequest = '';
    else:
        $userController = new UserController();
        //We need to put the content in a variable and return it.
        //Otherwise the page content (above the shortcode) will be pushed under the shortcode (until a better solution is found)
        $withdrawalRequest = '<div class="feedback"></div>';
        $withdrawalRequest .= do_action('wpds_request_to_user_view_before');
        $withdrawalRequest .= '<p>' . __('You currently have:', WPDEPOSIT_NAME) . ' <strong class="user_balance">' . the_credit_type_text(true, $userController->getBalanceInfo(true), true) . '</strong>. ';
        $withdrawalRequest .= '' . __('You can withdraw up to ', WPDEPOSIT_NAME) . ' <strong class="withdrawal_balance">' . the_credit_type_text(true, $canWithdrawalAmount, true) . '</strong>.</p>';
        $withdrawalRequest .= $wpelements->openForm('', 'post', false, 'frm_request_withdrawal');
        $withdrawalRequest .= '<p>';
            $withdrawalRequest .= '<label for="inp_request_amount"><strong>' . __('Amount to withdraw', WPDEPOSIT_NAME) . '</strong></label><br /> ';
            $withdrawalRequest .= '<strong>$</strong> <input class="required" type="text" name="inp_request_amount" id="inp_request_amount" size="4" />';
        $withdrawalRequest .= '</p>';
	    $withdrawalRequest .= '<label><strong>' . __('Provide your desired Payment gateway', WPDEPOSIT_NAME) . '</strong></label><br /> ';
	    $withdrawalRequest .= '<div class="payment_gateways">';
            $withdrawalRequest .= $paymentGatewayList;
        $withdrawalRequest .= '</div><br />';


	    $withdrawalRequest .= '<p>';
		    $withdrawalRequest .= '<label for="inp_request_message"><strong>' . __('Provide your account information', WPDEPOSIT_NAME) . '</strong></label> ';
		    $withdrawalRequest .= '<textarea class="required" style="width:100%;" rows="6" name="inp_request_message" id="inp_request_message" placeholder="' . __('eg: My paypal email: paypalmail@mail.com', WPDEPOSIT_NAME) . '"></textarea>';
	    $withdrawalRequest .= '</p>';
        do_action('wpds_add_request_fields');
        $withdrawalRequest .= '<p>';
            $withdrawalRequest .= '<input type="submit" name="sbm_request_to_user" id="sbm_request_to_user" value="' . __('Request withdrawal', WPDEPOSIT_NAME) . '" />';
        $withdrawalRequest .= '</p>';
        $withdrawalRequest .= $wpelements->closeForm();
        $withdrawalRequest .= do_action('wpds_request_to_user_view_after');
    endif;
else:
    echo '<a href="' . wp_login_url() . '" title="' . __('Login', WPDEPOSIT_NAME) . '">' . __('Please login to request a withdrawal', WPDEPOSIT_NAME) . '</a>';
endif;