<div class="feedback"><?php echo (isset($feedback) && !empty($feedback))? $feedback : '' ; ?></div>
<?php
if (is_user_logged_in()):
    if (count($withdrawals) == 0):
        echo '<p>' . __('You have no withdrawals', WPDEPOSIT_NAME) . '</p>';
    else:
        ?>
        <p>
        <?php $wpelements->filter_options(array(
            'select_list' => array('users' => 'Users')
        )); ?>
        </p>
        <table class="widefat deposit_list">
            <thead>
                <tr>
                    <th width="200" ><?php _e('Date', WPDEPOSIT_NAME); ?></th>
                    <th width="150" ><?php _e('User', WPDEPOSIT_NAME); ?></th>
                    <th width="50" ><?php _e('Amount', WPDEPOSIT_NAME); ?></th>
                    <th width="200" ><?php _e('Payment gateway', WPDEPOSIT_NAME); ?></th>
                    <th width="50" ><?php _e('Status', WPDEPOSIT_NAME); ?></th>
                    <th><?php _e('Message', WPDEPOSIT_NAME); ?></th>
                    <th></th>
                    <?php do_action('wpds_add_backend_withdrawal_list_column_title'); ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($withdrawals as $withdrawal): ?>
                    <tr class="">
                        <td><?php echo $withdrawal->created_ts; ?></td>
                        <td><?php echo $withdrawal->buyer_username; ?></td>
                        <td><strong><?php echo WPD_CURRENCY .' '. $withdrawal->amount; ?></strong></td>
                        <td><?php echo $withdrawal->payment_gateway; ?></td>
                        <td><?php echo $withdrawal->status; ?></td>
                        <td><?php echo $withdrawal->message; ?></td>
                        <?php
                        $pageLink = get_permalink();
                        $confirmUrl = add_query_arg(array('action' => 'markasfinished', 'withdrawalId' => $withdrawal->id), $pageLink);
                        $rejectUrl = add_query_arg(array('action' => 'reject', 'withdrawalId' => $withdrawal->id), $pageLink);
                        ?>
                        <td>
                            <?php if ($withdrawal->status == WithdrawalModel::STATUS_WAITING): ?>
                                <a href="<?php echo $confirmUrl; ?>" class="button-primary">Mark as finished</a>
                                <a href="<?php echo $rejectUrl; ?>" class="button-primary">Reject withdrawal</a>
                            <?php endif; ?>
                        </td>
                        <?php do_action('wpds_add_backend_withdrawal_list_column_content'); ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
<?php 
else:
    echo '<a href="' . wp_login_url() . '" title="' . __('Login', WPDEPOSIT_NAME) . '">' . __('Please login to view your withdrawals', WPDEPOSIT_NAME) . '</a>';
endif;