<?php

    $rc = $info =$status = $trxtime = $accno = $accname = $billperiode = $nominal = $adminfee = $price = $balance = $urlstruk = $refca = $refsbinq = '-';
    
if(isset($response['rc'])){

		foreach($response as $k=>$v ){
		  $$k = isset($response[$k]) ? $v : '-';
		}
		
		$form_member .= <<<EOT
		<table class="table table-striped">
			<tbody>
			<tr>
									<th colspan='2'>tagihan Asuransi</th>
									<th></th>
								</tr>
				<tr>
				  <td>Response Code</td>
				  <td>$status</td>
				</tr>
				
				<tr>
				  <td>Product Code</td>
				  <td>
				  
				  {$wpelements->input_field($type = 'hidden', 'uid', '', array('value'=>Siapbayar::ID_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'pin', '', array('value'=>Siapbayar::PIN_MEMBER,'for_table'=>false))}
				  
				  </td>
				</tr>
				
			
				
				<tr>
				  <td>-</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'refca', '', array('value'=>$refca,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  
				<tr>
			</tbody>
		</table>
		<input type="submit" name="submit_payment" id="submit_payment" value="BAYAR" />
EOT;
	}else{
		$form_member = '<h1><strong>CEK TRANSAKSI</strong></h1>';
		
		$form_member .= $wpelements->input_field($type = 'text', 'refca', 'REF CA', array('required'=>true));
		$form_member .= '</p><p>';
		
		$form_member .= '<input type="submit" name="submit_inquiry" id="submit_inquiry" value="' . __('SUBMIT', WPDEPOSIT_NAME) . '" />';
		$form_member .= '</p>';
	}	
	