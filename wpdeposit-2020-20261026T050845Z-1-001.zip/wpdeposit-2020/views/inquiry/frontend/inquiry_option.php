<?php
$inquiry_option = <<<FORM
<select name="productcode" id="productcode" class="form-control" required>
    <option value="">Pilih Pembayaran</option>
    <optgroup label="LEASING">
    <option value="LSADIRAL">ADIRA ELEKTRONIK</option>
        <option value="LSADIRA">ADIRA MOTOR</option>
        <option value="LSBIMA">BIMA FINANCE</option>
        
        <option value="LSBAF">BAF</option>
        <option value="LSCLMB">Columbia</option>
        <option value="LSMAF">MEGA AUTO FINANCE</option>
        <option value="LSMEGA">MEGA CENTRAL FINANCE</option>
        <option value="LSMPM">MPM FINANCE</option>
        <option value="LSOTO">OTO FINANCE</option>
        <option value="LSRADA">RADANA FINANCE</option>
        <option value="LSWKF">WOKA FINANCE</option>
        <option value="LSWOM">WOM FINANCE</option>
        <option value="LSFIF">FIF</option>
    </optgroup>
    <optgroup label="PDAM">
    <option value="PAMAET">AETRA JAKARTA</option>
        <option value="PAMPLJ">PALYJA JAKARTA</option>
        <option value="PAMBTM">PDAM BATAM</option>
        <option value="PAMCMS">PDAM CIAMIS</option>
        <option value="PAMCBN">PDAM CIREBON</option>
        <option value="PAMJAP">PDAM JAYAPURA</option>
        <option value="PAMKPRN">KAB BALANGAN</option>
        <option value="PAMKBDG">KAB BANDUNG</option>
        <option value="PAMKBKL">KAB BANGKALAN</option>
        <option value="PAMKPWT">KAB BANYUMAS</option>
        <option value="PAMKBTG">KAB BATANG</option>
        <option value="PAMBLA">KAB BLORA</option>
        <option value="PAMKBGR">KAB BOGOR</option>
        <option value="PAMKBGN">KAB BOJONEGORO</option>
        <option value="PAMKBDW">KAB BONDOWOSO</option>
        <option value="PAMKBYL">KAB BOYOLALI</option>
        <option value="PAMKBBS">KAB BREBES</option>
        <option value="PAMKSGR">KAB BULELENG BALI</option>
        <option value="PAMKCLP">KAB CILACAP</option>
        <option value="PAMKPWD">KAB GROBOGAN</option>
        <option value="PAMGRT">KAB GARUT</option>
        <option value="PAMKJMR">KAB JEMBER</option>
        <option value="PAMKJPA">KAB JEPARA</option>
        <option value="PAMKKRG">KAB KARANGANYAR</option>
        <option value="PAMKKBM">KAB KEBUMEN</option>
        <option value="PAMKSRP">KAB KLUNGKUNG</option>
        <option value="PAMKSRY">KAB KUBURAYA</option>
        <option value="PAMKKN">KAB KUTAI KARTANEGARA</option>
        <option value="PAMKPYA">KAB LOMBOK TENGAH</option>
        <option value="PAMKMLG">KAB MALANG</option>
        <option value="PAMKMJK">KAB MOJOKERTO</option>
        <option value="PAMKPKL">KAB PEKALONGAN</option>
        <option value="PAMKPBL">KAB PROBOLINGGO</option>
        <option value="PAMKPBG">KAB PURBALINGGA</option>
        <option value="PAMKRBG">KAB REMBANG</option>
        <option value="PAMKSPG">KAB SAMPANG MADURA</option>
        <option value="PAMKSMG">KAB SEMARANG</option>
        <option value="PAMKSDA">KAB SIDOARJO</option>
        <option value="PAMKSIT">KAB SITUBONDO</option>
        <option value="PAMKSMN">KAB SLEMAN</option>
        <option value="PAMKSKH">KAB SUKOHARJO</option>
        <option value="PAMKTNG">KAB TANGERANG</option>
        <option value="PAMKRTA">KAB TAPIN</option>
        <option value="PAMKTMG">KAB TEMANGGUNG</option>
        <option value="PAMKWNG">KAB WONOGIRI</option>
        <option value="PAMKWSB">KAB WONOSOBO</option>
        <option value="PAMBDL">KOTA BANDAR LAMPUNG</option>
        <option value="PAMBDG">KOTA BANDUNG</option>
        <option value="PAMBJB">KOTA BANJAR BARU</option>
        <option value="PAMDPR">KOTA DENPASAR</option>
        <option value="PAMDPK">KOTA DEPOK</option>
        <option value="PAMMAD">KOTA MADIUN</option>
        <option value="PAMMLG">KOTA MALANG</option>
        <option value="PAMMND">KOTA MANADO</option>
        <option value="PAMMTR">KOTA MATARAM</option>
        <option value="PAMMDN">KOTA MEDAN</option>
        <option value="PAMPLG">KOTA PALEMBANG</option>
        <option value="PAMPSR">KOTA PASURUAN</option>
        <option value="PAMSLT">KOTA SALATIGA</option>
        <option value="PAMSMG">KOTA SEMARANG</option>
        <option value="PAMSBY">KOTA SURABAYA</option>
        <option value="PAMTGT">KOTA TANAH GROGOT</option>
        <option value="PAMKTI">KOTA KUTAI</option>
        <option value="PAMMSI">KOTA MUSI</option>
        <option value ="PAMKBDGBR">KABUPATEN BANDUNG BARAT</option>
        
        
        <optgroup label="TB">
        <option value="TM25">Tol mandiri 25</option>
        
        <option value="SGR10">Token Listrik</option>
        <option value="TB10">Tol BNi 10</option>
    </optgroup>
        
    </optgroup>
    <optgroup label="ce">
        <option value="CE">PLN Pasca Bayar</option>
        
    </optgroup>
    <optgroup label="PLN">
        <option value="PLNPAC">PLN Pasca Bayar</option>
        <option value="PLNT">Token Listrik</option>
        <option value="PLNNON">Non Tagihan Listrik</option>
    </optgroup>
    <optgroup label="TELKOM">
        <option value="TELEPON">Telepon</option>
        <option value="SPEEDY">speedy / indihome</option>
    </optgroup>
    <optgroup label="KARTU KREDIT">
        <option value="KKAMEX">AMEX</option>
        <option value="KKANZ">ANZ</option>
        <option value="KKMGCF">BANKMEGA CAREFOUR</option>
        <option value="KKMGVSA">BANK MEGAVISA</option>
        <option value="KKBCA">BCA</option>
        <option value="KKBII">BII</option>
        <option value="KKBNI">BNI</option>
        <option value="KKBRI">BRI</option>
        <option value="KKBKPN">BUKOPIN</option>
        <option value="KKCIMB">CIMB NIAGA</option>
        <option value="KKCITI">CITIBANK</option>
        <option value="KKDANAMON">DANAMON</option>
        <option value="KKGE">GE</option>
        <option value="KKHSBC">HSBC</option>
        <option value="KKMANDR">MANDIRI</option>
        <option value="KKPANIN">PANIN</option>
        <option value="KKPRMTA">PERMATA</option>
        <option value="KKSTDC">STANDARD CHARTERED</option>
        <option value="KKUOBB">UOB BUANA</option>
    </optgroup>
    <optgroup label="HP PASCA">
        <option value="HPTSEL">Telkomsel (Halo)</option>
        <option value="HPXL">XL (xplor)</option>
        <option value="HPMTRIX">Indosat (Matrix)</option>
        <option value="HPESIA">Esia (Postpaid)</option>
        <option value="HPFREN">FREN, MOBI, HEPI (POSTPAID)</option>
        <option value="HPSMART">SMARTFREN (Postpaid)</option>
        <option value="HPTHREE">THREE (Postpaid)</option>
    </optgroup>
    <optgroup label="ASURANSI">
        <option value="ASBPJSKS">BPJS Kesehatan</option>
        <option value="ASCAR">CAR</option>
        <option value="ASPRU">PRUDENTIAL PREMI LANJUTAN</option>
        <option value="ASBINT1">ASURANSI BINTANG PAKET 1</option>
        <option value="ASBINT2">ASURANSI BINTANG PAKET 2</option>
        <option value="ASJWS">ASURANSI JIWASRAYA</option>
        <option value="ASTOKIOS">TOKIO MARINE (SatuTagihan)</option>
        <option value="ASTOKIO">TOKIO MARINE (SemuaTagihan)</option>
    </optgroup>
    <optgroup label="TV KABEL">
        <option value="TVSKYFAM3">SKYNINDO TV FAMILY 3 BLN (120.000)</option>
        <option value="TVSKYFAM6">SKYNINDO TV FAMILY 6 BLN (240.000)</option>
        <option value="TVSKYFAM12">SKYNINDO TV FAMILY 12 BLN (480.000)</option>
        <option value="TVSKYDEL1">SKYNINDO TV DELUXE 1 BLN (80.000)</option>
        <option value="TVSKYDEL3">SKYNINDO TV DELUXE 3 BLN (240.000)</option>
        <option value="TVSKYDEL6">SKYNINDO TV DELUXE 6 BLN (480.000)</option>
        <option value="TVSKYDEL12">SKYNINDO TV DELUXE 12 BLN (960.000)</option>
        <option value="TVSKYMAN1">SKYNINDO TV MANDARIN 1 BLN (140.000)</option>
        <option value="TVSKYMAN3">SKYNINDO TV MANDARIN 3 BLN (420.000)</option>
        <option value="TVSKYMAN6">SKYNINDO TV MANDARIN 6 BLN (840.000)</option>
        <option value="TVSKYMAN12">SKYNINDO TV MANDARIN 12 BLN (1.680.000)</option>
        <option value="TVKV50">K VISION (50.000)</option>
        <option value="TVKV75"> K VISION (75.000)</option>
        <option value="TVKV100">K VISION (100.000)</option>
        <option value="TVKV125">K VISION (125.000)</option>
        <option value="TVKV150">K VISION (150.000)</option>
        <option value="TVKV175">K VISION (175.000)</option>
        <option value="TVKV200">K VISION (200.000)</option>
        <option value="TVKV250">K VISION (250.000)</option>
        <option value="TVKV300">K VISION (300.000)</option>
        <option value="TVKV500">K VISION (500.000)</option>
        <option value="TVKV750">K VISION (750.000)</option>
        <option value="TVKV1000">K VISION (1.000.000)</option>
        <option value="TVORG30">ORANGE TV (50.000)</option>
        <option value="TVORG50">0RANGE TV (80.000)</option>
        <option value="TVORG100">0RANGE TV (100.000)</option>
        <option value="TVORG300">0RANGE TV (300.000)</option>
        <option value="TKORANGE">ORANGE TV POSTPAID</option>
        <option value="TVGEN25">GENFLIX (25.000)</option>
        <option value="TVGEN50">GENFLIX (50.000)</option>
        <option value="TVGEN100">GENFLIX (100.000)</option>
        <option value="TVBIG">BIG TV</option>
        <option value="TVINNOV">Innovate TV</option>
        <option value="TKNEX">NEX MEDIA</option>
        
    </optgroup>
    
    
</select>

FORM;



