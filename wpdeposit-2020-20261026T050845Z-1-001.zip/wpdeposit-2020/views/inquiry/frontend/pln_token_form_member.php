<?php
    $rc = $info = $trxtime = $accno = $accname = $billperiode = $nominal = $adminfee = $price = $balance = $notes = $nohp = $noref = $urlstruk = $refca = $refsb = '-';
    
   echo "Inquiry Response : <pre>";
	print_r($response);
	echo "</pre>";	
		
		
	if(isset($inq_response['rc'])){
	
		foreach($inq_response as $k=>$v ){
		  $$k = isset($inq_response[$k]) ? $v : '-';
		}
		
		$form_member .= <<<EOT
		<table class="table table-striped">
			<tbody>
				<tr>
				  <td>Response Code</td>
				  <td>$rc</td>
				</tr>
				<tr>
				  <td>Information</td>
				  <td>$info</td>
				</tr>
				<tr>
				  <td>Product Code</td>
				  <td>
				  {$wpelements->input_field($type = 'hidden', 'opcode', '', array('value'=>'payment','for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'uid', '', array('value'=>Siapbayar::ID_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'pin', '', array('value'=>Siapbayar::PIN_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'text', 'productcode', '', array('value'=>$productcode,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>Transaction Time</td>
				  <td>$trxtime</td>
				</tr>
				<tr>
				  <td>ID Pelanggan</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'accno', '', array('value'=>$accno,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				
				<tr>
				  <td>Nama</td>
				  <td>$accname</td>
				</tr>
				<tr>
				  <td>Jumlah Tagihan</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'nominal', '', array('value'=>$nominal,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>Periode</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'billperiode', '', array('value'=>$billperiode,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				
				<!--tr>
				  <td>Total Tagihan</td>
				  <td>$price</td>
				</tr>
				<tr>
				  <td>Balance</td>
				  <td>$balance</td>
				</tr>
				<tr>
				  <td>Notes Value</td>
				  <td>$notes</td>
				</tr>
				
				<tr>
				  <td>Nomor Referensi</td>
				  <td>$noref</td>
				</tr>
				<tr>
				  <td>URL Struk</td>
				  <td>$urlstruk</td>
				</tr--->
				<tr>
				  <td>Biaya Admin</td>
				  <td>$adminfee</td>
				</tr>
				<tr>
				  <td>No. Ref</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'refca', '', array('value'=>$refca,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>No. Ref SB</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'refsb', '', array('value'=>$refsb,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
			</tbody>
		</table>
		<input type="submit" name="submit_payment" id="submit_payment" value="BAYAR" />
EOT;
	}else{
		$form_member = '<h1><strong>TOKEN Listrik</strong></h1>';
		$form_member .= $wpelements->input_field($type = 'hidden', 'productcode', '', array('value'=>$productcode));
		$form_member .= '<p>';
		$form_member .= $wpelements->input_field($type = 'text', 'accno', 'ID Token', array('required'=>true));
		$form_member .= '</p><p>';
		
		$form_member .= '<input type="submit" name="submit_inquiry" id="submit_inquiry" value="' . __('SUBMIT', WPDEPOSIT_NAME) . '" />';
		$form_member .= '</p>';
	}	
	