<?php
    $rc = $info = $pulsa = $trxtime = $nohp = $serialno = $price = $balance = $refca = $refsb = '-';
    
if(isset($response['rc'])){

		foreach($response as $k=>$v ){
		  $$k = isset($response[$k]) ? $v : '-';
		}
		
		$form_member .= <<<EOT
		<table class="table table-striped">
			<tbody>
				
				<tr>
			<th colspan='2'>Top UP</th>
			<th></th>
			</tr>
				<tr>
				  <td>Response Code</td>
				  <td>$rc</td>
				</tr>
				<tr>
				  <td>Information</td>
				  <td>$info</td>
				</tr>
				<tr>
				  <td>Product Code</td>
				  <td>
				 {$wpelements->input_field($type = 'hidden', 'opcode', '', array('value'=>'payment','for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'uid', '', array('value'=>Siapbayar::ID_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'pin', '', array('value'=>Siapbayar::PIN_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'productcode', '', array('value'=>$productcode,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>Transaction Time</td>
				  <td>$trxtime</td>
				</tr>
				<tr>
				  <td>No HP</td>
				  <td>$nohp</td>
				</tr>
				<tr>
				  <td>Serial Number</td>
				  <td>$serialno</td>
				</tr>
				<tr>
				  <td>Harga</td>
				  <td>$price</td>
				</tr>
				
				<tr>
				  <td>Balance</td>
				  <td>$balance</td>
				</tr>
				
				<tr>
				  <td>No. Ref</td>
				  <td>$refca</td>
				</tr>
				<tr>
				  <td>No. Ref SB</td>
				  <td>$refsb </td>
				</tr>
				<tr>
			</tbody>
		</table>
		
EOT;
	}else{
		$form_member = '<h1><strong>Top UP</strong></h1>';
		$form_member .= $wpelements->input_field($type = 'hidden', 'productcode', '', array('value'=>$productcode));
		$form_member .= '<p>';
		$form_member .= $wpelements->input_field($type = 'text', 'nohp', 'Nomor HP', array('required'=>true));
		$form_member .= '</p><p>';
		
		$form_member .= '<input type="submit" name="submit_inquiry" id="submit_inquiry" value="' . __('SUBMIT', WPDEPOSIT_NAME) . '" />';
		$form_member .= '</p>';
	}	
	