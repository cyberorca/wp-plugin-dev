<?php
    $rc = $info = $trxtime = $accno = $accname = $billperiode = $nominal = $adminfee = $price = $balance = $urlstruk = $refca = $refsbinq = $notes = $noref = $refsb = '-';
    
if(isset($response['rc'])){

		foreach($response as $k=>$v ){
		  $$k = isset($response[$k]) ? $v : '-';
		}
		
		$form_member .= <<<EOT
		<table class="table table-striped">
			<tbody>
			<tr>
									<th colspan='2'>tagihan PDAM PILIHBAYAR</th>
									<th></th>
								</tr>
				<tr>
				  <td>Kode</td>
				  <td>$rc</td>
				</tr>
				<tr>
				  <td>Informasi</td>
				  <td>$info</td>
				</tr>
				<tr>
				  <td>Kode Produk</td>
				  <td>
				  {$wpelements->input_field($type = 'hidden', 'opcode', '', array('value'=>'payment','for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'uid', '', array('value'=>Siapbayar::ID_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'pin', '', array('value'=>Siapbayar::PIN_MEMBER,'for_table'=>false))}
				  {$wpelements->input_field($type = 'hidden', 'productcode', '', array('value'=>$productcode,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>Waktu</td>
				  <td>$trxtime</td>
				</tr>
				<tr>
				  <td>ID Pelanggan</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'accno', '', array('value'=>$accno,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				
				<tr>
				  <td>Nama</td>
				  <td>$accname</td>
				</tr>
				<tr>
				  <td>Jumlah Tagihan</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'nominal', '', array('value'=>$nominal,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>Periode</td>
				  <td>
				  {$wpelements->input_field($type = 'text', 'billperiode', '', array('value'=>$billperiode,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				
				<!--tr>
				  <td>Total Tagihan</td>
				  <td>$price</td>
				</tr>
				<tr>
				  <td>Balance</td>
				  <td>$balance</td>
				</tr>
				<tr>
				  <td>Notes Value</td>
				  <td>$notes</td>
				</tr>
				
				<tr>
				  <td>Nomor Referensi</td>
				  <td>$noref</td>
				</tr>
				<tr>
				  <td>URL Struk</td>
				  <td>$urlstruk</td>
				</tr--->
				<tr>
				  <td>Biaya Admin</td>
				  <td>$adminfee</td>
				</tr>
				<tr>
				  <td>-</td>
				  <td>
				  {$wpelements->input_field($type = 'hidden', 'refca', '', array('value'=>$refca,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
				  <td>-</td>
				  <td>
				  {$wpelements->input_field($type = 'hidden', 'refsbinq', '', array('value'=>$refsb,'readonly'=>'readonly','for_table'=>false))}
				  </td>
				</tr>
				<tr>
			</tbody>
		</table>
		<input type="submit" name="submit_payment" id="submit_payment" value="BAYAR"  />
		<button id='bpjs-back' onclick='window.print();'>CETAK</button>
EOT;
	}else{
		$form_member = '<h1><strong>Tagihan PDAM PILIHBAYAR</strong></h1>';
		$form_member .= $wpelements->input_field($type = 'hidden', 'productcode', '', array('value'=>$productcode));
		$form_member .= '<p>';
		$form_member .= $wpelements->input_field($type = 'text', 'accno', 'ID Pelanggan', array('required'=>true));
		$form_member .= '</p><p>';
		
		$form_member .= '<input type="submit" name="submit_inquiry" id="submit_inquiry" value="' . __('SUBMIT', WPDEPOSIT_NAME) . '" />';
		$form_member .= '</p>';
	}	
	