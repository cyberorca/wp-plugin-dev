<?php
    #print_r($_POST);
    $req = isset($_POST['request']) ? $_POST['request']  : '';
	$inquirylRequest  = '<div id="contact-area">';
    $inquirylRequest .= $wpelements->openForm('', 'post', false, 'frm_list_inquiry','form-inline');
    $inquirylRequest .= "<div class='form-group'>" . $inquiry_option . "</div>";
    $inquirylRequest .= '<input type="submit" name="submit_option" id="submit_option" value="' . __('GO!', WPDEPOSIT_NAME) . '" />';
    $inquirylRequest .= $wpelements->closeForm();
    $inquirylRequest .= $wpelements->openForm('', 'post', false, 'frm_request_inquiry','form-inline');
    $inquirylRequest .= $form_member;
    $inquirylRequest .= $wpelements->closeForm();
    $inquirylRequest .= '<div style="clear: both;"></div>';
    $inquirylRequest .= '</div>';
    
    $inquirylRequest  = '<div id="contact-area" class="row"><div class="col-md-12">';
    $inquirylRequest .= $wpelements->openForm('', 'post', false, 'frm_list_inquiry', 'form-inline');
    $inquirylRequest .= '<div class="form-group"><label for="productcode">Kode Produk</label>' . $inquiry_option . '</div>';
    $inquirylRequest .= ' <button class="btn btn-success btn-sm" type="submit" name="submit_option" id="submit_option">LANJUT</button>';
    $inquirylRequest .= $wpelements->closeForm();
    $inquirylRequest .= '</div></div>';
    $inquirylRequest .= '<div id="contact-area" class="row"><div class="col-md-12">';
    $inquirylRequest .= $wpelements->openForm('', 'post', false, 'frm_request_inquiry', 'form-inline');
    $inquirylRequest .= $form_member;
    $inquirylRequest .= $wpelements->closeForm();
    $inquirylRequest .= '<div style="clear: both;"></div>';
    $inquirylRequest .= '</div></div>';

?>
<script>
/*
window.addEventListener('load',function(){
    document.getElementById('productcode').addEventListener('change',function(e){
        document.getElementById("frm_request_inquiry").submit();
    },false);
  
  document.getElementById('productcode').setAttribute("disabled","true");
    var inputs=document.getElementsByTagName("input"),
    x=inputs.length;
	while(x--)
	    if(inputs[x].type==="radio")
	        inputs[x].addEventListener("change",function(){
	         document.getElementById('productcode').removeAttribute("disabled");
	        },0);
	        
});*/
</script>
