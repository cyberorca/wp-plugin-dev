<div id="wpdeposit-custom-views">
	<div class="feedback"></div><!-- .feedback -->
	<p><?php _e('If you wish to modify the look of the different pages/shortcodes, you can generate custom views which will be used instead of the default views provided by the plugin.', WPDEPOSIT_NAME); ?></p>
	<p><a href="#" class="generate_view_files"><?php _e('Generate custom views', WPDEPOSIT_NAME); ?></a></p>
	<?php if($customViewsExist): ?>
		<p><?php _e('Note: Generated view files were found in your theme.', WPDEPOSIT_NAME); ?></p>
	<?php endif; ?>
</div>
<script type="text/javascript" charset="utf-8">
jQuery(document).ready(function($) {
    customViewExists = false;
    <?php if($customViewsExist): ?>
        customViewExists = true;
    <?php endif; ?>
});
</script>