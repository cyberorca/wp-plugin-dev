<?php if(get_option(WPDEPOSIT_NAME . '_test_mode') == 1): ?>
    <div class="feedback"><p><?php _e('You are currently in test mode.', WPDEPOSIT_NAME); ?></p></div><!-- .feedback -->
<?php else: ?>
    <div class="feedback"></div><!-- .feedback -->
<?php endif; ?>
<?php echo $this->_wpelements->openForm('', 'POST', false, 'wpdeposit_go_form'); ?>
	<?php echo $paymentGatewayList; ?>
	<div class="clear"></div>
	<p class="input_block"><input type="submit" class="button-primary " size="80" value="<?php _e('Update settings', WPDEPOSIT_NAME); ?>" id="wpdeposit_pg_submit" name="submit"></p>
<?php echo $this->_wpelements->closeForm(); ?>