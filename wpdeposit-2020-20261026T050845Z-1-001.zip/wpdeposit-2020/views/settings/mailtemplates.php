<?php $available_shortcodes = __('Available shortcodes for this mail template.', WPDEPOSIT_NAME); ?>
<div class="feedback"></div><!-- .feedback -->
<?php echo $wpelements->openForm('', 'POST', false, WPDEPOSIT_NAME . '_settings_mail_templates'); ?>
<div id="<?php echo WPDEPOSIT_NAME; ?>_success_mail" class="mail_block">
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{USERNAME}</li>
            <li>{AMOUNT}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_success_mail_content">
                <?php echo __('Success email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_success_mail_content" id="<?php echo WPDEPOSIT_NAME; ?>_success_mail_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME . '_success_mail_content'); ?></textarea>
    </div>
</div>
<div id="<?php echo WPDEPOSIT_NAME; ?>_error_mail" class="mail_block">
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{USERNAME}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_error_mail_content">
                <?php echo __('Error/Cancel email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_error_mail_content" id="<?php echo WPDEPOSIT_NAME; ?>_error_mail_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME . '_error_mail_content'); ?></textarea>
    </div>
</div>
<hr />
<h2><?php echo __('Donation email templates', WPDEPOSIT_NAME); ?></h2>
<div id="<?php echo WPDEPOSIT_NAME; ?>_user_donation_email" class="mail_block">
    <p>
        <input type="checkbox" <?php echo (WPDEPOSIT_ENABLE_USER_ENABLE)? 'checked' : '' ; ?> value="1" name="<?php echo WPDEPOSIT_NAME; ?>_user_donation_content_enable" id="<?php echo WPDEPOSIT_NAME; ?>_user_donation_content_enable" /> 
        <label for="<?php echo WPDEPOSIT_NAME; ?>_user_donation_content_enable"><?php echo __('Send e-mail to users', WPDEPOSIT_NAME); ?></label>
    </p>
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{DONATER}</li>
            <li>{DONATION}</li>
            <li>{DONATION_RECEIVER}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_user_donation_email_content">
                <?php echo __('User donation email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_user_donation_email_content" id="<?php echo WPDEPOSIT_NAME; ?>_user_donation_email_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME . '_user_donation_email_content'); ?></textarea>
    </div>
</div>
<div id="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_email" class="mail_block">
    <p>
        <input type="checkbox" <?php echo (WPDEPOSIT_ENABLE_ADMIN_ENABLE)? 'checked' : '' ; ?> value="1" name="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_content_enable" id="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_content_enable" /> 
        <label for="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_content_enable"><?php echo __('Send e-mail to admin', WPDEPOSIT_NAME); ?></label>
    </p>
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{DONATER}</li>
            <li>{DONATION}</li>
            <li>{DONATION_RECEIVER}</li>
            <li>{USERNAME}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_email_content">
                <?php echo __('Admin donation notification email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_email_content" id="<?php echo WPDEPOSIT_NAME; ?>_admin_donation_email_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME . '_admin_donation_email_content'); ?></textarea>
    </div>
</div>
<hr />
<h2><?php echo __('Withdrawal email templates', WPDEPOSIT_NAME); ?></h2>
<div id="<?php echo WPDEPOSIT_NAME; ?>_user_withdrawal_email" class="mail_block">
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{AMOUNT}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_user_withdrawal_email_content">
                <?php echo __('Withdrawal REJECT email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_withdrawal_reject_email_content" id="<?php echo WPDEPOSIT_NAME; ?>_withdrawal_reject_email_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME .'_'. SettingsOptionsController::MAIL_WITHDRAWAL_REJECTED); ?></textarea>
    </div>
</div>
<div id="<?php echo WPDEPOSIT_NAME; ?>_admin_withdrawal_email" class="mail_block">
    <div class="mail_template_legend">
        <p><?php echo $available_shortcodes; ?></p>
        <ul class="shortcode_legend">
            <li>{AMOUNT}</li>
            <li>{SITEURL}</li>
            <li>{SITENAME}</li>
        </ul>
    </div>
    <div class="input_block">
        <p>
            <label class="lbl_textarea" for="<?php echo WPDEPOSIT_NAME; ?>_admin_withdrawal_email_content">
                <?php echo __('Withdrawal SUCCESS email template', WPDEPOSIT_NAME); ?>
            </label>
        </p>
        <textarea class="required" name="<?php echo WPDEPOSIT_NAME; ?>_withdrawal_success_email_content" id="<?php echo WPDEPOSIT_NAME; ?>_withdrawal_finished_email_content" cols="120" rows="10"><?php echo get_option(WPDEPOSIT_NAME .'_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED); ?></textarea>
    </div>
</div>
<p>
    <input type="submit" name="sbm_mail_templates" id="sbm_mail_templates" value="<?php _e('Update options', WPDEPOSIT_NAME); ?>" class="button-primary" />
</p>
<?php do_action('wpds_add_mail_templates_fields'); ?>
<?php echo $wpelements->closeForm();  ?>