<?php $pdfGenMessage = __('Will be displayed when an invoice or a deposit history pdf is generated.', WPDEPOSIT_NAME); ?>
<div class="feedback"></div><!-- .feedback -->
<?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_settings_form_add'); ?>
<table class="form-table">
    <tr>
        <td>
            <label for="rad_deposit_log"><?php _e('Log deposit actions', WPDEPOSIT_NAME); ?>:</label>
        </td>
        <td>
            <?php if($wpelements->if_selected(get_option(WPDEPOSIT_NAME . '_deposit_log'))): ?>
                <input type="radio" name="deposit_log" id="deposit_log" checked value="1" /> <?php _e('On', WPDEPOSIT_NAME); ?>
                <input type="radio" name="deposit_log" id="deposit_log" value="0" /> <?php _e('Off', WPDEPOSIT_NAME); ?>
            <?php else: ?>
                <input type="radio" name="deposit_log" id="deposit_log" value="1" /> <?php _e('On', WPDEPOSIT_NAME); ?>
                <input type="radio" name="deposit_log" id="deposit_log" checked value="0" /> <?php _e('Off', WPDEPOSIT_NAME); ?>
            <?php endif; ?>
            <small>Logs can be viewed on the system page.</small>
            <?php if ((LOG_DEPOSITS || LOG_DEPOSITS == 1) && (touch(WPDEPOSIT_PATH . '/deposit_log.txt') == false) && !is_writeable(WPDEPOSIT_PATH . '/deposit_log.txt')): ?>
                <small style="color: red">Error: make sure the file "<?php echo WPDEPOSIT_PATH . '/deposit_log.txt' ?>" is writeable!</small>
            <?php endif; ?>
        </td>
    </tr> <tr>
        <td>
            <label for="rad_withdrawals"><?php _e('Withdrawals', WPDEPOSIT_NAME); ?>:</label>
        </td>
        <td>
            <?php if (WPD_CREDIT_TYPE == 'points'): ?>
                <p>Notice: The points system is on so withdrawal is disabled. Withdrawal only works with Money.</p>
            <?php endif; ?>
	        <?php $withdrawalSetting = get_option(WPDEPOSIT_NAME.'_WITHDRAWALS_SETTING'); ?>
            <select name="withdrawals" id="withdrawals" >
            <?php if ($withdrawalSetting == WithdrawalModel::SETTING_EVERYTHING): ?>
                <option value="everything"  selected="selected"><?php _e('Deposits + Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="deposits_only" /> <?php _e('Only Deposits', WPDEPOSIT_NAME); ?></option>
                <option value="earnings_only" /> <?php _e('Only Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="disabled" /><?php _e('Disabled', WPDEPOSIT_NAME); ?></option>
            <?php elseif ($withdrawalSetting == WithdrawalModel::SETTING_DEPOSITS_ONLY): ?>
                <option value="everything"> <?php _e('Deposits + Earnings', WPDEPOSIT_NAME); ?></option>
                <option selected="selected"  value="deposits_only"> <?php _e('Only Deposits', WPDEPOSIT_NAME); ?></option>
                <option value="earnings_only"> <?php _e('Only Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="disabled"> <?php _e('Disabled', WPDEPOSIT_NAME); ?></option>
            <?php elseif ($withdrawalSetting == WithdrawalModel::SETTING_EARNINGS_ONLY): ?>
                <option value="everything"> <?php _e('Deposits + Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="deposits_only"> <?php _e('Only Deposits', WPDEPOSIT_NAME); ?></option>
                <option selected="selected" value="earnings_only"> <?php _e('Only Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="disabled"> <?php _e('Disabled', WPDEPOSIT_NAME); ?></option>
            <?php else: ?>
                <option value="everything"> <?php _e('Deposits + Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="deposits_only"> <?php _e('Only Deposits', WPDEPOSIT_NAME); ?></option>
                <option value="earnings_only"> <?php _e('Only Earnings', WPDEPOSIT_NAME); ?></option>
                <option value="disabled"  selected="selected"> <?php _e('Disabled', WPDEPOSIT_NAME); ?></option>
            <?php endif; ?>
            </select>
        </td>
    </tr>
    <tr>
        <td>
	<label><?php _e('Points name', WPDEPOSIT_NAME); ?>:</label> 
        </td>
        <td>
            <?php _e('Single:', WPDEPOSIT_NAME); ?> <input class="required" type="text" size="20" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_points_name_single'), ''); ?>" name="inp_points_name_single" id="inp_points_name_single" /> 
            <?php _e('Plural:', WPDEPOSIT_NAME); ?> <input class="required" type="text" size="20" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_points_name_plural'), ''); ?>" name="inp_points_name_plural" id="inp_points_name_plural" /> 
            <small><?php _e('Change this if you wish to use another name than points. Eg: chips, depositos, ...'); ?><small>
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_currency"><?php _e('Currency:', WPDEPOSIT_NAME); ?></label>
        </td>
        <td>
        <select name="inp_currency" id="inp_currency">
            <?php foreach($currencies as $currency): ?>
                <?php $selected = (WPD_CURRENCY_CODE == $currency['code'])? 'selected=""' : ''; ?>
                <option value="<?php echo $currency['code']; ?>" <?php echo $selected; ?>><?php echo $currency['code'] . ' - ' . $currency['text']; ?></option>
            <?php endforeach; ?>
            <?php $selected = (get_option(WPDEPOSIT_NAME . '_currency') == 'other')? 'selected=""' : ''; ?>
            <option value="other" <?php echo $selected; ?>><?php _e('Other', WPDEPOSIT_NAME); ?></option>
        </select>
        <div class="other_payment">
            <p>
                <label for="inp_custom_currency_code"><?php _e('Currency code:', WPDEPOSIT_NAME); ?></label> 
                <input type="text" size="4" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_custom_currency_code'), ''); ?>" name="inp_custom_currency_code" id="inp_custom_currency_code" /> <small>(eg: USD)</small> 
            </p>
            <p>
                <label for="inp_custom_currency"><?php _e('Currency:', WPDEPOSIT_NAME); ?></label> 
                <input type="text" size="4" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_custom_currency'), ''); ?>" name="inp_custom_currency" id="inp_custom_currency" /> <small>(eg: $)</small>
            </p>
        </div>
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_currency_position"><?php _e('Currency position', WPDEPOSIT_NAME); ?>:</label>
        </td>
        <td>
        <select name="inp_currency_position" id="inp_currency_position">
            <?php $currencyPosition = get_option(WPDEPOSIT_NAME . '_currency_position'); ?>
            <option value="before" <?php echo ($currencyPosition == 'before')? 'selected=""' : '';; ?>><?php _e('Before', WPDEPOSIT_NAME); ?></option>
            <option value="after" <?php echo ($currencyPosition == 'after')? 'selected=""' : '';; ?>><?php _e('After', WPDEPOSIT_NAME); ?></option>
        </select>
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_company_name"><?php _e('Company Name:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<input class="required" type="text" size="80" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_company_name'), ''); ?>" name="inp_company_name" id="inp_company_name" />
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_company_address"><?php _e('Company Address:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<input class="required" type="text" size="80" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_company_address'), ''); ?>" name="inp_company_address" id="inp_company_address" />
            <br /><small>(<?php echo $pdfGenMessage; ?>)</small>
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_company_number"><?php _e('Company Number:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<input class="required number" type="text" size="80" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_company_number'), ''); ?>" name="inp_company_number" id="inp_company_number" />
            <br /><small>(<?php echo $pdfGenMessage; ?>)</small>
        </td>
    </tr>
        <tr>
        <td>
    <label for="inp_company_phone_number"><?php _e('Company Phone Number:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
    <input class="number" type="text" size="80" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_company_phone_number'), ''); ?>" name="inp_company_phone_number" id="inp_company_phone_number" />
            <br /><small>(<?php echo $pdfGenMessage; ?>)</small>
        </td>
    </tr>
    <tr>
        <td>
	<label for="inp_pdf_document_footer"><?php _e('PDF document footer:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<textarea rows="3" cols="72" name="inp_pdf_document_footer" id="inp_pdf_document_footer" ><?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_pdf_document_footer'), ''); ?></textarea>
            <br /><small>(<?php echo $pdfGenMessage . ' ' . __('The content of this field will be displayed in the footer of the generated pdf and can be used as disclaimer or any other information you wish to provide the user.', WPDEPOSIT_NAME); ?>)</small>
        </td>
    </tr>
    <tr>
        <td>
	<label for="success_page"><?php _e('Deposit Success page:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<?php wp_dropdown_pages( array('selected' => get_option(WPDEPOSIT_NAME . '_success_page'), 'name' => 'success_page') ); ?>
        </td>
    </tr>
    <tr>
        <td>
	<label for="cancel_page"><?php _e('Deposit Cancel page:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<?php wp_dropdown_pages( array('selected' => get_option(WPDEPOSIT_NAME . '_cancel_page'), 'name' => 'cancel_page') ); ?>
        </td>
    </tr>
    <tr>
        <td>
	<label for="failure_page"><?php _e('Deposit Failure page:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<?php wp_dropdown_pages( array('selected' => get_option(WPDEPOSIT_NAME . '_failure_page'), 'name' => 'failure_page') ); ?>
        </td>
    </tr>
    <tr>
        <td>
	<label for="expired_page"><?php _e('Deposit Expired page:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<?php wp_dropdown_pages( array('selected' => get_option(WPDEPOSIT_NAME . '_expired_page'), 'name' => 'expired_page') ); ?>
        </td>
    </tr>
    <tr>
        <td>
	<label for="open_page"><?php _e('Deposit open page:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<?php wp_dropdown_pages( array('selected' => get_option(WPDEPOSIT_NAME . '_open_page'), 'name' => 'open_page') ); ?>
        </td>
    </tr>
    <tr>
        <td>
	<label for="txt_confirm_deposit_message"><?php _e('Deposit confirm message:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
	<textarea class="required" name="txt_confirm_deposit_message" id="txt_confirm_deposit_message" rows="5" cols="72"><?php echo stripslashes(get_option( WPDEPOSIT_NAME . '_confirm_deposit_message')); ?></textarea>
        </td>
    </tr>
    <tr>
        <td>
    <label for="inp_custom_deposit_limit"><?php _e('Custom deposit amount limit:', WPDEPOSIT_NAME); ?></label> 
        </td>
        <td>
            <?php _e('Min', WPDEPOSIT_NAME) ?>: <input class="required number" type="text" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_custom_deposit_limit_minimum'), '0'); ?>" name="inp_custom_deposit_limit_minimum" id="inp_custom_deposit_limit_minimum" />
	        <?php _e('Max', WPDEPOSIT_NAME) ?>: <input class="required number" type="text" value="<?php echo $wpelements->set_value(get_option(WPDEPOSIT_NAME . '_custom_deposit_limit'), '0'); ?>" name="inp_custom_deposit_limit" id="inp_custom_deposit_limit" />
	        <br/>
	        <small><?php _e('0 for no limit.', WPDEPOSIT_NAME); ?></small>
	        <br/>
	        <small>
		        <?php _e('Users can specify a custom amount to deposit on their account. You can set here a limit to that amount.', WPDEPOSIT_NAME); ?>
	        </small>
        </td>
    </tr>
    <tr>
        <td colspan="2"><hr /></td>
    </tr>
    <tr>
        <td>
            <label for="<?php echo WPDEPOSIT_NAME; ?>_disable_styles"><?php _e('Disable plugin styles', WPDEPOSIT_NAME); ?>:</label> 
        </td>
        <td>
            <input type="checkbox" value="1" name="<?php echo WPDEPOSIT_NAME; ?>_disable_styles" <?php echo (WPDEPOSIT_DISABLE_STYLES)? 'checked' : '' ; ?> id="<?php echo WPDEPOSIT_NAME; ?>_disable_styles" />
        </td>
    </tr>
</table>
<p class="submit_block"><input type="submit" name="sbm_settings" value="<?php _e('Update Settings', WPDEPOSIT_NAME); ?>" id="sbm_settings" class="button-primary" />
</p>
<?php do_action('wpds_add_settings_fields'); ?>
<?php echo $wpelements->closeForm();  ?>
<script type="text/javascript" charset="utf-8">
jQuery(document).ready(function($) {
    <?php $currencyCode = get_option(WPDEPOSIT_NAME . '_currency'); ?>
    <?php if($currencyCode != 'other'): ?>
        $('.other_payment').hide();
    <?php endif; ?>
    $('#inp_currency').on('change', function(e){
        var selectedCurrency = e.currentTarget.value;
        if (selectedCurrency == 'other') {
            $('.other_payment').show();
        } else {
            $('.other_payment').hide();
        }
    });

    <?php if(isset($paymentOptions) && !empty($paymentOptions)): ?>
        paymentOptions = <?php echo json_encode($paymentOptions); ?>;
    <?php else: ?>
        paymentOptions = null;
    <?php endif; ?>
    var creditType = '<?php echo WPD_CREDIT_TYPE ?>';
    if(document.location.hash == '#convert_points') {
        convert_creditTypes(creditType, 'points', paymentOptions, 'convert_points_after_update');
    }

});
</script>
