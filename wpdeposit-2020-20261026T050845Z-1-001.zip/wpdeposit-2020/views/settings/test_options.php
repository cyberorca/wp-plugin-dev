<div class="feedback"></div><!-- .feedback -->
<?php echo $wpelements->openForm('', 'POST', false, 'wpdeposit_settings_form_test_options'); ?>
<table class="form-table">
    <tr>
        <td width="150">
            <label for="rad_test_mode"><?php _e('Test mode', WPDEPOSIT_NAME); ?>:</label>
        </td>
        <td>
            <?php if($wpelements->if_selected(get_option(WPDEPOSIT_NAME . '_test_mode'))): ?>
                <input type="radio" name="rad_test_mode" id="rad_test_mode" checked value="1" /> <?php _e('On', WPDEPOSIT_NAME); ?>
                <input type="radio" name="rad_test_mode" id="rad_test_mode" value="0" /> <?php _e('Off', WPDEPOSIT_NAME); ?>
            <?php else: ?>
                <input type="radio" name="rad_test_mode" id="rad_test_mode" value="1" /> <?php _e('On', WPDEPOSIT_NAME); ?>
                <input type="radio" name="rad_test_mode" id="rad_test_mode" checked value="0" /> <?php _e('Off', WPDEPOSIT_NAME); ?>
            <?php endif; ?>
        </td>
    </tr>
</table>
<p class="submit_block">
    <input type="submit" name="sbm_settings" value="<?php _e('Update Settings', WPDEPOSIT_NAME); ?>" id="sbm_settings" class="button-primary" />
</p>
<h2><?php _e('Deposit test options', WPDEPOSIT_NAME); ?></h2>
<p>
    <a href="#" class="button-primary test-balance" data-test-type="increment">Test Increment Balance</a>&nbsp;&nbsp; / &nbsp;&nbsp;<a href="#" class="button-primary test-balance" data-test-type="decrement">Test Decrement Balance</a>
</p>
<p><?php _e('Your balance', WPDEPOSIT_NAME); ?>: <span class="balance_text"><?php echo the_credit_type_text(true, null, true); ?></span></p>

<?php echo $wpelements->closeForm();  ?>