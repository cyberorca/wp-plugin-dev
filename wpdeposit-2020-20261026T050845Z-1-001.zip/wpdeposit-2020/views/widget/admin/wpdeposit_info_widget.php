<div class="wpdeposit-admin-widget">
	<ul>
		<li class="stats-block stat-deposits">
			<span class="stat-icon">
				<img src="<?php echo WPDEPOSIT_URL; ?>/resources/images/stats.png" alt="Total deposits" />
			</span>
			<span class="stat-info"><span class="stat-amount"><?php echo $totalCount->total; ?></span> Total Deposits</span>
		</li>
		<li class="stats-block stat-total-amount stat-block-right">
			<span class="stat-icon">
				<img src="<?php echo WPDEPOSIT_URL; ?>/resources/images/piggy_bank.png" alt="Total deposits" />
			</span>
			<span class="stat-info"><span class="stat-amount"><?php echo WPD_CURRENCY; ?><?php echo $totalDeposits->total_amount; ?></span> Total Deposited</span>
		</li>
	</ul>
</div>