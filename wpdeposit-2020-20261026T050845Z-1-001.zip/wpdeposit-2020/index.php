<?php
/*
  Plugin Name: WP Deposit system
  Plugin URI: http://codecanyon.net/item/wpdeposit/500402
  Description: This plugin allows your to run a deposit system on your wordpress machine including several payment gateways
  Author: uWebic
  Version: 1.10.1
  Author URI: http://uwebic.com
 */

//Define the version of the plugin. used to check for updates and other
define('WPDEPOSIT_VERSION', '1.10.1');

//Define a list of currencies for the user
$currencies = array(
    'EUR' => array('code' => 'EUR', 'text' => 'Euros', 'sign' => '€'),
    'AUD' => array('code' => 'AUD', 'text' => 'AUD - Australian Dollars', 'sign' => '$'),
    'BRL' => array('code' => 'BRL', 'text' => 'BRL - Brazilian Reais', 'sign' => 'R$'),
    'GBP' => array('code' => 'GBP', 'text' => 'GBP - British Pounds', 'sign' => '£'),
    'CAD' => array('code' => 'CAD', 'text' => 'CAD - Canadian Dollars', 'sign' => '$'),
    'CZK' => array('code' => 'CZK', 'text' => 'CZK - Czech Koruny', 'sign' => 'Kč'),
    'DKK' => array('code' => 'DKK', 'text' => 'DKK - Danish Kroner', 'sign' => 'kr'),
    'HKD' => array('code' => 'HKD', 'text' => 'HKD - Hong Kong Dollars', 'sign' => '$'),
    'HUF' => array('code' => 'HUF', 'text' => 'HUF - Hungarian Forints', 'sign' => 'Ft'),
    'ILS' => array('code' => 'ILS', 'text' => 'ILS - Israeli New Shekels', 'sign' => '₪'),
    'JPY' => array('code' => 'JPY', 'text' => 'JPY - Japanese Yen', 'sign' => '¥'),
    'MYR' => array('code' => 'MYR', 'text' => 'MYR - Malaysian Ringgit', 'sign' => 'RM'),
    'MXN' => array('code' => 'MXN', 'text' => 'MXN - Mexican Pesos', 'sign' => '$'),
    'TWD' => array('code' => 'TWD', 'text' => 'TWD - New Taiwan Dollars', 'sign' => '$'),
    'NZD' => array('code' => 'NZD', 'text' => 'NZD - New Zealand Dollars', 'sign' => '$'),
    'NOK' => array('code' => 'NOK', 'text' => 'NOK - Norwegian Kroner', 'sign' => 'kr'),
    'PHP' => array('code' => 'PHP', 'text' => 'PHP - Philippine Pesos', 'sign' => '₱'),
    'PLN' => array('code' => 'PLN', 'text' => 'PLN - Polish Zlotys', 'sign' => 'zł'),
    'SGD' => array('code' => 'SGD', 'text' => 'SGD - Singapore Dollars', 'sign' => '$'),
    'SEK' => array('code' => 'SEK', 'text' => 'SEK - Swedish Kronor', 'sign' => 'kr'),
    'CHF' => array('code' => 'CHF', 'text' => 'CHF - Swiss Francs', 'sign' => 'Fr'),
    'THB' => array('code' => 'THB', 'text' => 'THB - Thai Baht', 'sign' => '฿'),
    'TRY' => array('code' => 'TRY', 'text' => 'TRY - Turkish Liras', 'sign' => 'kr'),
    'USD' => array('code' => 'USD', 'text' => 'U.S. Dollars', 'sign' => '$'),
);

/**
 * Define the basic name, shortname, path, currency code , .....
 */

define('WPDEPOSIT_NAME', 'wpdeposit');
if (!defined('WPDEPOSIT_PATH')) {
    define('WPDEPOSIT_PATH', dirname(__FILE__));
}
define('POINTS_NAME_SINGLE', get_option(WPDEPOSIT_NAME . '_points_name_single'));
define('POINTS_NAME_PLURAL', get_option(WPDEPOSIT_NAME . '_points_name_plural'));
define('WPDEPOSIT_URL', plugins_url($path = '/' . WPDEPOSIT_NAME));
$currencyCode = get_option(WPDEPOSIT_NAME . '_currency');
if (isset($currencyCode) && $currencyCode != null && $currencyCode != '' && isset($currencies[$currencyCode]['code'])) {
    define('WPD_CURRENCY', $currencies[$currencyCode]['sign']);
    define('WPD_CURRENCY_CODE', $currencyCode);
} elseif(isset($currencyCode) && $currencyCode != null && $currencyCode != '' && $currencyCode == 'other') {
    define('WPD_CURRENCY', get_option(WPDEPOSIT_NAME . '_custom_currency'));
    define('WPD_CURRENCY_CODE', get_option(WPDEPOSIT_NAME . '_custom_currency_code'));
} else {
    define('WPD_CURRENCY', '$');
    define('WPD_CURRENCY_CODE', 'USD');
}
define('WPD_CREDIT_TYPE', get_option(WPDEPOSIT_NAME . '_credit_type'));
define('DEPOSIT_LIMIT_AMOUNT', get_option(WPDEPOSIT_NAME . '_custom_deposit_limit'));

$depositStyles = get_option(WPDEPOSIT_NAME . '_disable_styles');
$depositStyles = ($depositStyles == 'on')? true : false ;
define('WPDEPOSIT_DISABLE_STYLES', $depositStyles);

if(WPD_CREDIT_TYPE == 'points') {
    define('WPD_SHOW_POINT_FIELDS', true);
} else {
    $showPointFields = get_option(WPDEPOSIT_NAME . '_show_point_fields');
    $showPointFields = ($showPointFields == 'on')? true : false ;
    define('WPD_SHOW_POINT_FIELDS', $showPointFields);
}


/**
 * Donation e-mail settings
 */
$option = get_option(WPDEPOSIT_NAME . '_user_donation_content_enable');
$option = ($option == 'on')? true : false ;
define('WPDEPOSIT_ENABLE_USER_ENABLE', $option);
define('WPDEPOSIT_USER_DONATION_MAIL', get_option(WPDEPOSIT_NAME . '_user_donation_email_content'));

$option = get_option(WPDEPOSIT_NAME . '_admin_donation_content_enable');
$option = ($option == 'on')? true : false ;
define('WPDEPOSIT_ENABLE_ADMIN_ENABLE', $option);
define('WPDEPOSIT_ADMIN_DONATION_MAIL', get_option(WPDEPOSIT_NAME . '_admin_donation_email_content'));

define('LOG_DEPOSITS', get_option(WPDEPOSIT_NAME . '_DEPOSIT_LOG'));

// withdrawal can NEVER be enabled if points is enabled
if (WPD_CREDIT_TYPE == 'points') {
    require_once WPDEPOSIT_PATH . '/models/withdrawal.php';
    define('WPDEPOSIT_WITHDRAWALS', WithdrawalModel::SETTING_DISABLED);
} else {
    define('WPDEPOSIT_WITHDRAWALS', get_option(WPDEPOSIT_NAME . '_WITHDRAWALS_SETTING'));
}


/**
 * Add/Load translation
 */
add_action('plugins_loaded', 'wpdeposit_localization');
function wpdeposit_localization() {
    load_plugin_textdomain(WPDEPOSIT_NAME, false, dirname( plugin_basename( __FILE__ ) ) . '/lang/');
}

/**
 * Function to show the user balance based on given parameters.
 *
 */
function the_credit_type_text($cap = false, $amount = null, $currency = false){
    $controller = new UserController;
    if($amount === null) {
        $amount = $controller->getBalanceInfo();
    }
    if (WPD_CREDIT_TYPE == 'money') {
        if ($currency) {
            $position = get_option(WPDEPOSIT_NAME . '_currency_position');

            if (!isset($position) || empty($position)) {
                $position = 'before';
            }
            if ($position == 'before'){
                return WPD_CURRENCY . $amount;
            } elseif ($position == 'after') {
                return $amount . WPD_CURRENCY;
            }
        } else {
            $amount = (!empty($amount) && $amount != '')? $amount . ' ' : '' ;
            if($cap){
                return $amount . ' ' . WPD_CURRENCY_CODE;
            } else {
                return $amount . ' ' . strtolower(WPD_CURRENCY_CODE);
            }
        }
    } else {
        if ($cap) {
            return  $amount . ' ' . POINTS_NAME_PLURAL;
        } else {
            return $amount . ' ' . POINTS_NAME_PLURAL;
        }
    }
}

require_once "classes/wp-deposit.php";
$wpdeposit = new WPdeposit();
add_action('plugins_loaded', array($wpdeposit, 'woocommerce_wpdeposit_init'));

//temporarily add support for the function name
function show_deposit_balance()
{
	global $wpdeposit;
	$wpdeposit->shortcodes->show_deposit_balance();
}
