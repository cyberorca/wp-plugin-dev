<?php
include_once  WPDEPOSIT_PATH . '/controllers/abstract.php';

class WPD_Payment_Gateways extends wpdepositAbstractController {
    
    /**
     *
     * @var array 
     */
    public $_gatewayList = array();
    
    
    /**
     * Initialize
     * @return array 
     */
    public function init() {
        do_action('wpds_init_payment_gateways_before');
        //load payment gateways
        $this->_gatewayList = apply_filters('wpdeposit_payment_gateways', $this->_gatewayList);
        foreach ($this->_gatewayList as $gateway) :
            $load_gateway = new $gateway();
        endforeach;
        do_action('wpds_init_payment_gateways_after');
        return $this->_gatewayList;
    }
    
    /**
     * Get the active PG's
     * @return array
     */
    public function getPaymentGateways(){
        do_action('wpds_get_payment_gateways_before');
        $gatewayList = array();
        foreach($this->_gatewayList as $gateway){
            if($gateway->active == 1){
                $gatewayList[] = $gateway;
            }
        }
        do_action('wpds_get_payment_gateways_after');
        return $gatewayList;
    }
    
    public function generateAdminHtml(){
        $wpelements = new WP_elements();
        $this->_gatewayList = apply_filters('wpdeposit_payment_gateways', array());
        $pgAdminSettings = '';
        foreach ($this->_gatewayList as $gateway) :
            /**
             * Create new instances of the PG classes
             */
            $load_gateway = new $gateway();
            
            /**
             * Check if the required methods exist
             */
            $this->_checkRequiredMethodsExist($load_gateway, $gateway);
            
            if (method_exists($load_gateway, 'getFormFields')) {
                $formFieldsExist = true;
                //filter through forms
                $formFields = $this->_constructFormFields($load_gateway->getFormFields());
            }
            
            /**
             * Get required info from the PG class
             */
            $icon = $load_gateway->getIcon();
            $gatewayName = $load_gateway->getGatewayName();
            
            /**
             * Mark gateway as checked if it is active if not disabled the form fields
             */
            $checked = ($wpelements->if_checked(get_option(WPDEPOSIT_NAME . '_gateway_' . $gatewayName)))? 'checked' : '';
            
            /**
             * Construct PG html block
             */
            $pgAdminSettings .= '<div id="' . $gatewayName . '_gateway_settings" class="gateway_block">';
                $pgAdminSettings .= '<div class="gateway_block_inner">';
                    $pgAdminSettings .= '<span class="arrow_open" id="' . $gatewayName . '_gateway_settings_arrow" title="click to open"></span>';
                    $pgAdminSettings .= '<p>';
                        $pgAdminSettings .= '<input type="checkbox" class="checkbox gateway_active_checkbox" name="' . $gatewayName . '_active" value="checked" ' . $checked . ' id="' . $gatewayName . '_active" /> ';
                        $pgAdminSettings .= '<img src="' . $icon . '" alt="' . $gatewayName . '" title="' . $gatewayName . '" />';
                    $pgAdminSettings .= '</p>';
                    $pgAdminSettings .= '<div class="gateway_info" id="' . $gatewayName . '_gateway_info">';
                        $pgAdminSettings .= '<table class="form-table">';
                            if ($formFieldsExist) {
                                $pgAdminSettings .= $formFields;
                            }
                        $pgAdminSettings .= '</table>';
                    $pgAdminSettings .= '</div>';
                $pgAdminSettings .= '</div>';
            $pgAdminSettings .= '</div>';
        endforeach;
        return $pgAdminSettings;
    }
    
    public function generateFrontendHtml(){
        $this->_gatewayList = apply_filters('wpdeposit_payment_gateways', array());
        $gatewaysHtml = '';
        foreach ($this->_gatewayList as $gateway) :
            $load_gateway = new $gateway();
            $this->_checkRequiredMethodsExist($load_gateway, $gateway);
            $icon = $load_gateway->getIcon();
            $gatewayName = $load_gateway->getGatewayName();
            /**
             * check if the PG is active
             */
            if (get_option(WPDEPOSIT_NAME . '_gateway_' . $gatewayName) == 'checked'): //check if active 
                $gatewaysHtml .= '<input type="radio" id="' . $gatewayName . '" value="' . $gateway . '" name="payment_gateway" class="payment_gateway" checked>';
                $gatewaysHtml .= '<label for="' . $gatewayName . '"><img title="' . $gatewayName . '" alt="' . $gatewayName . '" src="' . $icon . '"></label>';
            endif;
        endforeach;
        htmlentities($gatewaysHtml);
        return $gatewaysHtml;
    }
    
    /**
     * Quick function to check if the basic required method exists in the PG class
     * @param object $class
     * @param string $gateway
     * @return type 
     */
    private function _checkRequiredMethodsExist($class, $gateway)
    {
        /**
         * check if the PG class has a method getIcon
         */
        if (!method_exists($class, 'getIcon')) {
            return '<strong>Error:</strong>The payment gateway class ' . $gateway . ' is missing the getIcon() method!';
        }
        /**
         * check if the PG class has a method getGatewayName
         */
        if (!method_exists($class, 'getGatewayName')) {
            return '<strong>Error:</strong>The payment gateway class ' . $gateway . ' is missing the getGatewayName() method!';
        }
    }
    
    public function _constructFormFields($fields)
    {
        do_action('wpds_construct_form_fields_before', $fields);
        $formFields = '';
        if (is_array($fields['fields'])) {
            foreach($fields['fields'] as $field){
                $formFields .= $this->_constructFormFieldType($field);
            }
        } else {
            $formFields = '<p>' . __('No form fields provided for this Payment Gateway', WPDEPOSIT_NAME) . '</p>';
        }
        do_action('wpds_construct_form_fields_after', $fields);
        return $formFields;
    }
    
    public function _constructFormFieldType($field)
    {
        /**
         * Still check if we actually get an array
         */
        if ($field) {
            /**
             * Check if there are extra options for the field and save in a variable
             */
            $extraOptions = $this->_filterExtraOptions($field);
            
            /**
             * Check which field type is requested and build html
             */
            switch($field['type']){
                case 'textfield':
                    $formField = '<tr>';
                        $formField .= '<td>';
                            $formField .= '<label for="' . $field['name'] . '">' . $field['label'] . '</label>';
                            $formField .= '</td><td>';
                            $formField .= ' <input type="text" name="' . $field['name'] . '" value="' . get_option(WPDEPOSIT_NAME . '_' . $field['name']) . '" id="' . $field['name'] . '" ' . $extraOptions . ' />';
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
                case 'uploadfile':
                    $currentFile = get_option(WPDEPOSIT_NAME . '_' . $field['name']);
                    $formField = '<tr>';
                        $formField .= '<td>';
                            $formField .= '<label for="' . $field['name'] . '">' . $field['label'] . '</label>';
                            $formField .= '</td><td>';
                            $formField .= '<input type="file" name="' . $field['name'] . '" id="' . $field['name'] . '" ' . $extraOptions . ' />';
                            $formField .= '<div id="' . $field['name'] . '_info">';
                                if(!empty($currentFile) && file_exists($field['uploadpath'] . $currentFile)):
                                    $formField .= '<p class="current_file">' . __('Current file', WPDEPOSIT_NAME) . ': ' . $currentFile . '</p>';
                                else:
                                    $formField .= '<p>' . __('No file uploaded yet.', WPDEPOSIT_NAME) . '</p>';
                                endif;  
                            $formField .= '</div>';
                            $formField .= '<script type="text/javascript">';
                            $formField .= 'jQuery(document).ready(function($) {';
                                $formField .= '$(\'#' . $field['name'] . '\').uploadify({';
                                    $formField .= '\'uploader\'  : \'' . WPDEPOSIT_URL . '/resources/js/lib/uploadify/uploadify.swf\',';
                                    $formField .= '\'script\'    : \'' . WPDEPOSIT_URL . '/includes/uploadify.php\',';
                                    $formField .= '\'cancelImg\' : \'' . WPDEPOSIT_URL . '/resources/images/cancel.png\',';
                                    $formField .= '\'folder\'    : \'' . $field['uploadpath'] . '\',';
                                    $formField .= '\'auto\'      : true,';
                                        $formField .= '\'fileExt\'	: \'' . $field['extention'] . '\',';
                                        $formField .= '\'buttonText\': \'' . $field['btn_name'] . '\',';
                                        $formField .= '\'method\'	: \'post\',';
                                        $formField .= '\'onError\'     : function (event,ID,fileObj,errorObj) {';
                                       $formField .= ' console.log(errorObj.type + \' Error: \' + errorObj.info);';
                                    $formField .= '},';
                                        $formField .= '\'onComplete\': function(event, ID, fileObj, response, data) {';
                                                $formField .= 'var r = eval(\'(\' + response + \')\');';
                                                $formField .= 'var filename = r.file_data.basename;';
                                                $formField .= 'var data = {action: \'setting_add_image\', ' . $field['name'] . ': filename};';
                                                $formField .= 'jQuery.post(';
                                                    $formField .= 'ajaxurl,';
                                                    $formField .= 'data,';
                                                    $formField .= 'function(response){';
                                                        $formField .= 'if (response.success) {';
                                                                $formField .= 'jQuery(\'.feedback\').html(\'<div class="updated" id="message"><p>\' + response.message + \'</p></div>\').fadeIn();';
                                                                $formField .= 'jQuery(\'#' . $field['name'] . '_info\').html(\'<p class="current_file">' . __('Current file', WPDEPOSIT_NAME) . ': \' + filename + \'</p>\');';
                                                        $formField .= '} else {';
                                                                $formField .= 'jQuery(\'.feedback\').html(\'<div class="error" id="message"><p>\' + response.message + \'</p></div>\').fadeIn();';
                                                        $formField .= '}';
                                                    $formField .= '}';
                                                $formField .= ');';
                                    $formField .= '}';
                                $formField .= '});';
                            $formField .= '});';
                            $formField .= '</script>';
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
                case 'radio':
                    $getFieldStatus = get_option(WPDEPOSIT_NAME . '_' . $field['name']);
                    $formField = '';
                    $formField .= '<tr>';
                        $formField .= '<td>';
                        $i = 1;
                            foreach($field['radio_options'] as $radio):
                                $checked = '';
                                $extraOptions = $this->_filterExtraOptions($radio);
                                if ($getFieldStatus == $radio['value'] || (empty($getFieldStatus) && $i == 1)):
                                    $checked = 'checked';
                                endif;
                                $formField .= '<label for="' . $radio['value'] . '">' . $radio['label'] . '</label>';
                                $formField .= ' <input type="radio" ' . $checked . ' name="' . $field['name'] . '" value="' . $radio['value'] . '" id="' . $radio['value'] . '" ' . $extraOptions . ' />';
                                $formField .= '&nbsp;&nbsp;&nbsp;';
                                $i++;
                            endforeach;
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
                case 'checkbox':
                    $getFieldStatus = get_option(WPDEPOSIT_NAME . '_' . $field['name']);
                    $checked = ($getFieldStatus == 'checked')? 'checked' : '' ;
                    $formField = '<tr>';
                        $formField = '<td>';
                            $formField .= '<label for="' . $field['name'] . '">' . $field['label'] . '</label>';
                            $formField .= '</td><td>';
                            $formField .= ' <input type="checkbox" ' . $checked . ' name="' . $field['name'] . '" value="checked" id="' . $field['name'] . '" ' . $extraOptions . ' />';
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
                case 'textarea':
                    $textareaContent = get_option(WPDEPOSIT_NAME . '_' . $field['name']);
                    $textareaContent = (isset($field['default_content'] ) && !empty($field['default_content'] ))? $field['default_content'] : $textareaContent ;
                    $formField = '<tr>';
                        $formField = '<td>';
                            $formField .= '<label for="' . $field['name'] . '">' . $field['label'] . '</label>';
                            $formField .= '</td><td>';
                            $formField .= ' <textarea name="' . $field['name'] . '" id="' . $field['name'] . '" ' . $extraOptions . ' >' . $textareaContent . '</textarea>';
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
                case 'title':
                    $headingType = (isset($field['headingtype']) && !empty($field['headingtype']))? $field['headingtype'] : 'h2' ;
                    $headingText = (isset($field['text']) && !empty($field['text']))? $field['text'] : '-' ;
                    $formField = '<tr>';
                        $formField = '<td colspan="2">';
                            $formField .= '<' . $headingType . '>' . $field['text'] . '</' . $headingType . '>';
                        $formField .= '</td>';
                    $formField .= '</tr>';
                break;
            }
        }
        return $formField;
    }
    
    public function _filterExtraOptions($field)
    {
        $extraOptions = '';
        if (isset($field['extra_options']) && is_array($field['extra_options'])) {
            foreach($field['extra_options'] as $attribute => $value)
            {
                $extraOptions .= ' ' . $attribute . '="' . $value . '"';
            }
        }
        return $extraOptions;
    }

}// end of class