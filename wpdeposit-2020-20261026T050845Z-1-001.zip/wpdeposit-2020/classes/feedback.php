<?php

class feedback {
    
    const ADVERTISEMENT_ADDED       = 100;
    const ADVERTISEMENT_EXTENDED    = 110;
    const SUBSCRIPTION_ADDED        = 120;
    
    public static function getMessage($code)
    {
        $messages = array (
            self::ADVERTISEMENT_ADDED => 'Advertisement added successfully.',
            self::ADVERTISEMENT_EXTENDED => 'Advertisement extended successfully.',
            self::SUBSCRIPTION_ADDED => 'Subscription added successfully.',
        );
        
        return (isset($messages[$code]) ? $messages[$code] : '');
    }
    
}