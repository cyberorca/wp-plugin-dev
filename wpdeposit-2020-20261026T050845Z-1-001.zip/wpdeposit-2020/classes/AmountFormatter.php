<?php

class AmountFormatter {

	public function validateAmount($amount)
	{
		$newAmount = str_replace(' ', '', $amount);
		$posPoint = stripos($amount, '.');
		$posComma = stripos($amount, ',');
		if ($posComma !== FALSE && $posPoint !== FALSE) {
			if ($posPoint > $posComma) {
				//1,000.OO
				$newAmount = str_replace(',', '', $newAmount);
			} elseif($posComma > $posPoint) {
				//1.000,00
				$newAmount = str_replace('.', '', $newAmount);
				$newAmount = str_replace(',', '.', $newAmount);
			}
		} elseif($posComma !== FALSE) {
			//19,99
			$newAmount = str_replace(',', '.', $newAmount);
		}
		//other do not require modifications. eg: 20 or 20.99
		return $newAmount;
	}
} 