<?php

include_once  WPDEPOSIT_PATH . '/controllers/abstract.php';
class WPD_Payment_Gateway extends wpdepositAbstractController {
    
    /** @var string Gateway Name. */
    public $id;

    /** @var string Gateway Icon. */
    public $icon;

    /** @var string Description for the gateway. */
    public $description;
    
    public function __construct() {
        parent::__construct();
    }

    /**
     * Process Payment
     *
     * Process the payment. Override this in your gateway.
     *
     * @access public
     * @return void
     */
    public function process_payment() {}

}// end of class