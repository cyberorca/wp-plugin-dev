<?php
/**
* Simple Class to log messages to a file. It can be used for example for debuging.
*/

if (!class_exists('WpdepositActionLogger')) {
    class WpdepositActionLogger {

        public $logFilePath = '';
        
        public function __construct($pathName)
        {
            $this->logFilePath = $pathName;
        }

        public function log($message, $type = 'log')
        {
            if (LOG_DEPOSITS || LOG_DEPOSITS == 1) {
                //check if message is not empty
                if (empty($message)) {
                        throw new exception('Log message cannot be empty');
                }

                //create/open file
                $fp = fopen($this->logFilePath, 'a');

                //write message to log file
                fwrite($fp, '[' . strtoupper($type) . '] ' . date('d M Y h:i:s', time()) . ' - ' . $message . "\n");

                //close file
                fclose($fp);
            }
            return true;
        }
    }//end of class
}