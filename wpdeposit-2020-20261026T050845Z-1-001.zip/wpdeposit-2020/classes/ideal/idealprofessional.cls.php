<?php

	// Load iDEAL settings
	if(file_exists(dirname(__FILE__) . '/idealprofessional.cfg.php'))
	{
		require_once(dirname(__FILE__) . '/idealprofessional.cfg.php');
	}

	// Load iDEAL classes
	if(version_compare(PHP_VERSION, '5', '<'))
	{
		require_once(dirname(__FILE__) . '/idealprofessional.cls.4.php');
	}
	else
	{
		require_once(dirname(__FILE__) . '/idealprofessional.cls.5.php');
	}

?>