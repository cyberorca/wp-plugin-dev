<?php
if (get_option(WPDEPOSIT_NAME . '_test_mode') == '1') {
	define('IDEAL_AQUIRER', 'Simulator');
	define('IDEAL_TEST_MODE', true);
	define('IDEAL_MERCHANT_ID', '123456789');
	define('IDEAL_PRIVATE_KEY', 'Password');
} else {
	define('IDEAL_AQUIRER', get_option(WPDEPOSIT_NAME . '_ideal_aquirer'));
	define('IDEAL_TEST_MODE', false);
	define('IDEAL_MERCHANT_ID', get_option(WPDEPOSIT_NAME . '_ideal_merchant_id'));
	define('IDEAL_PRIVATE_KEY', get_option(WPDEPOSIT_NAME . '_ideal_private_key'));
}
define('IDEAL_CACHE_PATH', dirname(__FILE__) . '/cache/');
define('IDEAL_PRIVATE_CERTIFICATE_FILE', 'private.cer'); 
define('IDEAL_PRIVATE_KEY_FILE', 'private.key');
define('IDEAL_RETURN_URL', '');
define('IDEAL_SECURE_PATH', dirname(__FILE__) . '/ssl/');
define('IDEAL_SUB_ID', '0');