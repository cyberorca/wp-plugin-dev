<?php
/**
 * Main class for the WPdeposit
 */
require_once WPDEPOSIT_PATH . '/classes/abstract.php';
require_once WPDEPOSIT_PATH . '/lib/validation.php';
require_once WPDEPOSIT_PATH . '/lib/wpelements/wp_elements.php';
require_once WPDEPOSIT_PATH . '/classes/logger.class.php';
require_once WPDEPOSIT_PATH . '/lib/uploader.php';
require_once WPDEPOSIT_PATH . '/classes/wpd_payment_gateways.php';
require_once WPDEPOSIT_PATH . '/classes/wpd_payment_gateway.php';
require_once WPDEPOSIT_PATH . '/classes/AmountFormatter.php';
require_once WPDEPOSIT_PATH . '/controllers/api/rajabiller.php'; // api - doni
require_once WPDEPOSIT_PATH . '/controllers/api_rajabiller.php'; // api - doni
require_once WPDEPOSIT_PATH . '/controllers/admin/payment_options.php';
require_once WPDEPOSIT_PATH . '/controllers/settings_options.php';
require_once WPDEPOSIT_PATH . '/controllers/shortcodes.php';
require_once WPDEPOSIT_PATH . '/controllers/filters.php';
require_once WPDEPOSIT_PATH . '/controllers/gateways/paypal_options.php';
require_once WPDEPOSIT_PATH . '/controllers/gateways/authorize_options.php';
require_once WPDEPOSIT_PATH . '/controllers/gateways/bank_options.php';
require_once WPDEPOSIT_PATH . '/controllers/gateways/ideal_options.php';
require_once WPDEPOSIT_PATH . '/controllers/gateways/woocommerce.php';
require_once WPDEPOSIT_PATH . '/controllers/deposit_options.php';
require_once WPDEPOSIT_PATH . '/controllers/point_options.php';
require_once WPDEPOSIT_PATH . '/controllers/user.php';
require_once WPDEPOSIT_PATH . '/controllers/transaction.php';
require_once WPDEPOSIT_PATH . '/controllers/withdrawal.php';
require_once WPDEPOSIT_PATH . '/controllers/admin/system.php';
require_once WPDEPOSIT_PATH . '/controllers/admin/pages.php';
require_once WPDEPOSIT_PATH . '/controllers/updates.php';
require_once WPDEPOSIT_PATH . '/controllers/rewards.php';
require_once WPDEPOSIT_PATH . '/controllers/credit_convertion.php';
require_once WPDEPOSIT_PATH . '/controllers/woocommerce.php';
require_once WPDEPOSIT_PATH . '/controllers/adminwidget.php';
require_once WPDEPOSIT_PATH . '/controllers/widgets.php';
require_once WPDEPOSIT_PATH . '/controllers/ajax.php';

class WPdeposit extends AbstractWPdepositClass {

    const MOD_ADVERTISEMENT = 'wpd-advertisements';
    const MOD_SUBSCRIPTION  = 'wpd-subscription';
    const MOD_SHOPPER       = 'wpd-shopper';
    const MOD_PAYPERPOST    = 'wpd-payperpost';
    const MOD_PAYPERVIEW    = 'wpd-payperview';
    const MOD_QA            = 'wpd-qa';
    
    /**
     * @var object 
     */
    public $_gatewaysClass;
    
    /**
     * @var array
     */
    public $wpdepositPages = array(
        'page=wpdeposit_plugin',
        'page=wpdeposit_deposits',
        'page=wpdeposit_payment_option_plugin',
        'page=wpdeposit_transactions',
        'page=wpdeposit_withdrawals',
        'page=wpdeposit_system',
        'page=wpdeposit_reward_system',
        'page=wpdeposit_add_ons',
    );

    public function __construct()
    {
        /**
         * init wpdeposit class
         */
        add_action( 'init', array( &$this, 'init' ), 0 );
        
        /**
         * run function when the plugin is activated
         */
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));

        /**
         * Register the widgets for the plugin
         */
	    $WPDWidgets = new WPdepositWidgets();
	    $WPDAdminWidgets = new WPdepositAdminWidgets();
        add_action("widgets_init", array($WPDWidgets, 'register_widgets'));
	    add_action( 'wp_dashboard_setup', array($WPDAdminWidgets, 'wpdeposit_info') );

        // Loaded action
        do_action( 'wpdeposit_loaded' );
    }

    /**
     * Setup the plugin
     */
    public function init()
    {
        //Class instances
        $this->_gatewaysClass = new WPD_Payment_Gateways();
        //Init payment gateways
        $this->_gatewaysClass->init();
        //add reward
	    //@todo probleem met rewards bij het registreren
        $rewards = new RewardsController();
        if (defined('DOING_AJAX') && DOING_AJAX) {
	        $ajaxController = new WPdepositAjax();
	        $ajaxController->registerAjaxRequests();
        } else {
            //add menu and resources
            add_action('admin_menu', array($this, 'load_menu'));
            add_action('init', array($this, 'loadAdminResources'));
			$this->shortcodes = new WPdepositShortcodes();
			$this->filters = new WPdepositFilters();
            add_action('init', array($this, 'loadFrontScripts'));
            if (!WPDEPOSIT_DISABLE_STYLES)
            {
                add_action('wp_head', array($this, 'loadFrontStyles'));
            }
            //check if admin
            if (is_super_admin())
            {
	            $WPDWidgets = new WPdepositWidgets();
                //register_activation_hook does not work with automatic updates so we check version on each admin page load
                $obj = new updatesController();
                $obj->checkPointConvertion();
                $obj->checkVersion();
                //add extra profile options and update options for those fields (only for admin eyes)
                add_action( 'show_user_profile', array($WPDWidgets, 'wpd_show_extra_profile_fields' ));
                add_action( 'edit_user_profile', array($WPDWidgets, 'wpd_show_extra_profile_fields' ));
	            add_action( 'personal_options_update', array($WPDWidgets, 'wpd_save_extra_profile_fields' ));
	            add_action( 'edit_user_profile_update', array($WPDWidgets, 'wpd_save_extra_profile_fields' ));
            }
        }
        
    }
    
    public function allowedLoadResource()
    {
        if (isset($_GET['page']) && (preg_match('/^wpd\-/', $_GET['page']) || preg_match('/^wpdeposit\_/', $_GET['page'])))
        {
            //also allow add-ons as they required certain resources from the main plugin like the simple tab script for the settings page, ... etc
            return true;
        }
        return false;
    }
    
    /**
     * function to include resources in the admin head
     *
     * @return void
     * */
    public function loadAdminResources()
    {
        if ($this->allowedLoadResource() && is_admin())
        {
            //enqueue jquery
            wp_enqueue_script("jquery");
            wp_enqueue_script('jquery-ui-dialog');
	        //wp_register_script(WPDEPOSIT_NAME . '_admin_js', );
	        wp_enqueue_script(
		        WPDEPOSIT_NAME . '_admin_js',
		        WPDEPOSIT_URL . '/public/js/admin.js',
		        array('underscore', 'backbone'),
		        WPDEPOSIT_VERSION,
		        true
	        );


	        /*
	        wp_enqueue_script(WPDEPOSIT_NAME . '_jquery.validate');
	        wp_enqueue_script(WPDEPOSIT_NAME . '_simpletab');
	        wp_enqueue_script(WPDEPOSIT_NAME . '_swfobject');
	        wp_enqueue_script(WPDEPOSIT_NAME . '_uploadify_script');
	        wp_enqueue_script(WPDEPOSIT_NAME . '_qtip_script');
	        wp_register_script(WPDEPOSIT_NAME . '_simpletab', WPDEPOSIT_URL . '/resources/js/js_snippet/simpleTab.js');
	        wp_register_script(WPDEPOSIT_NAME . '_swfobject', WPDEPOSIT_URL . '/resources/js/uploadify/swfobject.js');
	        wp_register_script(WPDEPOSIT_NAME . '_uploadify_script', WPDEPOSIT_URL . '/resources/js/uploadify/jquery.uploadify.v2.1.4.min.js');
	        wp_register_script(WPDEPOSIT_NAME . '_qtip_script', WPDEPOSIT_URL . '/resources/js/jquery.qtip.min.js');
	        wp_register_script(WPDEPOSIT_NAME . '_jquery.validate', WPDEPOSIT_URL . '/resources/js/jquery.validate.min.js');
	        */

            $data = array(
                'wpd_credit_type' => WPD_CREDIT_TYPE,
            );
            wp_localize_script(WPDEPOSIT_NAME . '_admin_js', 'php_data', $data);

	        //@todo move translations for js in other file/function
	        $trans = array(
		        'rewards_updated' => __('Rewards updated', WPDEPOSIT_NAME),
		        'error_try_again_later' => __('A problem occurred, please try again later.', WPDEPOSIT_NAME),
		        'field_cannot_be_empty' => __('field cannot be empty', WPDEPOSIT_NAME),
            );
            wp_localize_script(WPDEPOSIT_NAME . '_admin_js', 'trans', $trans);
        }
	    if(is_admin()) {
		    wp_enqueue_style(WPDEPOSIT_NAME . '_admin_styles', WPDEPOSIT_URL . '/public/css/admin_styles.css');
	    }

    }
    
    public function loadFrontStyles()
    {
        wp_enqueue_style(WPDEPOSIT_NAME . '_front_styles', WPDEPOSIT_URL . '/public/css/front_styles.css');
    }
    
    /**
     * Load scripts for frontend but only on certain pages
     * @global type $post
     */
    public function loadFrontScripts()
    {
	    //enqueue jquery
	    wp_enqueue_script("jquery");
        wp_enqueue_script(WPDEPOSIT_NAME . '_front', WPDEPOSIT_URL . '/public/js/front.js', array('jquery'));
	    wp_localize_script(WPDEPOSIT_NAME . '_front', 'ajaxurl', admin_url( 'admin-ajax.php' ));
	    $trans = array(
		    'error_form_dialog_expected' => __('Something went wrong. Contact the site adminstrator (error: form dialog expects a callback function)', WPDEPOSIT_NAME),
		    'error_no_form_dialog_fields_provided' => __('Something went wrong. Contact the site adminstrator (error: no dialog fields provided)', WPDEPOSIT_NAME),
		    'error_redirect_url_cannot_empty' => __('Something went wrong. Contact the site adminstrator (error: redirect url cannot be empty)', WPDEPOSIT_NAME),
		    'error_process_type_unknown' => __('Something went wrong. Contact the site adminstrator (error: process type unkown)', WPDEPOSIT_NAME),
	    );
	    wp_localize_script(WPDEPOSIT_NAME . '_admin_js', 'trans', $trans);
    }

	public function woocommerce_wpdeposit_init()
	{
		$WPdepWoo = new WPdepositWoocommerce();
		add_filter('woocommerce_payment_gateways', array($WPdepWoo, 'woocommerce_add_wpdeposit_gateway') );
	}

    /**
     * Code to run when the plugin was activated
     */
    public function activate_plugin()
    {
        $obj = new updatesController();
        $obj->firstInstall();
    }

    /**
     * Load the menu in the backend
     */
    public function load_menu()
    {
        do_action('wpds_load_menu_before');
        $this->menu = new WPdepositAdminFunctions();
	    do_action('wpds_load_menu_after');
    }
    
    /**
     */
    public function add_ons()
    {
        $wpelements = new WP_elements();
        echo $wpelements->openWrapper('Add ons');
        $obj = new AddonsController();
        $obj->overviewAdmin();
        echo $wpelements->closeWrapper();
    }

}
