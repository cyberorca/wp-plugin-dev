<?php

class Helpers {
	
    public static function getPermalink() {
        $l = get_permalink();
        if (substr($l, -1) == '/') {
            $l = $l . '?';
        } else {
            $l = $l . '&amp;';
        }
        return $l;
    }
	
	/**
	 * Debuging data when cookies are set
     */
	public static function cdebug($cookiesName,$dtDebug){
		if(isset($_COOKIE[$cookiesName])) {
			echo "================= DEBUGING DATA ==================== <br/>";
			if(is_array($dt_debug)){
				echo "<pre>";
				print_r($dtDebug);
				echo "</pre>";
			}else{
				echo $dtDebug . "<br/>";
			}
			echo "<br/>================= END DEBUGING DATA ==================== <br/>";
		}
	}

}