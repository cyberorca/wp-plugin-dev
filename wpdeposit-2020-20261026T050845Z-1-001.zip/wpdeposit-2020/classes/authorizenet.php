<?php 

class Authorizenet {
	
    /**
     * Function to determine if payment is in test mode or not
     *
     * @return void
     * @author Christophe Debruel
     **/
    public function payment_action()
    {
        global $testmode;

        if($testmode === true):
            return "https://test.authorize.net/gateway/transact.dll";
        else:
            return "https://secure.authorize.net/gateway/transact.dll";
        endif;
    }


    /**
     * function to display the paypal form
     *
     * @return void
     * @author Christophe Debruel
     **/
    public function deposit_form($amount)
    {
        global $siteurl, $useridentify, $depositconfirm, $authorizeApiLoginID, $authorizeTransactionKey;
        require_once WPDEPOSIT_PATH . '/lib/anet_php_sdk/AuthorizeNet.php'; // The SDK
        $fp_timestamp = time();
        $fp_sequence = "order_" . time(); // Enter an invoice or other unique number.
        $fingerprint = AuthorizeNetSIM_Form::getFingerprint($authorizeApiLoginID, $authorizeTransactionKey, $amount, $fp_sequence, $fp_timestamp)
        ?>

        <form name="depositform" id="depositform" method='post' action="<?php echo self::payment_action(); ?>">
            <input type='hidden' name="x_login" value="<?php echo $authorizeApiLoginID?>" />
            <input type='hidden' name="x_fp_hash" value="<?php echo $fingerprint?>" />
            <input type='hidden' name="x_amount" value="<?php echo $amount?>" />
            <input type='hidden' name="x_fp_timestamp" value="<?php echo $fp_timestamp?>" />
            <input type='hidden' name="x_fp_sequence" value="<?php echo $fp_sequence?>" />
            <input type='hidden' name="x_version" value="3.1">
            <input type='hidden' name="x_show_form" value="payment_form">
            <input type='hidden' name="x_test_request" value="false" />
            <input type='hidden' name="x_method" value="cc">
            <input type="hidden" name="x_userid" value="<?php echo $useridentify; ?>" />
            <input type="hidden" name="x_relay_response" value="TRUE" />
            <input type="hidden" name="x_relay_url" value="<?php echo $siteurl; ?>includes/authorize_post.php" />
            <p><?php echo $depositconfirm; ?></p>
            <input type="submit" name="checkout" value="Proceed with payment" />
        </form>
    <?php
    }
	
}//end of class
?>