<?php

class WPdepositActiveModules {

    /**
     * Get all modules
     * @return array $modules
     */
    public static function getModules() {
        return array (
            WPdeposit::MOD_ADVERTISEMENT,
            WPdeposit::MOD_SUBSCRIPTION,
        );
    }
    
    /**
     * Get all active modules
     * 
     * @return array $modules
     */
    public static function getActiveModules() {
        $modules = array();
        foreach (self::getModules() as $module) {
            if (defined($module.'_active') && constant($module.'_active') == true) {
                $modules[] = $module;
            }
        }
        return $modules;
    }
    
    /**
     * Is given module active
     * 
     * @param string $module
     * @return boolean isActive 
     */
    public static function isModuleActive($module) {
        return in_array($module, self::getActiveModules());
    }

}