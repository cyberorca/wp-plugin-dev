<?php
require_once WPDEPOSIT_PATH . '/classes/wpd-active_modules.php';

class deposit_balance extends WP_Widget {

    public function __construct() {
        $widget_ops = array('classname' => 'wpdeposit', 'description' => __('This widget will display the deposit balance of the current logged in user.', WPDEPOSIT_NAME));
        parent::__construct('wpdeposit', __('WPdeposit - Show user info & balance', WPDEPOSIT_NAME), $widget_ops);
    }
    
    public function control()
    {
        ?>
        <p><?php _('This widget will desplay the deposit balance of the current logged in user.'); ?></p>
        <?php
    }

    public function widget($args, $instance)
    {
        global $wpdb, $current_user;
	    wp_get_current_user();
        echo $args['before_widget'];
        echo $args['before_title'] . 'Deposit balance' . $args['after_title'];
        include_once(WPDEPOSIT_PATH . '/models/user.php');
        $userModel = new UserModel($current_user->ID);
		$balance = get_user_meta($current_user->ID, WPDEPOSIT_NAME . '_user_amount', true);
		if (empty($balance) || $balance == '') {
			$balance = 0;
		}
        echo '<p>' . __('Your current balance is', WPDEPOSIT_NAME) . ': <strong>';
        if(is_user_logged_in()){
            echo the_credit_type_text(true, $balance, true);
        } else {
            echo '<a href="' . home_url() . '/wp-login.php?redirect_to=' . urlencode('http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']) . '">';
            _e('You are not logged in', WPDEPOSIT_NAME);
            echo '</a>';
        }
        echo '</strong></p>';
    }

    public function register()
    {
        wp_register_sidebar_widget('deposit_balance_widget', 'Deposit balance', array('deposit_balance', 'widget'));
        wp_register_widget_control('deposit_balance_widget_control', 'Deposit balance', array('deposit_balance', 'control'));
    }

}//end of class