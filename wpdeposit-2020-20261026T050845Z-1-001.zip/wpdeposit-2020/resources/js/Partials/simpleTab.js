jQuery(document).ready(function($) {
	$('.tab_box').hide();
	$('.box_tab_1').show();
	$('#tab_1').addClass('nav-tab-active');
	$('.nav-tab').click(function(){
		var tabId = this.id;
		$('.tab_box').hide();
		$('.nav-tab').removeClass('nav-tab-active');
		$('.box_' + tabId).show();
		$('#' + tabId).addClass('nav-tab-active');
	});
});//end of document ready