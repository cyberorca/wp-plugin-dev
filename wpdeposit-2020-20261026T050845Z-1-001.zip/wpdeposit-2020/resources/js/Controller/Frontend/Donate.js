var WPdeposit = WPdeposit || {};
Controller = WPdeposit.Controller = WPdeposit.Controller || {};

WPdeposit.Controller.Donate = {

    init: function () {
        jQuery("#frm_donate_to_user").validate({
            submitHandler: function(form) {
                jQuery.post(
                    ajaxurl,
                    {
                        'action'            : 'donate_to_user',
                        'donate_to_user'    : jQuery('#inp_donate_to_username').val(),
                        'donate_amount'     : jQuery('#inp_donate_amount').val()
                    },
                    function(response){
                        if (response.success == true) {
                            jQuery('.user_balance').text(response.amount);
                            jQuery('.feedback').html('<div class="updated" id="message"><p>' + response.message + '</p></div>');
                            jQuery('#inp_donate_to_username').val('');
                            jQuery('#inp_donate_amount').val('');
                        } else {
                            jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>');
                        }
                    }
                );
            }
        });
    }
};

jQuery(function(){
    WPdeposit.Controller.Donate.init();
});