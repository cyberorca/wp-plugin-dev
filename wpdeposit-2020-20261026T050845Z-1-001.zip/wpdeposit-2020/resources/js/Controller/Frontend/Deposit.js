var WPdeposit = WPdeposit || {};
Controller = WPdeposit.Controller = WPdeposit.Controller || {};

WPdeposit.Controller.Deposit = {

    init: function() {
        var that = WPdeposit.Controller.Deposit;
        jQuery('#deposit_custom_amount').focus(function(){
            jQuery('.deposit_amount').prop('checked', false);
        });
        // add form
        jQuery('#wpdeposit_deposit_money').submit(function(e) {
            e.preventDefault();
            var selectedPaymentGateway = jQuery('.payment_gateway:checked').val();
            //get form
            jQuery.post(
                ajaxurl,
                {
                    'action': 'forward_to_gateway',
                    'deposit_amount': jQuery('.deposit_amount:checked').val(),
                    'deposit_custom_amount': jQuery('.deposit_custom_amount').val(),
                    'payment_gateway':  selectedPaymentGateway
                },
                function(response){
                    var loadFormEl = jQuery('.loadform'),
                        feedbackEl = jQuery('.feedback');
                    if (response.success === true) {
                        loadFormEl.html( response.form );
                        switch(response.processtype){
                            case 'form':
                                var depositForm = loadFormEl.html().replace(/&lt;/g, "<").replace(/&gt;/g, ">");
                                feedbackEl.html('<div class="updated" id="message"><p>' + response.message + '</p></div>').fadeIn();
                                loadFormEl.html( depositForm );
                                jQuery('#depositform').submit();
                                break;
                            case 'formdialog':
                                var dialogScreenTitle = '';
                                if (response.dialog_screen_title == '' || response.dialog_screen_title == null) {
                                    dialogScreenTitle = 'Payment process window';
                                } else {
                                    dialogScreenTitle = response.dialog_screen_title;
                                }
                                if (response.dialog_screen_title == '' || response.dialog_screen_title == null) {
                                    jQuery('.feedback').html('<div class="error" id="message"><p>' + trans.error_form_dialog_expected + '</p></div>').fadeIn();
                                    return false;
                                }
                                if (response.dialog_fields == '' || response.dialog_fields == null) {
                                    jQuery('.feedback').html('<div class="error" id="message"><p>' + trans.error_no_form_dialog_fields_provided + '</p></div>').fadeIn();
                                    return false;
                                }
                                var depositForm = loadFormEl.html().replace(/&lt;/g, "<").replace(/&gt;/g, ">");
                                showDialog(depositForm , dialogScreenTitle, response.callback, response.dialog_fields);
                                break;
                            case 'redirecturl':
                                var rUrl = response.redirecturl;
                                if (rUrl != '' && rUrl != null) {
                                    window.location = response.redirecturl;
                                } else {
                                    jQuery('.feedback').html('<div class="error" id="message"><p>' + trans.error_redirect_url_cannot_empty + '</p></div>').fadeIn();
                                    return false;
                                }

                                break;
                            default:
                                feedbackEl.html('<div class="error" id="message"><p>' + trans.error_process_type_unknown + '</p></div>').fadeIn();
                                return false;
                                break;
                        }
                    } else {
                        feedbackEl.html('<div class="error" id="message"><p>' + response.message + '</p></div>').fadeIn();
                    }
                }
            );
        });
    },

    showDialog: function(str, strtitle, callback, dialogFields)
    {
        if(!strtitle) {
            strtitle='Error message';
        }
        var dialogEl = jQuery('.dialog');
        dialogEl.show();
        dialogEl.html(str);
        dialogEl.dialog({
            resizable: false,
            modal: true,
            width: 600,
            overlay: {
                backgroundColor: '#000',
                opacity: 0.2
            },
            title:strtitle,
            buttons: {
                'Continue': function() {
                    var data = {};
                    var errors = new Array();
                    data['action'] = callback;
                    /**
                     * Get all the field values and validate using the specified validators
                     * @since version 1.8.2
                     */
                    jQuery.each(dialogFields, function(key, validators){
                        var fieldValue = jQuery('.ui-dialog').find('#' + key).val();
                        if(validators != null && validators != ''){
                            var fieldValidators = validators.split('|');
                            for(e in fieldValidators){
                                switch(fieldValidators[e]){
                                    case 'required':
                                        if(fieldValue == null || fieldValue == ''){
                                            errors.push(key + trans.field_cannot_be_empty);
                                        }
                                        break;
                                    case 'valid_email':
                                        if(!fieldValue.match(/([\w-+\.]+)@((?:[\w]+\.)+)([a-zA-Z]{2,4})/)){
                                            errors.push(key + trans.field_cannot_be_empty);
                                        }
                                        break;
                                    case 'valid_numeric':
                                        if(!fieldValue.match(/[0-9]+/)){
                                            errors.push(key + trans.field_cannot_be_empty);
                                        }
                                        break;
                                    case 'valid_url':
                                        if(!fieldValue.match(/(((f|ht){1}(tp|tps):\/\/)[\w\d\S]+)/)){
                                            errors.push(key + trans.field_cannot_be_empty);
                                        }
                                        break;
                                }
                            }
                        }
                        data[key] = fieldValue;
                    });
                    if (errors.length > 0) {
                        jQuery('.error').remove();
                        //there are errors
                        var errorMessage = '<div class="error"><ul>';
                        for(c in errors){
                            errorMessage+= '<li>' + errors[c] + '</li>';
                        }
                        errorMessage+= '</ul></div>';
                        dialogEl.prepend(errorMessage);
                        return false;
                    }
                    jQuery.post(
                        ajaxurl,
                        data,
                        function(response){
                            dialogEl.dialog('destroy');
                            if (response.success === true) {
                                window.location.replace(response.transaction_url);
                            } else {
                                jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>').fadeIn();
                            }
                        }
                    );
                },
                'Cancel': function() {
                    dialogEl.dialog('destroy');
                }
            }
        });

    }

};

jQuery(function(){
    WPdeposit.Controller.Deposit.init();
});