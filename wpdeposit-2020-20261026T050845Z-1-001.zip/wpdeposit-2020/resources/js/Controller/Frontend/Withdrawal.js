var WPdeposit = WPdeposit || {};
Controller = WPdeposit.Controller = WPdeposit.Controller || {};

WPdeposit.Controller.Withdrawal = {

    init: function () {
        jQuery("#frm_request_withdrawal").validate({
            submitHandler: function(form) {
                jQuery.post(
                    ajaxurl,
                    {
                        'action'            : 'request_withdrawal',
                        'request_amount'     : jQuery('#inp_request_amount').val(),
                        'request_gateway'     : jQuery('[name="payment_gateway"]').attr('id'),
                        'request_message'     : jQuery('#inp_request_message').val()
                    },
                    function(response){
                        if (response.success == true) {
                            jQuery('#inp_request_amount').val('');
                            location.reload();
                            jQuery('.user_balance').text(response.amount);
                            jQuery('.withdrawal_balance').text(response.withdrawal_amount);
                            jQuery('.feedback').html('<div class="updated" id="message"><p>' + response.message + '</p></div>');
                        } else {
                            jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>');
                        }
                    }
                );
            }
        });
    }
};

jQuery(function(){
    WPdeposit.Controller.Withdrawal.init();
});