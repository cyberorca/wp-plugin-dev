var WPdeposit = WPdeposit || {};
Controller = WPdeposit.Controller = WPdeposit.Controller || {};

//@todo backbone view van maken
WPdeposit.Controller.PaymentOption = {
    init: function() {
        var that = WPdeposit.Controller.PaymentOption;
        jQuery('.show-point-fields').on('click', function(){
            jQuery.post(
                ajaxurl,
                {
                    action : 'point_fields',
                    type: 'show'
                },
                function(response){
                    if(response.success){
                        location.reload();
                    } else {
                        alert(trans.error_try_again_later);
                    }
                }
            );
        });
        jQuery('.hide-point-fields').on('click', function(){
            jQuery.post(
                ajaxurl,
                {
                    action : 'point_fields',
                    type: 'hide'
                },
                function(response){
                    if(response.success){
                        location.reload();
                    } else {
                        alert(trans.error_try_again_later);
                    }
                }
            );
        });

        // add form
        jQuery("#wpdeposit_po_form").validate({
            submitHandler: function(form) {
                var priceEl = jQuery('#wpdeposit_price'),
                    pointsEl = jQuery('#wpdeposit_points'),
                    bonusEl = jQuery('#wpdeposit_bonus'),
                    defaultConvertion = jQuery('#wpdeposit_default_convertion'),
                    data = {
                        'action': 'add_payment_option',
                        'bonus':  bonusEl.val(),
                        'price':  priceEl.val(),
                        'default_convertion': defaultConvertion.val()
                    };
                if (pointsEl.length > 0) {
                    data['points'] = pointsEl.val();
                }

                jQuery.post(
                    ajaxurl,
                    data,
                    function(response){
                        priceEl.val(''),
                            pointsEl.val(''),
                            that.reloadPaymentOptions();
                        jQuery('.feedback').html('<div class="updated" id="message"><p>Payment option added</p></div>').fadeIn().delay(3000).fadeOut('slow');
                    }
                );
            }
        });

        // edit form
        jQuery("#wpdeposit_po_form_edit").validate({
            submitHandler: function(form) {
                var priceEl = jQuery('#wpdeposit_price_e'),
                    pointsEl = jQuery('#wpdeposit_points_e'),
                    bonusEl = jQuery('#wpdeposit_bonus_e'),
                    idInputEl = jQuery('#wpdeposit_id_e'),
                    defaultConvertion = jQuery('#wpdeposit_default_convertion_e'),
                    data = {
                        'action': 'edit_payment_option',
                        'price':  priceEl.val(),
                        'bonus':  bonusEl.val(),
                        'default_convertion': defaultConvertion.val(),
                        'id':  idInputEl.val()
                    };
                if (pointsEl.length > 0) {
                    data['points'] = pointsEl.val();
                }
                jQuery.post(
                    ajaxurl,
                    data,
                    function(response){
                        that.hidePOEdit();
                        that.reloadPaymentOptions();
                        jQuery('.feedback').html('<div class="updated" id="message"><p>Payment option edited</p></div>').fadeIn().delay(3000).fadeOut('slow');
                    }
                );
            }
        });

        // edit action link
        jQuery('.edit_payment_option').live('click', function() {
            var priceEl = jQuery('#wpdeposit_price_e'),
                pointsEl = jQuery('#wpdeposit_points_e');
            priceEl.val('');
            if (pointsEl.length > 0) {
                pointsEl.val('')
            }

            var id = this.title.replace('po-', '');
            jQuery('#wpdeposit_po_form').slideUp('fast', function() {
                jQuery.ajax({
                    url: ajaxurl,
                    type: "GET",
                    data: ({
                        id : id,
                        action: 'get_payment_option'
                    }),
                    dataType: "json",
                    success: function(data) {
                        jQuery('#wpdeposit_price_e').val(data.record.price);
                        jQuery('#wpdeposit_bonus_e').val(data.record.bonus);
                        if (data.record.points != '' && data.record.points != null) {
                            jQuery('#wpdeposit_points_e').val(data.record.points);
                        }
                        jQuery('#wpdeposit_default_convertion_e').val(data.record.default_convertion);
                        jQuery('#wpdeposit_id_e').val(data.record.id);
                        jQuery('#wpdeposit_po_form_e_wrap').show('slow');
                    }
                });
            });
            return false;
        });

        // delete action link
        jQuery('.delete_payment_option').live('click', function() {
            var id = this.title.replace('po-', '');
            var del = confirm('Are you sure you want to delete this?');

            if (del) {
                that.hidePOEdit();
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: ({
                        id : id,
                        action: 'delete_payment_option'
                    }),
                    dataType: "json",
                    success: function(data) {
                        that.reloadPaymentOptions();
                        jQuery('.feedback').hide().html('<div class="updated" id="message"><p>Payment option deleted</p></div>').fadeIn().delay(1000).fadeOut('slow');
                    }
                });
            }
            return false;
        });

        // cancel button
        jQuery('#edit_payment_option_cancel').click(function() {
            that.hidePOEdit();
            return false;
        });
    },

    reloadPaymentOptions: function()
    {
        var paymentOption = jQuery('#payment_options');
        paymentOption.html('Loading...');
        paymentOption.load(ajaxurl + '?action=get_payment_options');
    },

    hidePOEdit: function()
    {
        jQuery('#wpdeposit_price_e').val('');
        jQuery('#wpdeposit_id_e').val('');

        jQuery('#wpdeposit_po_form_e_wrap').hide('fast', function() {
            jQuery('#wpdeposit_po_form').show('slow');
        });
    }
};

jQuery(function(){
    WPdeposit.Controller.PaymentOption.init();
});