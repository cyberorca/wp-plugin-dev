var WPdeposit = WPdeposit || {};
    Controller = WPdeposit.Controller = WPdeposit.Controller || {};



WPdeposit.Controller.Settings = {

    init: function() {
        var that = WPdeposit.Controller.Settings;
        that.setupSimpleTabs();
        this.controls = {
            generalSettings: new WPdeposit.View.GeneralSettings({
                el: jQuery('#wpdeposit_settings_form_add')
            }),
            testSettings: new WPdeposit.View.TestSettings({
                el: jQuery('#wpdeposit_settings_form_test_options')
            }),
            gatewaySettings: new WPdeposit.View.GatewaySettings({
                el: jQuery('#wpdeposit_go_form')
            }),
            mailSettings: new WPdeposit.View.MailSettings({
                el: jQuery('#wpdeposit_settings_mail_templates')
            }),
            pointsSettings: new WPdeposit.View.PointsSettings({
                el: jQuery('#wpdeposit_points_form')
            }),
            viewsSettings: new WPdeposit.View.ViewsSettings({
                el: jQuery('#wpdeposit-custom-views')
            })
        }

        jQuery('.test-balance').on('click', function(){
            var $this = jQuery(this),
                testType = $this.data('test-type');

            if(typeof testType !== 'undefined' && testType != '' && testType != null){
                jQuery.post(
                    ajaxurl,
                    {
                        action : 'test_balance',
                        type: testType
                    },
                    function(response){
                        if(response.success){
                            jQuery('.balance_text').html(response.message);
                        } else {
                            alert(trans.error_try_again_later);
                        }
                    }
                );
            } else {
                alert(trans.error_try_again_later);
            }
        });
    },

    setupSimpleTabs: function() {
        jQuery('.tab_box').hide();
        jQuery('.box_tab_1').show();
        jQuery('#tab_1').addClass('nav-tab-active');
        jQuery('.nav-tab').click(function(){
            var tabId = this.id;
            jQuery('.tab_box').hide();
            jQuery('.nav-tab').removeClass('nav-tab-active');
            jQuery('.box_' + tabId).show();
            jQuery('#' + tabId).addClass('nav-tab-active');
        });
    }

};

jQuery(function(){
    WPdeposit.Controller.Settings.init();
});