var WPdeposit = WPdeposit || {};
    Controller = WPdeposit.Controller = WPdeposit.Controller || {};

WPdeposit.Controller.Rewards = {

    init: function() {
        var that = WPdeposit.Controller.Rewards;
        that.setupSimpleTabs();
        /**========================================
         * Form save settings, validate & submit
         ========================================*/
        jQuery("#wpdeposit_rewards_form").validate({
            submitHandler: function(form) {
                var formSerialized = jQuery("#wpdeposit_rewards_form").serializeArray();
                jQuery.post(
                    ajaxurl,
                    {
                        'action': 'update_rewards',
                        'form': formSerialized
                    },
                    function(response){
                        if (response.success) {
                            jQuery('.feedback').html('<div class="updated" id="message"><p>' + trans.rewards_updated + '</p></div>').fadeIn().delay(3000).fadeOut('slow');
                        }
                    }
                );
            }
        });
        jQuery("#wpdeposit_add_extra_rewards_form").validate({
            submitHandler: function(form) {
                var formSerialized = jQuery("#wpdeposit_add_extra_rewards_form").serializeArray();
                jQuery.post(
                    ajaxurl,
                    {
                        'action': 'add_extra_reward',
                        'form': formSerialized
                    },
                    function(response){
                        if (response.success) {
                            jQuery('.extra_reward_list tr:last').after('<tr><td>' + response.action_hook_info.action_hook + '</td><td>' + response.action_hook_info.action_hook_point_type + '</td><td>' + response.action_hook_info.action_hook_value + '</td></tr>');
                            jQuery('.feedback').html('<div class="updated" id="message"><p>' + trans.rewards_updated + '</p></div>').fadeIn().delay(3000).fadeOut('slow');
                        }
                    }
                );
            }
        });

        jQuery("#wpdeposit_edit_extra_rewards_form").validate({
            submitHandler: function(form) {
                var formSerialized = jQuery("#wpdeposit_edit_extra_rewards_form").serializeArray();
                jQuery.post(
                    ajaxurl,
                    {
                        'action': 'edit_extra_reward',
                        'form': formSerialized
                    },
                    function(response){
                        if (response.success) {
                            jQuery('.feedback').html('<div class="updated" id="message"><p>' + trans.rewards_updated + '</p></div>').fadeIn().delay(1500).fadeOut('slow', function(){
                                window.location.reload();
                            });
                        }
                    }
                );
            }
        });

        jQuery('.edit_reward').click(function(e){
            var $this = jQuery(e.currentTarget),
                originalHook = $this.data('hook');
            jQuery('#extra_reward_edit_form').slideDown('fast', function(){
                var $this = jQuery(this),
                    data = {
                        hook : originalHook,
                        action: 'get_extra_reward'
                    };
                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: data,
                    success: function(data) {
                        if(!data.success){
                            alert('something went wrong. Try again.');
                            jQuery('#extra_reward_edit_form').slideUp('fast');
                        } else {
                            if(typeof data.record !== 'undefined' && data.record != ''){
                                $this.find('[name="original_hook"]').val(data.record.action_hook);
                                $this.find('[name="action_hook"]').val(data.record.action_hook);
                                $this.find('[name="action_hook_point_type"]').val(data.record.action_hook_point_type);
                                $this.find('[name="action_hook_value"]').val(data.record.action_hook_value);
                            }
                        }
                    }
                });
            });
            return false;
        });

        jQuery('.delete_reward').click(function(e){
            e.preventDefault();
            var $this = jQuery(e.currentTarget),
                originalHook = $this.data('hook');

            if(confirm('Are you sure you wish to delete this reward?')){
                var data = {
                    hook : originalHook,
                    action: 'delete_extra_reward'
                };

                jQuery.ajax({
                    url: ajaxurl,
                    type: "POST",
                    data: data,
                    success: function(data) {
                        if(!data.success){
                            alert('something went wrong. Try again.');
                        } else {
                            $this.parent().parent().remove();
                        }
                    }
                });
            }
        });
    },

    setupSimpleTabs: function() {
        jQuery('.tab_box').hide();
        jQuery('.box_tab_1').show();
        jQuery('#tab_1').addClass('nav-tab-active');
        jQuery('.nav-tab').click(function(){
            var tabId = this.id;
            jQuery('.tab_box').hide();
            jQuery('.nav-tab').removeClass('nav-tab-active');
            jQuery('.box_' + tabId).show();
            jQuery('#' + tabId).addClass('nav-tab-active');
        });
    }

};

jQuery(function(){
    WPdeposit.Controller.Rewards.init();
});