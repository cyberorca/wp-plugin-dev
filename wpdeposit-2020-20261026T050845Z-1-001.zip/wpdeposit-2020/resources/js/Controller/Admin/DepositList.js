var WPdeposit = WPdeposit || {};
Controller = WPdeposit.Controller = WPdeposit.Controller || {};

//@todo backbone view van maken
WPdeposit.Controller.DepositList = {
    init: function() {
        var that = WPdeposit.Controller.DepositList;

        var completeDepEl = jQuery('.completedeposit');
        completeDepEl.qtip({
            content: {attr: 'title'},
            show: {
                when: { event: 'mouseover' }
            },hide: { event: 'mouseout' }
        });
        jQuery('.suspenddeposit').qtip({content: {attr: 'title'}});
        completeDepEl.click(function() {
            var dId = this.id;
            jQuery.post(
                ajaxurl,
                {
                    'action': 'mark_deposit_completed',
                    'unique_code': dId
                },
                function(response){
                    var actionId = jQuery('#action_' + dId),
                        statusId = jQuery('#status_' + dId);
                    var img = actionId.html();
                    var status = statusId.html();
                    var newImg = '';
                    var newStatus = '';
                    if (response.success == true) {
                        newStatus = status.replace('Pending', 'Completed');
                        statusId.removeClass('orange').addClass('green');
                        jQuery('.feedback').html('<div class="updated" id="message"><p>' + response.message + '</p></div>').fadeOut(5000);
                    } else {
                        jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>').fadeOut(5000);
                    }
                    actionId.html('');
                    statusId.html(newStatus);
                }
            );
            return false;
        });
    }
};

jQuery(function(){
    WPdeposit.Controller.DepositList.init();
});