var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.TestSettings = Backbone.View.extend({

    initialize: function(){
        _.bindAll(this, 'submitForm', 'save');
    },

    events: {
        'click [name="sbm_settings"]': 'submitForm'
    },

    submitForm: function(e){
        e.preventDefault();
        this.saveSettings();
    },

    save: function(){
        jQuery.post(
            ajaxurl,
            {
                'action': 'update_test_options_settings',
                'test_mode': this.$('input[name=rad_test_mode]:checked').val()
            },
            function(response){
                if (response.success) {
                    jQuery('.feedback')
                        .html('<div class="updated" id="message"><p>Settings updated</p></div>')
                        .fadeIn()
                        .delay(3000)
                        .fadeOut('slow');
                }
            }
        );
    }

});