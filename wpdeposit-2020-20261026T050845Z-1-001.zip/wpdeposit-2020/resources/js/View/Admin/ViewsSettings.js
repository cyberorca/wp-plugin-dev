var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.ViewsSettings = Backbone.View.extend({

    initialize: function(){

    },

    events: {
        'click .generate_view_files': 'generateViewFiles'
    },

    generateViewFiles: function() {
        if (customViewExists) {
            if (confirm('Custom views already exist, generating these views again might overwrite any changes you made. Are you sure you wish to regenerate your view files?')) {
                this.generateCustomViews();
            }
        } else {
            this.generateCustomViews();
        }
    },

    generateCustomViews: function(){
        jQuery.post(
            ajaxurl,
            {
                'action': 'generate_custom_views'
            },
            function(response){
                if (response.success) {
                    jQuery('.feedback')
                        .html('<div class="updated" id="message"><p>Custom views were generated in your theme. All view files are located in a wpdeposit folder.</p></div>')
                        .fadeIn()
                        .delay(3000)
                        .fadeOut('slow');
                }
            }
        );
    }

});