var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.MailSettings = Backbone.View.extend({

    initialize: function(){
        _.bindAll(this, 'submitForm', 'save');
    },

    events: {
        'click [name="sbm_mail_templates"]': 'submitForm'
    },

    submitForm: function(e){
        e.preventDefault();
        this.save();
    },

    save: function(){
        var adminEmailEnable = 'off';
        if (jQuery('#wpdeposit_admin_donation_content_enable').is(':checked')) {
            adminEmailEnable = 'on';
        }
        var userEmailEnable = 'off';
        if (jQuery('#wpdeposit_user_donation_content_enable').is(':checked')) {
            userEmailEnable = 'on';
        }
        jQuery.post(
            ajaxurl,
            {
                'action': 'update_mailtemplate_settings',
                'success_mail_template': jQuery('#wpdeposit_success_mail_content').val(),
                'error_mail_template': jQuery('#wpdeposit_error_mail_content').val(),
                'user_donation_content_enable': userEmailEnable,
                'user_donation_email_content': jQuery('#wpdeposit_user_donation_email_content').val(),
                'admin_donation_content_enable': adminEmailEnable,
                'admin_donation_email_content': jQuery('#wpdeposit_admin_donation_email_content').val(),
                'withdrawal_reject_email_content': jQuery('#wpdeposit_withdrawal_reject_email_content').val(),
                'withdrawal_finished_email_content': jQuery('#wpdeposit_withdrawal_finished_email_content').val()
            },
            function(response){
                if (response.success) {
                    jQuery('.feedback')
                        .html('<div class="updated" id="message"><p>Mail templates updated</p></div>')
                        .fadeIn()
                        .delay(3000)
                        .fadeOut('slow');
                }
            }
        );
    }

});