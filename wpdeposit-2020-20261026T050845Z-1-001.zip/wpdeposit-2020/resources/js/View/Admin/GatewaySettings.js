var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.GatewaySettings = Backbone.View.extend({

    initialize: function(){
        _.bindAll(this, 'submitForm', 'save');

        var arrow_block = jQuery('.arrow_open');
        arrow_block.click(function(e){
            jQuery('.arrow_close').removeClass('arrow_close').addClass('arrow_open');
            jQuery('.gateway_info').css('display', 'none');
            var el = this.id;
            jQuery('#'+ this.id).removeClass('arrow_open').addClass('arrow_close');
            var parentId = el.replace(/\_arrow/, '');
            jQuery("#" + parentId + " .gateway_info").css('display', 'block');
        });
        jQuery('.arrow_close').click(function(){
            jQuery('.arrow_close').removeClass('arrow_close').addClass('arrow_open');
            jQuery('.gateway_info').css('display', 'none');
        });
    },

    events: {
        'click #wpdeposit_pg_submit': 'submitForm'
    },

    submitForm: function(e){
        e.preventDefault();
        this.save();
    },

    save: function(){
        /**
         * create data array variable to be passed later on to the ajax call
         */
        var data = {};
        data['action'] = 'update_gateway_settings';

        /**
         * Get checkboxes and only save those who are checked
         */
        var gatewayList = new Array();
        var gatewayUncheckedList = new Array();
        var gatewayCheckboxes = jQuery('.gateway_active_checkbox');
        var i = 0;
        var t = 0;
        gatewayCheckboxes.each(function(key, el){
            if (el.checked) {
                var elId = el.id;
                elId = elId.replace('_active', '');
                gatewayList[i] = elId;
                i++;
            } else {
                var elId = el.id;
                elId = elId.replace('_active', '');
                gatewayUncheckedList[t] = elId;
                t++;
            }
        });
        data['active_gateways'] = gatewayList;
        data['unactive_gateways'] = gatewayUncheckedList;

        /**
         * foreach active payment gateways save the fields
         */
        jQuery.each(gatewayList, function(index, pg) {
            var gatewayFields = jQuery('#' + pg + '_gateway_info :input');
            if (gatewayFields.length > 0) {
                jQuery.each(gatewayFields, function(index, field) {
                    var fieldId = field.id,
                        fieldEl = jQuery('#' + fieldId),
                        fieldType = fieldEl.prop('tagName') + '_' + fieldEl.attr('type');
                    //get radio buttons
                    if (fieldType == 'INPUT_radio' && field.checked) {
                        data[fieldEl.attr('name')] = fieldEl.attr('value');
                        //get checked checkboxes
                    } else if(fieldType == 'INPUT_checkbox' && field.checked) {
                        data[fieldEl.attr('id')] = fieldEl.attr('value');
                        //get unchecked checkboxes
                    } else if(fieldType == 'INPUT_checkbox' && !field.checked) {
                        data[fieldEl.attr('id')] = 'unchecked';
                    } else {
                        if (fieldType != 'INPUT_radio' && fieldType != 'INPUT_checkbox' && fieldEl.attr('value') != '') { //prevent unchecked radio and checkboxes to be processed
                            data[fieldEl.attr('id')] = fieldEl.attr('value');
                        }
                    }
                });
            }
        });

        jQuery.post(
            ajaxurl,
            data,
            function(response){
                if (response.success) {
                    jQuery('.feedback').html('<div class="updated" id="message"><p>' + response.message + '</p></div>').fadeIn();
                } else {
                    jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>').fadeIn();
                }
            }
        );
        return false;
    },

    getElementLabel: function(el){
        var label = $('label[for="'+$(el).attr('id')+'"]');
        if(label.length <= 0) {
            var parentElem = $(this).parent(),
                parentTagName = parentElem.get(0).tagName.toLowerCase();
            if(parentTagName == "label") {
                label = parentElem;
            }
        }
    }

});