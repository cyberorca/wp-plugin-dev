var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.GeneralSettings = Backbone.View.extend({

    initialize: function(){
        _.bindAll(this, 'submitForm', 'save');
    },

    events: {
        'click [name="sbm_settings"]': 'submitForm'
    },

    submitForm: function(e){
        e.preventDefault();
        this.save();
    },

    save: function(){
        var disableWPdepositStyles = 'off';
        if (this.$('#wpdeposit_disable_styles').is(':checked')) {
            disableWPdepositStyles = 'on';
        }
        var data = {
            'action': 'update_main_settings',
            'deposit_log': this.$('input[name=deposit_log]:checked').val(),
            'withdrawals': this.$('#withdrawals').val(),
            'points_name_single': this.$('#inp_points_name_single').val(),
            'points_name_plural': this.$('#inp_points_name_plural').val(),
            'currency': this.$('#inp_currency').val(),
            'currency_position': this.$('#inp_currency_position').val(),
            'custom_currency_code' : this.$('#inp_custom_currency_code').val(),
            'custom_currency' : this.$('#inp_custom_currency').val(),
            'company_name': this.$('#inp_company_name').val(),
            'company_address': this.$('#inp_company_address').val(),
            'company_number': this.$('#inp_company_number').val(),
            'company_phone_number': this.$('#inp_company_phone_number').val(),
            'pdf_document_footer': this.$('#inp_pdf_document_footer').val(),
            'deposit_success_page': this.$('#success_page').val(),
            'deposit_cancel_page': this.$('#cancel_page').val(),
            'deposit_failure_page': this.$('#failure_page').val(),
            'deposit_expired_page': this.$('#expired_page').val(),
            'deposit_open_page': this.$('#open_page').val(),
            'deposit_confirm_message': this.$('#txt_confirm_deposit_message').val(),
            'custom_deposit_limit': this.$('#inp_custom_deposit_limit').val(),
            'disable_styles': disableWPdepositStyles
        };

        jQuery.post(
            ajaxurl,
            data,
            function(response){
                if (response.success) {
                    jQuery('.feedback')
                        .html('<div class="updated" id="message"><p>Settings updated</p></div>')
                        .fadeIn()
                        .delay(3000)
                        .fadeOut('slow');
                }
            }
        );
    }

});