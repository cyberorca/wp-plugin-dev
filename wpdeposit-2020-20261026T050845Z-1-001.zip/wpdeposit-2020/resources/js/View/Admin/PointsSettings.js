var WPdeposit = WPdeposit || {};
    View = WPdeposit.View = WPdeposit.View || {};

WPdeposit.View.PointsSettings = Backbone.View.extend({

    initialize: function(){
        _.bindAll(this, 'submitForm', 'save');
    },

    events: {
        'click [name="sbm_settings"]': 'submitForm'
    },

    submitForm: function(e){
        e.preventDefault();
        this.save();
    },

    save: function(){
        var creditTypeEl = jQuery('#wpdeposit_credit_type'),
            newCreditTypeVal = creditTypeEl.val();
        if(depositCount > 0) {
            if (creditType != newCreditTypeVal) {
                this.convert_creditTypes(creditType, newCreditTypeVal, paymentOptions);
            }
        } else {
            if (creditType != newCreditTypeVal) {
                this.saveCreditTypeSettings(newCreditTypeVal);
            }
        }
    },

    convert_creditTypes: function(creditType, newCreditTypeVal, paymentOptions, convertType) {
        var that = this,
            dialogEl = document.createElement('div'),
        minHeight = 220;
        dialogEl.id = 'convertion-alert';
        jQuery('body').append(dialogEl);
        var convertionRateDialog = jQuery('#convertion-alert');
        if(convertType == 'convert_points_after_update') {
            var convertionTextHtml = '<p>Before you proceed you must convert to the new point system. (a backup of the current credits will be created first).</p><p>Please select a convertion rate.</p>';
        } else {
            if(newCreditTypeVal == 'points') {
                var convertionTextHtml = '<p>You have selected to move from credits to points. Before continuing we must convert all credits to points (a backup of the current credits will be created first).</p><p>Please select a convertion rate.</p>';
            } else {
                var convertionTextHtml = '<p>You have selected to move from points to credits. Before continuing we must convert all points to credits (a backup of the current credits will be created first).</p><p>Please select a convertion rate.</p>'
            }
        }
        if(paymentOptions != null) {
            var optionSelected = '';
            for(e in paymentOptions){
                if(e == 0){
                    optionSelected = 'checked="checked"';
                } else {
                    optionSelected = '';//reset
                }
                convertionTextHtml += '<p><input type="radio" name="convertion_rate" class="convertion_rate" ' + optionSelected + ' value="' + paymentOptions[e].points + '/' + paymentOptions[e].price + '" /> ' + paymentOptions[e].points + ' point(s)/' + paymentOptions[e].price + ' credits</p>' ;
                minHeight += 35;
            }
        } else {
            convertionTextHtml += '<p class="error"><strong>It looks like you have not created any payment option. Please go to WPdeposit -> payment options before your proceed with the convertion.</strong></p>';
            minHeight += 50;
        }
        convertionRateDialog.html(convertionTextHtml);
        convertionRateDialog.dialog({
            resizable: false,
            height:minHeight,
            minWidth: 550,
            modal: false,
            buttons: {
                "ok": function() {
                    if(paymentOptions != null) {
                        if(newCreditTypeVal != 'points') {
                            var convertAction = 'convert_points_to_credits';
                        } else {
                            var convertAction = 'convert_credits_to_points';
                        }
                        var convertionRateOptionEl = jQuery('[name="convertion_rate"]:checked');
                        if(convertionRateOptionEl.length == 0){
                            alert('You did not select a convertion option');
                        } else {
                            var convertionRate = convertionRateOptionEl.val();
                            jQuery.post(
                                ajaxurl,
                                {
                                    action : convertAction,
                                    convertionRate: convertionRate
                                },
                                function(response){
                                    if(response.success){
                                        that.saveCreditTypeSettings(newCreditTypeVal);
                                    }
                                    that.displayFeedbackMessage(response);
                                }
                            );
                            jQuery( this ).dialog( "close" );
                        }
                    } else {
                        jQuery( this ).dialog( "close" );
                        alert('Nothing converted. Please add payment options first');
                    }
                },
                Cancel: function() {
                    jQuery('.feedback').html('<div class="error" id="message"><p>Save cancelled by user.</p></div>').fadeIn().delay(3000).fadeOut('slow');
                    jQuery( this ).dialog( "close" );
                }
            }
        });
    },

    saveCreditTypeSettings: function(newCreditTypeVal) {
        var that = this;
        jQuery.post(
            ajaxurl,
            {
                'action'        : 'update_credit_settings',
                'credit_type'   : newCreditTypeVal
            },
            function(response){
                that.displayFeedbackMessage(response);
            }
        );
    },

    displayFeedbackMessage: function(response)
    {
        if (response.success) {
            jQuery('.feedback').html('<div class="updated" id="message"><p>' + response.message + '</p></div>').fadeIn().delay(3000).fadeOut('slow');
        } else {
            jQuery('.feedback').html('<div class="error" id="message"><p>' + response.message + '</p></div>').fadeIn().delay(3000).fadeOut('slow');
        }
    }

});