<?php

/**
 * Abstract controller
 */
abstract class wpdepositAbstractController {
    
    /**
     * wpdb
     * @var wpdb 
     */
    protected $_wpdb;
    
    /**
     * current logged in wordpress user
     */
    protected $_user;
    
    protected $_wpelements;
    
    /**
     *
     * @var boolean 
     */
    public $_logger;
    
    public function __construct() {
        //@todo: is this still needed?
        // check if wpdeposit is installed
        if (!file_exists(WPDEPOSIT_PATH)) {
            wp_die('You need the WPdeposit plugin and it has to be active to use this plugin. For more information please contact us at http://www.uwebic.com');
        }
        
        global $wpdb, $current_user;
	    wp_get_current_user();
        $this->_user = $current_user;
        $this->_wpdb = $wpdb;
        $this->_wpelements = new WP_elements();
        $this->_logger = new WpdepositActionLogger(WPDEPOSIT_PATH . '/deposit_log.txt');
    }
    
}