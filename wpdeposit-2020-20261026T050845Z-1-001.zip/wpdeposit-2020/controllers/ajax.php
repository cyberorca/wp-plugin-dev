<?php

class WPdepositAjax extends wpdepositAbstractController  {

	public function registerAjaxRequests()
	{
		if (is_admin()) {
			//ajax request for admin panel only
			add_action('wp_ajax_add_payment_option', array($this, 'add_payment_option'));
			add_action('wp_ajax_edit_payment_option', array($this, 'edit_payment_option'));
			add_action('wp_ajax_delete_payment_option', array($this, 'delete_payment_option'));
			add_action('wp_ajax_get_payment_option', array($this, 'get_payment_option'));
			add_action('wp_ajax_get_payment_options', array($this, 'get_payment_options'));
			add_action('wp_ajax_get_extra_reward', array($this, 'get_extra_reward'));
			add_action('wp_ajax_edit_extra_reward', array($this, 'edit_extra_reward'));
			add_action('wp_ajax_delete_extra_reward', array($this, 'delete_extra_reward'));
			//save main settings
			add_action('wp_ajax_update_test_options_settings', array($this, 'update_test_options_settings'));
			add_action('wp_ajax_update_main_settings', array($this, 'update_settings'));
			add_action('wp_ajax_update_gateway_settings', array($this, 'update_gateway_settings'));
			add_action('wp_ajax_setting_add_image', array($this, 'setting_add_image'));
			add_action('wp_ajax_update_mailtemplate_settings', array($this, 'update_mailtemplate_settings'));
			add_action('wp_ajax_update_credit_settings', array($this, 'update_credit_settings'));
			add_action('wp_ajax_update_rewards', array($this, 'update_rewards'));
			add_action('wp_ajax_add_extra_reward', array($this, 'add_extra_reward'));
			//generate view files
			add_action('wp_ajax_generate_custom_views', array($this, 'generate_custom_views'));
			//enable point fields (needed for when converting from credits to points and vice versa
			add_action('wp_ajax_point_fields', array($this, 'point_fields'));
			add_action('wp_ajax_test_balance', array($this, 'test_balance'));
			//convertion process
			$creditConvertController = new CreditConvertionController();
			add_action('wp_ajax_convert_points_to_credits', array($creditConvertController, 'convert_points_to_credits'));
			add_action('wp_ajax_convert_credits_to_points', array($creditConvertController, 'convert_credits_to_points'));

		}
		//deposit front page
		add_action('wp_ajax_forward_to_gateway', array($this, 'forward_to_gateway'));
		//deposit history list
		add_action('wp_ajax_mark_deposit_completed', array($this, 'mark_deposit_completed'));
		add_action('wp_ajax_mark_deposit_suspend', array($this, 'mark_deposit_suspend'));
		//ideal payment
		add_action('wp_ajax_process_ideal_payment', array($this, 'process_ideal_payment'));
		//other
		add_action('wp_ajax_donate_to_user', array($this, 'donate_to_user'));
		add_action('wp_ajax_request_withdrawal', array($this, 'request_withdrawal'));
	}

	public function add_payment_option()
	{
		$obj = new PaymentOptionsController();
		$obj->add();
	}

	public function edit_payment_option()
	{
		$obj = new PaymentOptionsController();
		$obj->edit();
	}

	public function delete_payment_option()
	{
		$obj = new PaymentOptionsController();
		$obj->delete();
	}

	public function get_payment_option()
	{
		$obj = new PaymentOptionsController();
		$obj->getPaymentOption();
	}

	public function get_payment_options()
	{
		$obj = new PaymentOptionsController();
		$obj->getPaymentOptions();
	}

	public function forward_to_gateway()
	{
		$obj = new PaymentOptionsController();
		$obj->forwardToGateway();
	}

	/**
	 * Settings
	 */
	public function update_test_options_settings()
	{
		$obj = new SettingsOptionsController();
		$obj->updateTestOptionsSettings();
	}

	public function update_settings()
	{
		$obj = new SettingsOptionsController();
		$obj->updateSettings();
	}

	public function update_gateway_settings()
	{
		$obj = new SettingsOptionsController();
		$obj->updateGatewaySettings();
	}

	public function setting_add_image()
	{
		$obj = new SettingsOptionsController();
		$obj->settingAddImage();
	}

	public function update_mailtemplate_settings()
	{
		$obj = new SettingsOptionsController();
		$obj->updateMailTemplateSettings();
	}

	public function update_credit_settings()
	{
		$obj = new PointOptionsController();
		$obj->updateSettings();
	}

	public function mark_deposit_completed()
	{
		$obj = new DepositOptionsController();
		$obj->markDepositCompleted();
	}

	public function mark_deposit_suspend()
	{
		$obj = new DepositOptionsController();
		$obj->markDepositSuspend();
	}

	/*
     * iDeal payment
     */
	public function process_ideal_payment()
	{
		$obj = new WPD_Ideal_Gateway();
		$obj->transactionRequest();
	}

	/*
	 * updateRewards
	 */
	public function update_rewards()
	{
		$obj = new RewardsController();
		$obj->updateSettings();
	}

	/*
	 * updateRewards
	 */
	public function add_extra_reward()
	{
		$obj = new RewardsController();
		$obj->add_extra_reward();
	}

	public function generate_custom_views()
	{
		$obj = new SettingsOptionsController();
		$obj->createCustomViews();
	}


	public function point_fields()
	{
		$obj = new SettingsOptionsController();
		$obj->pointFields();
	}

	public function test_balance()
	{
		$obj = new SettingsOptionsController();
		$obj->testBalance();
	}

	/**
	 * function to donate to user
	 *
	 * @return void
	 * */
	public function donate_to_user()
	{
		$obj = new UserController();
		$obj->donate_to_user();
	}

	public function request_withdrawal()
	{
		$wpelements = new WP_elements();
		$obj = new WithdrawalController();
		$obj->request_withdrawal();
	}

	public function get_extra_reward()
	{
		$obj = new RewardsController();
		$obj->getExtraRewardOption();
	}

	public function edit_extra_reward()
	{
		$obj = new RewardsController();
		$obj->editExtraReward();
	}

	public function delete_extra_reward()
	{
		$obj = new RewardsController();
		$obj->deleteExtraReward();
	}
}