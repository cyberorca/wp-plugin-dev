<?php
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';

class WPdepositWoocommerce extends wpdepositAbstractController {

	/**
	 * Add the Gateway to WooCommerce
	 **/
	public function woocommerce_add_wpdeposit_gateway($methods) {
		$methods[] = 'WC_WPDEPOSIT';
		return $methods;
	}

}