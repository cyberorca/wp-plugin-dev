<?php

class WPdepositWidgets extends wpdepositAbstractController {

	public function __construct()
	{

	}

	public function register_widgets()
	{
		do_action('wpds_register_widgets_before');
		require_once WPDEPOSIT_PATH . '/classes/widgets/deposit_balance.php';
		register_widget('deposit_balance');
		do_action('wpds_register_widgets_after');
	}

	public function wpd_save_extra_profile_fields( $user_id )
	{
		do_action('wpds_save_extra_profile_fields_before');
		if ( !current_user_can( 'edit_user', $user_id ) ) {
			return false;
		}

		$userModel = new UserModel($user_id);
		if (WPD_CREDIT_TYPE == 'points') {
			if (isset($_POST['wpdeposit_user_points']) && !empty($_POST['wpdeposit_user_points'])) {
				$amount = (int) $_POST['wpdeposit_user_points'];
				$userModel->updatePointsBalance($amount);
			}

		} else {
			if (isset($_POST[ WPDEPOSIT_NAME . '_user_amount']) && !empty($_POST[ WPDEPOSIT_NAME . '_user_amount'])) {
				$amount = (int) $_POST[ WPDEPOSIT_NAME . '_user_amount' ];
				$userModel->updateRegularBalance( $amount );

			}
			if (isset($_POST[ WPDEPOSIT_NAME . '_reward_amount']) && !empty($_POST[ WPDEPOSIT_NAME . '_reward_amount'])) {
				$rewardAmount = (int) $_POST[ WPDEPOSIT_NAME . '_reward_amount' ];
				$userModel->updateRewardBalance( $rewardAmount );
			}
		}
		do_action('wpds_save_extra_profile_fields_after');
	}

	public function wpd_show_extra_profile_fields( $user )
	{
		$userModel = new UserModel($user->ID);
		do_action('wpds_show_extra_profile_fields_before', $userModel);
		?>
		<h3>WPdeposit</h3>
		<table class="form-table">
			<?php if(WPD_CREDIT_TYPE == 'points'): ?>
				<tr>
					<th><label for="<?php echo WPDEPOSIT_NAME . '_user_points'; ?>"><?php _e('User points', WPDEPOSIT_NAME); ?></label></th>
					<td>
						<input type="text" name="<?php echo WPDEPOSIT_NAME . '_user_points'; ?>" id="<?php echo WPDEPOSIT_NAME . '_user_points'; ?>" value="<?php echo $userModel->getBalance(); ?>" class="regular-text" />
					</td>
				</tr>
			<?php else: ?>
				<tr>
					<th><?php _e('Total Balance', WPDEPOSIT_NAME); ?></th>
					<td>
						<?php echo $userModel->getBalance(); ?>
					</td>
				</tr>
				<tr>
					<th><label for="<?php echo WPDEPOSIT_NAME . '_user_amount'; ?>"><?php _e('Regular Balance', WPDEPOSIT_NAME); ?></label></th>
					<td>
						<input type="text" name="<?php echo WPDEPOSIT_NAME . '_user_amount'; ?>" id="<?php echo WPDEPOSIT_NAME . '_user_amount'; ?>" value="<?php echo $userModel->getRegularBalance(); ?>" class="regular-text" />
					</td>
				</tr>
				<tr>
					<th><label for="<?php echo WPDEPOSIT_NAME . '_user_amount'; ?>"><?php _e('Reward Balance', WPDEPOSIT_NAME); ?></label></th>
					<td>
						<input type="text" name="<?php echo WPDEPOSIT_NAME . '_reward_amount'; ?>" id="<?php echo WPDEPOSIT_NAME . '_reward_amount'; ?>" value="<?php echo $userModel->getRewardBalance(); ?>" class="regular-text" />
					</td>
				</tr>
			<?php endif; ?>
		</table>
		<?php
		do_action('wpds_show_extra_profile_fields_after', $userModel);
	}

}