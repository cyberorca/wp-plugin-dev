<?php
include_once(WPDEPOSIT_PATH . '/models/user.php');

class UserController extends wpdepositAbstractController {

    public function getBalanceInfo($getAmount = false){
        $model = new UserModel();
        $balance = $model->getBalance($this->_user->ID, $getAmount);
        return $balance;
    }
    
    public function display_deposit_balance()
    {
        $userModel = new UserModel($this->_user->ID);
        //@todo: should not be static currency!!!!
        $depositHtml = __('Your current balance is', WPDEPOSIT_NAME) . ': <strong>' . the_credit_type_text(true, $userModel->getBalance(), true, false) . '</strong>';
        echo apply_filters('wpds_display_deposit_balance', $depositHtml);
    }
    
    public function donate_to_user()
    {
        do_action('wpds_donate_to_user_before');
        try{
            if (empty($_POST['donate_amount'])) {
                throw new Exception(__('Amount field cannot be empty', WPDEPOSIT_NAME));
            }
            if (empty($_POST['donate_to_user'])) {
                throw new Exception(__('User field cannot be empty', WPDEPOSIT_NAME));
            }
            if (!floatval($_POST['donate_amount'])) {
                throw new Exception(__('Invalid amount (eg: 10)', WPDEPOSIT_NAME));
            }
            $user = $_POST['donate_to_user'];
            if (!$userInfo = get_user_by('login', $user)) { //no need to validate. the function uses sanitize_user()
                throw new Exception(__('Unable to find the specified user.', WPDEPOSIT_NAME));
            }
            $userId = $userInfo->ID;
	        $amount = wp_kses($_POST['donate_amount'], array());
	        $formatter = new AmountFormatter();
	        $amount = $formatter->validateAmount($amount);
            if ($userId == $this->_user->ID) {
                throw new Exception(__('You cannot donate to yourself.', WPDEPOSIT_NAME));
            }
            $userModel = new UserModel();
            
            //check if user has enougth to donate
            if ($userModel->canAfford($amount) === false) {
                throw new Exception(__('You do not have enough to donate.', WPDEPOSIT_NAME));
            }
            
            //deduct from donating user first. if it fails we abort the donation process
            if (!$userModel->decrementBalance($amount)) {
                throw new Exception(__('Unable to deduct from your account', WPDEPOSIT_NAME));
            }
            
            if (!$success = $userModel->donateToUser($userId, wp_kses($amount, array()), $userInfo)) {
                throw new Exception(__('Unable to donate to user.', WPDEPOSIT_NAME));
            }
            
            $response = json_encode(array(
                'success' => $success, 
                'message' => __('You have successfully donated', WPDEPOSIT_NAME) . ' ' . WPD_CURRENCY . $amount . ' ' . __('to', WPDEPOSIT_NAME) . ' ' . $user, 
                'amount' => WPD_CURRENCY . $userModel->getBalance(),
                ));
            do_action('wpds_donate_to_user_after');
            $this->_wpelements->jsonResponseOutput($response);
        } catch (exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
            $this->_wpelements->jsonResponseOutput($response);
        }
    }
}