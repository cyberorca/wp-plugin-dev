<?php
include_once(WPDEPOSIT_PATH . '/models/user.php');
include_once(WPDEPOSIT_PATH . '/models/withdrawal.php');

class WithdrawalController extends wpdepositAbstractController
{
    public function request_transaction_interface()
    {
        $withdrawalRequest = '';
        $withdrawalsEnabled = WPDEPOSIT_WITHDRAWALS != WithdrawalModel::SETTING_DISABLED;
        $wpelements = new WP_elements();

        $userModel = new UserModel();
        $canWithdrawalAmount = $userModel->getCanWithdrawAmount();

	    $gateways = new WPD_Payment_Gateways();
	    $paymentGatewayList = $gateways->generateFrontendHtml();

        include WPDEPOSIT_PATH . '/views/withdrawal/frontend/request_withdrawal.php';
        return $withdrawalRequest;
    }

    public function request_withdrawal()
    {
        $withdrawalsEnabled = WPDEPOSIT_WITHDRAWALS != WithdrawalModel::SETTING_DISABLED;
        //do_action('wpds_request_to_user_before');
        try{
            if ($withdrawalsEnabled == false) {
                throw new \RuntimeException('Withdrawals disabled');
            }

            if (empty($_POST['request_amount'])) {
                throw new \InvalidArgumentException(__('Amount field cannot be empty', WPDEPOSIT_NAME));
            }
            if (!is_numeric($_POST['request_amount']) || $_POST['request_amount'] < 1) {
                throw new \InvalidArgumentException(__('Invalid amount (eg: 10)', WPDEPOSIT_NAME));
            }
            if (empty($_POST['request_message'])) {
                throw new \InvalidArgumentException(__('Please provide your account info', WPDEPOSIT_NAME));
            }
	        if (empty($_POST['request_gateway'])) {
                throw new \InvalidArgumentException(__('Please provide your desired Payment gateway', WPDEPOSIT_NAME));
            }
            $amount = $_POST['request_amount'];
            $message = wp_kses($_POST['request_message'], array());
            $paymentGateway = wp_kses($_POST['request_gateway'], array());
            $userModel = new UserModel();

            //check if user has enouth to request
            if ($userModel->canWithdraw($amount) === false) {
                throw new \RuntimeException(__('You do not have enough balance to request that amount.', WPDEPOSIT_NAME));
            }

            // save withdrawal
            $withdrawalModel = new WithdrawalModel();
            $success = $withdrawalModel->addWithdrawal($userModel->getId(), $amount, $paymentGateway, WithdrawalModel::STATUS_WAITING, WPDEPOSIT_WITHDRAWALS, $message);
            if ($success === false) {
                throw new \RuntimeException(__('Unable to request withdrawal', WPDEPOSIT_NAME));
            }

            // decrement requested balance so they can not use it or request another withdrawal
            if (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_EVERYTHING) {
                $userModel->decrementBalance($amount);
            } elseif (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_DEPOSITS_ONLY) {
                $userModel->decrementRegularBalance($amount);
            } elseif (WPDEPOSIT_WITHDRAWALS == WithdrawalModel::SETTING_EARNINGS_ONLY) {
                $userModel->decrementRewardBalance($amount);
            }

            $this->sendRequestMail($userModel->getId());

            $response = json_encode(
                array(
                    'success' => $success,
                    'message' => __('You have successfully requested a withdrawel of ', WPDEPOSIT_NAME) . ' ' . WPD_CURRENCY . $amount,
                    'amount' => WPD_CURRENCY . $userModel->getBalance(),
                    'withdrawal_amount' => WPD_CURRENCY . $userModel->getCanWithdrawAmount(),
                )
            );
            //do_action('wpds_request_to_user_after');
            $this->_wpelements->jsonResponseOutput($response);
        } catch (exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
            $this->_wpelements->jsonResponseOutput($response);
        }
    }

    public function overview()
    {
        $withdrawalRequest = $this->request_transaction_interface();
        $withdrawalsEnabled = WPDEPOSIT_WITHDRAWALS != WithdrawalModel::SETTING_DISABLED;

        $userModel = new UserModel();
        $model = new WithdrawalModel();

        if (isset($_GET['action']) && $_GET['action'] == 'cancel') {
            $this->cancelWithdrawal($userModel, $model);
        }

        $withdrawals = $model->getForUser($userModel->getId());

        $pageId = get_queried_object_id();

        include WPDEPOSIT_PATH . '/views/withdrawal/frontend/overview.php';
    }

    protected function cancelWithdrawal($userModel, $withdrawalModel)
    {
        $withdrawalId = $_GET['withdrawalId'];
        $withdrawal = $withdrawalModel->getForId($withdrawalId);
        if ($withdrawal == null || $withdrawal->status != WithdrawalModel::STATUS_WAITING) {
            return;
        }
        $result = $withdrawalModel->cancelWithdrawal($withdrawalId, $userModel->getId());
        if ($result != true) {
            return;
        }

        // give back the money to the user
        if ($withdrawal->source == WithdrawalModel::SETTING_EVERYTHING) {
            $userModel->incrementBalance($withdrawal->amount);
        } elseif ($withdrawal->source == WithdrawalModel::SETTING_DEPOSITS_ONLY) {
            $userModel->incrementRegularBalance($withdrawal->amount);
        } elseif ($withdrawal->source == WithdrawalModel::SETTING_EARNINGS_ONLY) {
            $userModel->incrementRewardBalance($withdrawal->amount);
        }
    }

    public function overviewAdmin()
    {
        $wpelements = new WP_elements();
        try {
            $model = new WithdrawalModel();

            if (isset($_GET['action']) && $_GET['action'] == 'reject') {
                $this->rejectWithdrawal($model);
            }
            if (isset($_GET['action']) && $_GET['action'] == 'markasfinished') {
                $this->markWithdrawalAsFinished($model);
            }

            $model = new WithdrawalModel();
            $withdrawals = $model->getAll();
        } catch(Exception $e) {
            $feedback = '<div class="">' . $e->getMessage() . '</div>';
        }
        include WPDEPOSIT_PATH . '/views/withdrawal/backend/overview.php';
    }

    protected function rejectWithdrawal($withdrawalModel)
    {
        $withdrawalId = $_GET['withdrawalId'];
        $withdrawal = $withdrawalModel->getForId($withdrawalId);
        if ($withdrawal == null || $withdrawal->status != WithdrawalModel::STATUS_WAITING) {
            return;
        }
        $result = $withdrawalModel->updateWithdrawalStatus($withdrawal->id, $withdrawal->user_id, WithdrawalModel::STATUS_REJECTED);
        if ($result != true) {
            return;
        }

        // give back the money to the user
        $userModel = new UserModel($withdrawal->user_id);
        if ($withdrawal->source == WithdrawalModel::SETTING_EVERYTHING) {
            $userModel->incrementBalance($withdrawal->amount);
        } elseif ($withdrawal->source == WithdrawalModel::SETTING_DEPOSITS_ONLY) {
            $userModel->incrementRegularBalance($withdrawal->amount);
        } elseif ($withdrawal->source == WithdrawalModel::SETTING_EARNINGS_ONLY) {
            $userModel->incrementRewardBalance($withdrawal->amount);
        }

        $this->sendRejectMail($withdrawal);
    }

    protected function markWithdrawalAsFinished($withdrawalModel)
    {
        $withdrawalId = $_GET['withdrawalId'];
        $withdrawal = $withdrawalModel->getForId($withdrawalId);
        if ($withdrawal == null || $withdrawal->status != WithdrawalModel::STATUS_WAITING) {
            return;
        }

        $result = $withdrawalModel->updateWithdrawalStatus($withdrawal->id, $withdrawal->user_id, WithdrawalModel::STATUS_PROCESSED);
        if ($result != true) {
            return;
        }

        $this->sendFinishedMail($withdrawal);
    }

    private function sendRequestMail($userId)
    {
        $user = get_userdata($userId);
        $settings = new SettingsOptionsController();
        $headers = "From:" . get_bloginfo('adminmail') . "\r\n";
        $message = 'Hello, <br />'.$user->user_email.' requested a withdrawal on your site.';

        wp_mail(get_bloginfo('adminmail'), "[WPDEPOSIT] Withdrawal Requested", $message, $headers);
    }

    private function sendRejectMail($withdrawal)
    {
        $user = get_userdata($withdrawal->user_id);
        $to = $user->user_email;
        $settings = new SettingsOptionsController();
        $headers = "From:" . get_bloginfo('adminmail') . "\r\n";
        $message = $settings->loadMailTemplate('_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED, array(
            '{USERNAME}' => $this->_user->display_name,
            '{SITENAME}' => get_bloginfo('name'),
            '{SITEURL}' => get_bloginfo('url'),
            '{AMOUNT}' => $withdrawal->amount,
        ));

        wp_mail($to, "Withdrawal Rejected", $message, $headers);
    }

    private function sendFinishedMail($withdrawal)
    {
        $user = get_userdata($withdrawal->user_id);
        $to = $user->user_email;
        $settings = new SettingsOptionsController();
        $headers = "From:" . get_bloginfo('adminmail') . "\r\n";
        $message = $settings->loadMailTemplate('_'. SettingsOptionsController::MAIL_WITHDRAWAL_FINISHED, array(
            '{USERNAME}' => $this->_user->display_name,
            '{SITENAME}' => get_bloginfo('name'),
            '{SITEURL}' => get_bloginfo('url'),
            '{AMOUNT}' => $withdrawal->amount,
        ));

        wp_mail($to, "Withdrawal processed", $message, $headers);
    }

}
