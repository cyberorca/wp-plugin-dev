<?php
include_once WPDEPOSIT_PATH . '/models/deposit_options.php';

class WPdepositAdminWidgets extends wpdepositAbstractController {

	public function __construct()
	{

	}

	function wpdeposit_info() {

		wp_add_dashboard_widget(
			'wpdeposit_info_widget',
			'WPdeposit Stats',
			array($this, 'wpdeposit_info_widget_function')
		);
	}

	/**
	 * Create the function to output the contents of our Dashboard Widget.
	 */
	function wpdeposit_info_widget_function()
	{
		$depositOptions = new DepositOptionsModel();
		$totalDeposits = $depositOptions->getTotalDepositAmount();
		$totalCount = $depositOptions->getTotalCount();
		include WPDEPOSIT_PATH . '/views/widget/admin/wpdeposit_info_widget.php';
	}

}