<?php
include_once(WPDEPOSIT_PATH . '/models/user.php');
include_once(WPDEPOSIT_PATH . '/models/rewards.php');

class RewardsController extends wpdepositAbstractController
{
    public $_actionList = array();
    
    public $_actionPointsList = array();
    
    public function __construct() {
        $model = new RewardsModel();
        //Call all functions and create list of actions to loop through
        $this->defaultRewardActions();
        $this->easyDigitalDownloadsPlugin();

        //loop through actions and call correct function
        foreach($this->_actionList as $action) {
            foreach ($action['items'] as $item) {
	            if ($item['amount']['value'] != '0' && $item['amount']['value'] != '') {
		            $this->_actionPointsList[$item['action']] = $item['amount'];
		            add_action($item['action'], array($this, $item['type']));
	            }

            }
        }

        //get the extra rewards, loop through and call correct function
        $extraRewardValues = $model->getExtraRewardValues();
        if (isset($extraRewardValues['actions'])) {
            foreach ($extraRewardValues['actions'] as $eReward) {
                $this->_actionPointsList[$eReward['action_hook']] = $eReward['action_hook_value'];
                add_action($eReward['action_hook'], array($this, $eReward['action_hook_point_type']));
            }
        }
        parent::__construct();
    }
    
    public function defaultRewardActions()
    {
        $model = new RewardsModel();
        $rewardValues = $model->getRewardValues();
        $this->_actionList = array(
            array(
                'title' => __('Default rewards', WPDEPOSIT_NAME),
                'items' => array(
                    array('action' => 'user_register', 'type' => 'increment', 'amount' => $this->set_value($rewardValues, 'user_register', 0), 'label' => __('On user registration', WPDEPOSIT_NAME)),
                    array('action' => 'comment_post', 'type' => 'increment', 'amount' => $this->set_value($rewardValues, 'comment_post', 0), 'label' => __('User commenting', WPDEPOSIT_NAME)),
                    array('action' => 'draft_to_publish', 'type' => 'increment', 'amount' => $this->set_value($rewardValues, 'draft_to_publish', 0), 'label' => __('From draft to published post', WPDEPOSIT_NAME)),
                    array('action' => 'pending_to_publish', 'type' => 'increment', 'amount' => $this->set_value($rewardValues, 'pending_to_publish', 0), 'label' => __('From pending to publish post', WPDEPOSIT_NAME)),
                )
            )
        );
    }
    
    public function updateSettings()
    {
        $wpelements = new WP_elements();
        $model = new RewardsModel();
        $response = $model->updateRewards();
        $response = json_encode( array('success' => true));
        $wpelements->jsonResponseOutput($response);
    }
    
    public function add_extra_reward()
    {
        try{
            $wpelements = new WP_elements();
            $model = new RewardsModel();
            $response = $model->addReward();
            $return = json_encode( array('success' => true, 'action_hook_info' => $response));
        } catch(Exception $e){
            $return = json_encode( array('success' => false, 'message' => $e->getMessage()));
        }
        $wpelements->jsonResponseOutput($return);
    }
    
    public function set_value($array, $name, $default_value) {
        if (!is_array($array)) {
            return $default_value;
        }
        if (isset($array[$name]) && !empty($array[$name])) {
            return $array[$name];
        } else {
            return $default_value;
        }
    }
    
    /***************************************
     * 
     *    VIEW FUNCTIONS
     * 
     *************************************/
    
    public function overviewAdmin()
    {
        $wpelements = new WP_elements();
        $model = new RewardsModel();
        $rewardValues = $model->getRewardValues();
        $extraRewards = $model->getExtraRewardValues();
        include WPDEPOSIT_PATH . '/views/rewards/backend/overview.php';
    }
    
    /***************************************
     * 
     *    INCREMENT / DECREMENT FUNCTIONS
     * 
     *************************************/
    public function increment($user_id)
    {
        /* Get the hook type by backtracing */
        $backtrace = debug_backtrace();
        $hook_type = $backtrace[2]['args'][0];
        $userModel = new UserModel();
        if (isset($this->_actionPointsList[$hook_type])) {
            $this->_logger->log(sprintf('[REWARD][%s] Added %s to the reward balance of %s.', $hook_type, the_credit_type_text(false, (int) $this->_actionPointsList[$hook_type], true), $userModel->getCurrentUser()->user_login));
            if (!empty($user_id) && is_numeric($user_id)) {
	            $userModel->incrementBalance((int) $this->_actionPointsList[$hook_type]['value'], $user_id);
            } else {
	            $userModel->incrementBalance((int) $this->_actionPointsList[$hook_type]['value']);
            }

        }
    }
    
    public function decrement()
    {
        /* Get the hook type by backtracing */
        $backtrace = debug_backtrace();
        $hook_type = $backtrace[2]['args'][0];
        $userModel = new UserModel();
        if (isset($this->_actionPointsList[$hook_type])) {
            $userModel->decrementBalance($this->_actionPointsList[$hook_type]);
        }
    }
    
    public function selectPointTypeHtml($name, $default = '')
    {
        $html = '<select name="' . $name . '_point_type">';
        $selected = (ucfirst($default) == 'Increment')? 'selected' : '' ;
        $html .= '<option value="increment" ' . $selected . '>' . __('Increment', WPDEPOSIT_NAME) . '</option>';
        $selected = (ucfirst($default) == 'Decrement')? 'selected' : '' ;
        $html .= '<option value="decrement" ' . $selected . '>' . __('Decrement', WPDEPOSIT_NAME) . '</option>';
        $html .= '</select>';
        return $html;
    }
    
    
    /***************************************
     * 
     *    SUPPORT FOR EXTERNAL PLUGIN
     * 
     *************************************/
    public function easyDigitalDownloadsPlugin() 
    {
        $model = new RewardsModel();
        $rewardValues = $model->getRewardValues();
        $this->_actionList[] = array(
            'title' => __('Easy digital download plugin rewards', WPDEPOSIT_NAME),
            'url' => 'http://wordpress.org/plugins/easy-digital-downloads/',
            'items' => array(
                array(
                    'action' => 'edd_complete_purchase', 
                    'type' => 'increment', 
                    'amount' => $this->set_value($rewardValues, 'edd_complete_purchase', 0), 
                    'label' => __('On completing checkout', WPDEPOSIT_NAME)
                    ),//Checkout complete
                array(
                    'action' => 'edd_process_verified_download', 
                    'type' => 'increment', 
                    'amount' => $this->set_value($rewardValues, 'edd_process_verified_download', 0), 
                    'label' => __('On file download', WPDEPOSIT_NAME)
                    ),//file download
            )
        );
    }

	public function getExtraRewardOption()
	{
        $hook = isset($_POST['hook']) ? $_POST['hook'] : false;
		if (!$hook) {
			$response = json_encode(array('success' => false, 'message' => 'Invalid hook. Please check your input'));
			$this->_wpelements->jsonResponseOutput($response);
		}

		$model = new RewardsModel();
		$rewardOption = $model->getByHookName($hook);
		$response = json_encode(array('success' => true, 'record' => $rewardOption));
		$this->_wpelements->jsonResponseOutput($response);
	}

    public function editExtraReward()
    {
        $post = $_POST['form'];
        $hook = (!empty($post)) ? true : false;
        if (!$hook) {
            $response = json_encode(array('success' => false, 'message' => 'Invalid hook. Please check your input'));
            $this->_wpelements->jsonResponseOutput($response);
        }
        foreach($post as $key => $item){
            $data[$item['name']] = $item['value'];
        }

        $model = new RewardsModel();
        $result = $model->editExtraReward($data);
        $response = json_encode(array('success' => $result));
        $this->_wpelements->jsonResponseOutput($response);
    }

    public function deleteExtraReward()
    {
        $hook = $_POST['hook'];
        $valid = (!empty($hook)) ? true : false;
        if (!$valid) {
            $response = json_encode(array('success' => false, 'message' => 'Invalid hook. Please check your input'));
            $this->_wpelements->jsonResponseOutput($response);
        }

        $model = new RewardsModel();
        $result = $model->deleteExtraReward($hook);
        $response = json_encode(array('success' => $result));
        $this->_wpelements->jsonResponseOutput($response);
    }
    
}//end of class