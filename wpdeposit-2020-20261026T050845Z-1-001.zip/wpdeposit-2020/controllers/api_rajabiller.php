<?php
require_once WPDEPOSIT_PATH . '/classes/helpers.php';
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/controllers/api/rajabiller.php';
require_once WPDEPOSIT_PATH . '/controllers/api/siapbayar.php';
require_once WPDEPOSIT_PATH . '/controllers/shortcodes.php';
include_once WPDEPOSIT_PATH . '/models/user.php';
include_once WPDEPOSIT_PATH . '/models/transaction.php';

class ApiRajabillerController extends wpdepositAbstractController
{
    
    /**
     * construct function
     *
     * @return void
     * @author Doni K dan smita CS
     *
     */
    public function __construct()
    {
        parent::__construct();
        global $current_user;
        wp_get_current_user();
        $this->wpusername = $current_user->user_login;
        $this->uid = 'SP61417';
        $this->pin = '232323';
        $this->apiUrl ='https://rajabiller.fastpay.co.id/transaksi/index.php';
    }
    
    private function send_message( $method, $request = array()) { 
        $request = xmlrpc_encode_request($method, $request);
        $context = stream_context_create(
            array('http' => array(
                    'timeout' => 160,
                    'method' => "POST",
                    'header' => "Content-Type: text/xml",
                    'content' => $request
                )
            )
        );
        $file = file_get_contents($this->apiUrl, false, $context);
        $response = xmlrpc_decode($file);
        if ($response && xmlrpc_is_fault($response)){
            trigger_error("xmlrpc: $response[faultString] ($response[faultCode])");
        } else {
            return $response;
        }
    }
    
    /**
     * Show api payment PLN options
     * Payment goes to : rajabiller_api_payment_pln()
     */
    public function rajabiller_api_payment_pln()
    {
        //
    }

    public function rajabiller_api_inquiry_pln()
    {
        $key = [
                        'PLNPASCH' => [
                            'KODE_PRODUK_VALUE',
                            'WAKTU_VALUE',
                            'IDPEL1_VALUE',
                            'IDPEL2_VALUE',
                            'IDPEL3_VALUE',
                            'NAMA_VALUE',
                            'PERIODE_VALUE',
                            'JML_BULAN_VALUE',
                            'NOMINAL_VALUE',
                            'TARIF_VALUE',
                            'DAYA_VALUE',
                            'REF_VALUE',
                            'STAN_AWAL_VALUE',
                            'STAN_AKHIR_VALUE',
                            'INFOTEKS_VALUE',
                            'ADMIN_VALUE',
                            'UID_VALUE',
                            'PIN_VALUE',
                            'REF1_VALUE',
                            'REF2_VALUE',
                            'REF3_VALUE',
                            'STATUS_VALUE',
                            'KETERANGAN_VALUE',
                            'SALDO_TERPORONG_VALUE',
                            'SISA_SALDO_VALUE',
                            'URL_VALUE',
                        ],
                        'PLNPRAH' => [
                            'KODE_PRODUK_VALUE',
                            'WAKTU_VALUE',
                            'IDPEL1_VALUE',
                            'IDPEL2_VALUE',
                            'IDPEL3_VALUE',
                            'NAMA_VALUE',
                            'NOMINAL_VALUE',
                            'TARIF_VALUE',
                            'DAYA_VALUE',
                            'REF_VALUE',
                            'MATERAI_VALUE',
                            'PPN_VALUE',
                            'PPJ_VALUE',
                            'ANGSURAN_VALUE',
                            'POWER_PURCHASE_VALUE',
                            'KWH_VALUE',
                            'TOKEN_VALUE',
                            'INFOTEKS_VALUE',
                            'ADMIN_VALUE',
                            'UID_VALUE',
                            'PIN_VALUE',
                            'REF1_VALUE',
                            'REF2_VALUE',
                            'REF3_VALUE',
                            'STATUS_VALUE',
                            'KETERANGAN_VALUE',
                            'SALDO_TERPOTONG',
                            'SISA_SALDO',
                            'URL_STRUK_VALUE',
                        ],
                    ];
        $html = "
                <style>
                                    div.blueTable {
                                      width: 100%;
                                      text-align: left;
                                      background-color: #EEEEEE;
                                      border:1px solid black;
                                      padding:10px 20px;
                                      border-radius: 5px;
                                      margin: 20px 0;
                                    }
                                    
                                    .hide{
                                        display:none !important;
                                    }
                                    
                                    .show{
                                        display:unset;
                                    }
                                    
                                    .btn{
                                        padding: 9px 7px !important; 
                                        border: none !important;
                                        border-radius: 4px !important;
                                        cursor: pointer !important;
                                        margin:0 5px !important; 
                                        float: right;
                                    }
                                    .btn-primary {
                                        color: #fff !important;
                                        background-color: #007bff !important;
                                        border-color: #007bff !important;
                                        border-radius: 4px !important;
                                    }
                                    .btn-secondary {
                                        color: #fff !important;
                                        background-color: #6c757d !important;
                                        border-color: #6c757d !important;
                                         border-radius: 4px !important;
                                    }
                                    .btn-success {
                                        color: #fff !important;
                                        background-color: #28a745 !important;
                                        border-color: #28a745 !important;
                                        border-radius: 4px !important;
                                    }
                                    .err{
                                        font-size: 10px;
                                        color:red;
                                    }
                                    .badge {
                                        display: inline-block;
                                        padding: .25em .4em;
                                        font-size: 75%;
                                        font-weight: 700;
                                        line-height: 1;
                                        text-align: center;
                                        vertical-align: baseline;
                                        border-radius: .25rem;
                                        transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
                                    }
                                    .badge-danger {
                                        color: #fff;
                                        background-color: #dc3545;
                                    }
                                    
                                    
                                    .divTable.blueTable .divTableCell, .divTable.blueTable .divTableHead {
                                      padding: 3px 2px;
                                    }
                                    .divTable.blueTable .divTableBody .divTableCell {
                                      font-size: 15px;
                                    }
                                    .blueTable .tableFootStyle {
                                      font-size: 14px;
                                    }
                                    .blueTable .tableFootStyle .links {
                                    	 text-align: right;
                                    }
                                    .blueTable .tableFootStyle .links a{
                                      display: inline-block;
                                      background: #1C6EA4;
                                      color: #FFFFFF;
                                      padding: 2px 8px;
                                      border-radius: 5px;
                                    }
                                    .blueTable.outerTableFooter {
                                      border-top: none;
                                    }
                                    .blueTable.outerTableFooter .tableFootStyle {
                                      padding: 3px 5px; 
                                    }
                                    /* DivTable.com */
                                    .divTable{ display: table; }
                                    .divTableRow { display: table-row; }
                                    .divTableHeading { display: table-header-group;}
                                    .divTableCell, .divTableHead { display: table-cell;}
                                    .divTableHeading { display: table-header-group;}
                                    .divTableFoot { display: table-footer-group;}
                                    .divTableBody { display: table-row-group;}
                                    .val{font-weight:bolder;}
								</style>
        ";
        
        if ( is_user_logged_in() ) {
            
            $html .= '
								<form method="post" action="" autocomplete="off">
    								<div class="divTable blueTable">
                                        <div class="divTableBody">
                                            <div class="divTableRow">
                                                <div class="divTableCell">ID Pelanggan</div>
                                                <div class="divTableCell">                                        
                                                    <input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
            										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="" />
            										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
            										<input type="hidden" name="ref1" id="ref1" value="0" /></div>
                                                </div>
                                            <div class="divTableRow">
                                                <div class="divTableCell">Jenis Layanan</div>
                                                <div class="divTableCell">
                                                    <select name="kodeproduk" id="kodeproduk" required>
                    									<option value="">Pilih </option>
                    									<option value="PLNPASCH">Listrik</option>
                    									<option value="PLNPRAH">Token</option>
            									    </select>
        									    </div>
                                            </div>
                                            <div class="divTableRow">
                                                <div class="divTableCell">&nbsp;</div>
                                                <div class="divTableCell">
                                                    <input type="submit" name="submit" value="SEND" class="btn btn-success" />
        									    </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
						';
						
			if ( empty( $_POST ) === false ) {		
			    
                $method = 'rajabiller.inqpln';
    
                $kode_produk = Array2XML::sanitize( $_POST['kodeproduk'] );
    
                $idpelanggan1 = Array2XML::sanitize( $_POST['idpelanggan1'] );
    
                $idpelanggan2 = Array2XML::sanitize( $_POST['idpelanggan2'] );
    
                $idpelanggan3 = Array2XML::sanitize( $_POST['idpelanggan3'] );
    
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                
                $digitCountIdpel = count(str_split($idpelanggan1));
                
                $idpelanggan = $idpelanggan1;
                
                if( $kode_produk == "PLNPRAH" ){
                    
                    if( $digitCountIdpel == 12 ){
            
                        $idpelanggan2 = $idpelanggan1;
                        
                        $idpelanggan1 = '';
                        
                        $idpelanggan3 = '';
                        
                    }
                    
                }
                
                $pb_request = array( $kode_produk, $idpelanggan1, $idpelanggan2, $idpelanggan3, $this->uid, $this->pin, $ref1 );
                
                $pb_response = $this->send_message($method, $pb_request);
                
                $i = 0;
                    
                foreach ( $pb_response as $idx => $response ) {
                    
                    $a[ $key[ $kode_produk ][ $i++ ] ] = $response;
                    
                }
                
                // echo "<pre>";
                // var_dump($a);
                // echo "</pre>";
                
                // if($a['STATUS_VALUE'] == '00') echo "status value " . $a['STATUS_VALUE'];
                
                $rupiah     = number_format($a['NOMINAL_VALUE'] , 2, ',', '.');
                
                $html .= '
                                    <div class="divTable blueTable">
                                        <div class="divTableBody '. ( $a['STATUS_VALUE'] == '00' ? 'hide' : 'show' ) .'">
                                            <div class="divTableRow">
                                            <div class="divTableCell badge badge-danger">' . preg_replace('/(EXT|\:)+/', '',$a['KETERANGAN_VALUE']). '</div>
                                            </div>
                                        </div>
                                        <div class="divTableBody '. ( $a['STATUS_VALUE'] == '00' ? 'show' : 'hide' ) .'">
                                        <div class="contentToPrint">
                                            <div class="divTableRow">
                                                <div class="divTableCell">ID Pelanggan</div>
                                                <div class="divTableCell val">' . $idpelanggan . '</div>
                                            </div>
                                            <div class="divTableRow">
                                                <div class="divTableCell">Nama</div>
                                                <div class="divTableCell val">' . $a['NAMA_VALUE'] . '</div>
                                            </div>
                                            <div class="divTableRow">
                                                <div class="divTableCell">Jumlah Tagihan</div>
                                                <div class="divTableCell val">Rp. ' . $rupiah . '</div>
                                            </div>
                                            <div class="divTableRow">
                                                <div class="divTableCell">Stand Meter</div>
                                                <div class="divTableCell val">' . (isset($a['STAN_AKHIR_VALUE']) ? $a['STAN_AKHIR_VALUE'] : '')  .'-'. ( isset( $a['STAN_AWAL_VALUE'] ) ? $a['STAN_AWAL_VALUE'] : '' ) . ' ( ' . $a['TARIF_VALUE'] . ' )</div>
                                            </div>
                                        </div>
                                        <div class="divTableRow">
                                            <div class="divTableCell"><input type="button" name="cetak" id="printOut" class="btn btn-primary" value="CETAK" /><input type="button" name="bayar" class="btn btn-success" value="BAYAR" /></div>
                                        </div>
                                        </div>
                                    </div> 
                                    <script type="text/javascript">
                                            document.querySelector("input#printOut").addEventListener("click",function(e){
                                                e.preventDefault();
                                                var w = window.open(),
                                                printOne = document.querySelector(".contentToPrint").innerHTML;
                                                w.document.write(`
                                                <html>
                                                    <head>
                                                        <title>Pilihbayar - PLN Transaction Report</title>
                                                        <style>
                                                            table.blueTable {
                                                                border: 1px solid #1C6EA4;
                                                                background-color: #EEEEEE;
                                                                width: 100%;
                                                                text-align: left;
                                                                border-collapse: collapse;
                                                            }
                                                            table.blueTable td, table.blueTable th {
                                                                border: 1px solid #AAAAAA;
                                                                padding: 3px 2px;
                                                            }
                                                            table.blueTable tbody td {
                                                                font-size: 13px;
                                                            }
                                                            table.blueTable tr:nth-child(even) {
                                                                background: #D0E4F5;
                                                            }
                                                            table.blueTable tfoot td {
                                                                font-size: 14px;
                                                            }
                                                            table.blueTable tfoot .links {
                                                                text-align: right;
                                                            }
                                                            table.blueTable tfoot .links a{
                                                                display: inline-block;
                                                                background: #1C6EA4;
                                                                color: #FFFFFF;
                                                                padding: 2px 8px;
                                                                border-radius: 5px;
                                                            }
                                                        </style>
                                                    </head>
                                                    <body>
                                                        <table class="blueTable">
                                                            <tbody>
                                                                <tr>
                                                                    <td>ID Pelanggan</td>
                                                                    <td>' . $idpelanggan . '</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Nama/td>
                                                                    <td>' . $a['NAMA_VALUE'] . '</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Jumlah Tagihan</td>
                                                                    <td>Rp. ' . $rupiah . '</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Stand Meter</td>
                                                                    <td>' . (isset($a['STAN_AKHIR_VALUE']) ? $a['STAN_AKHIR_VALUE'] : '')  .'-'. ( isset( $a['STAN_AWAL_VALUE'] ) ? $a['STAN_AWAL_VALUE'] : '' ) . ' ( ' . $a['TARIF_VALUE'] . ' )</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </body>
                                                </html>
                                                `);
                                                w.window.print();
                                                w.document.close();
                                                return false;
                                            });
                                    </script>                     
                ';
                            
			}
            
        } else {
            
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        
        echo $html;
    }
    
    /**
     * Show a list of api bpjsker options
     */
    public function rajabiller_api_bpjsTK()
    {

        $html = '';
        if (is_user_logged_in()) {
            $_helpersClass = new Helpers();
            $_helpersClass::cdebug('debug', $_POST);

            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                if (isset($_POST['head-tagihan'])) {
                    //populate all the tagihan PDAM value
                    if ($_POST['head-tagihan'] == 1) {
                        $nominal = isset($_POST['tagihan-pdam-nominal']) ? $_POST['tagihan-pdam-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pdam-idpelanggan1']) ? $_POST['tagihan-pdam-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pdam-ref1']) ? $_POST['tagihan-pdam-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pdam-ref2']) ? $_POST['tagihan-pdam-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pdam-ref3']) ? $_POST['tagihan-pdam-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pdam-kodeproduk']) ? $_POST['tagihan-pdam-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pdam']);

                    }

                    //populate all the tagihan PLN value
                    if ($_POST['head-tagihan'] == 2) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pln']);

                    }

                    //populate all the tagihan Telkom value
                    if ($_POST['head-tagihan'] == 3) {
                        $nominal = isset($_POST['tagihan-telkom-nominal']) ? $_POST['tagihan-telkom-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-telkom-idpelanggan1']) ? $_POST['tagihan-telkom-idpelanggan1'] : '';
                        $idpelanggan2 = isset($_POST['tagihan-telkom-idpelanggan2']) ? $_POST['tagihan-telkom-idpelanggan2'] : '';
                        $ref1 = isset($_POST['tagihan-telkom-ref1']) ? $_POST['tagihan-telkom-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-telkom-ref2']) ? $_POST['tagihan-telkom-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-telkom-ref3']) ? $_POST['tagihan-telkom-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-telkom-kodeproduk']) ? $_POST['tagihan-telkom-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan Pascabayar value
                    if ($_POST['head-tagihan'] == 4) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan TV value
                    if ($_POST['head-tagihan'] == 5) {
                        $nominal = isset($_POST['tagihan-tv-nominal']) ? $_POST['tagihan-tv-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-tv-idpelanggan1']) ? $_POST['tagihan-tv-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-tv-ref1']) ? $_POST['tagihan-tv-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-tv-ref2']) ? $_POST['tagihan-tv-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-tv-ref3']) ? $_POST['tagihan-tv-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-tv-kodeproduk']) ? $_POST['tagihan-tv-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }
                    $rawHtml = '<div id="contact-area">
    								<h2 style="text-align: right">Pembayaran Tagihan</h2><br>
    								<form method="post" action="" autocomplete="off">
    									<label for="kodeproduk">Kode Produk</label>
    									<select name="kodeproduk" id="kodeproduk" required>
    										<option value="">Pilih </option>


    										<option value="TELEPON">Telkom/Flexi</option>


    									</select>
    									<br/>

    									<label for="idpelanggan1">ID Pelanggan 1</label>
    										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan"  value="' . $idpelanggan1 . '" required />
    									<br/>
    									<label for="idpelanggan2">ID Pelanggan 2</label>
    										<input type="text" name="idpelanggan2" id="idpelanggan2" value="' . $idpelanggan2 . '"   />
    									<br/>
    									<label for="idpelanggan3">-</label>
    										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
    									<br/>
    									<label for="nominal">Nominal</label>
    										<input type="text" name="nominal" id="nominal" placeholder="Nominal" value="' . $nominal . '" required />
    									<br/>

    									<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"   />
    									<label for="ref2">No Referensi</label>
    										<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '" required   />
    									<br/>
    									<input type="hidden" name="ref3" id="ref3" value="' . $ref3 . '"  />
    									<input type="submit" name="submit" value="Bayar" class="btn btn-success" />

    								</form>
    								<div style="clear: both;"></div>

    							</div>';

                    $html .= str_replace('value="' . $selectedKode . '"', 'value="' . $selectedKode . '" selected', $rawHtml);
                } else {
                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < 12000) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    #print_r($_POST);
                    //method rajabiller untuk
                    $method = 'rajabiller.pay';

                    //kode produk
                    $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                    //id pelanggan
                    $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                    //id pelanggan
                    $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                    //id pelanggan
                    $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                    //nominal
                    $nominal = Array2XML::sanitize($_POST['nominal']);

                    //User ID SP Anda
                    $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                    //PIN ID SP Anda
                    $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                    //ref
                    $ref1 = Array2XML::sanitize($_POST['ref1']);

                    //ref
                    $ref2 = Array2XML::sanitize($_POST['ref2']);

                    //ref
                    $ref3 = Array2XML::sanitize($_POST['ref3']);

                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < $nominal + 500) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    if (empty($kodeproduk)) {
                        $html .= 'harus diisi';
                    } else {

                        //generate ke XML
                        $tes_xml = array(
                            'methodName' => array(
                                '@value' => $method,
                                //nama method

                            ),
                            'params' => array(
                                'param' => array(

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($kodeproduk), //kode produk

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan1),
                                            //id pelanggan 1

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan2),
                                            //id pelanggan 2

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan3),
                                            //id pelanggan 3

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($nominal), // nominal

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($uid), //User ID Anda

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($pin), //Pin Anda

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref1), //ref1

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref2), //ref2

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref3), //ref3

                                        ),
                                    ),
                                ),
                            ),
                        );

                        $xml = Array2XML::createXML('methodCall', $tes_xml);

                        //jika  tidak ingin melihat request hilangkan kode dibawah
                        //lihat request xml yg akan dikirim
                        $send = $xml->saveXML();

                        //Alamat URL yang di hit ke rajabiller
                        $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_VERBOSE, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_REFERER, $url);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/text',
                        ));
                        $data = curl_exec($ch);

                        if ($data === false) {
                            printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                            rewind($verbose);
                            $verboseLog = stream_get_contents($verbose);
                            $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                        }

                        $errno = curl_errno($ch);
                        $error = curl_error($ch);

                        if ($errno > 0) {
                            $result = 'null';
                        } else {
                            $result = $data;
                        }

                        //close connection
                        curl_close($ch);

                        //jika tidak ingin melihat response, hilangkan kode dibawah
                        #echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                        //
                        $dom = new DOMDocument;
                        //result
                        $dom->loadXML($result);

                        //pengambilan string dari node <string></string> pada response xml rajabiller
                        $arrays = $dom->getElementsByTagName('string');

                        // membuat array untuk inisiasi masing2 string xml
                        $key = array(
                            'KODEPRODUK',
                            'WAKTU(YYYYMMDDHHIISS)',
                            'IDPELANGGAN1',
                            'IDPELANGGAN2',
                            'IDPELANGGAN3',
                            'NAMAPELANGGAN',
                            'PERIODETAGIHAN',
                            'NOMINAL',
                            'BIAYAADMIN',
                            'UID',
                            'PIN',
                            'REF1',
                            'REF2',
                            'REF3',
                            'STATUS',
                            'KETERANGAN',
                            'SALDOTERPOTONG',
                            'SISASALDO',
                            'URLSTRUK',
                        );
                        //

                        $i = 0;
                        foreach ($arrays as $array) {
                            $a[$key[$i++]] = $array->nodeValue;
                        }

                        if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                            //salah
                            $html .= '<b>Something went wrong!</b><br>';
                            $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';

                        } else {
                            //echopre($a);
                            $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                            $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                            $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                            $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                            $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                            $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                            $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                            $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                            $tgl = date("j F Y, g:i a", $mydate);
                            $userId = $userModel;
                            $member = $userId;
                            $penjumlahan = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] + 600), 2, ',', '.');
                            $potongan = number_format(Array2XML::sanitize($a['NOMINAL'] + 500), 2, ',', '.');
                            $html .= "
        								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
        								<tr>
        									<th colspan='2'>Bukti Pembayaran tagihan </th>
</tr>
<tr>
									<th colspan='2'>Nama Loket : $this->wpusername</th>
</tr>
<tr>
        									<th colspan='2'> </th>
        								</tr>
        								<tr>
        									<td id='left-td'>Nama Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>ID Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

        								</tr>
<tr>
        									<td id='left-td'>ID Pelanggan2</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>Periode Bulan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tanggal Tagihan</td>
        									<td id='right-td'>{$tgl}</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Biaya Admin</td>
        									<td id='right-td'>Rp. 3000</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Pembayaran</td>
        									<td id='right-td'>Rp.{$penjumlahan}</td>
        								</tr>
        								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

        								<tr>
        									<td id='left-td'>No Transaksi</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Khusus Token</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
        								</tr>


        								</table>

        								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
        							";
                            //cut deposit from user
                            $marginAdmin = 400; //keuntungan admin
                            $marginProvider = 100; //keuntungan provider
                            $decrementVal = $a['NOMINAL'] + $marginAdmin + $marginProvider;
                            $userModel->decrementRegularBalance($decrementVal);

                            //save transaction in wpdeposit transaction table
                            $userId = $userModel->getId();
                            $itemId = 0;
                            $amount = $decrementVal;
                            $addon = '';
                            $message = 'ID ' . $a['IDPELANGGAN1'] . $a['NAMAPELANGGAN'] . $penjumlahan . $a['KETERANGAN'] . $a['URLSTRUK'];
                            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        } //if status  == 00

                    } //if not empty kode produk

                } //if not bayar tagihan

            } //empty post

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        } //if user not login
        echo $html;
    }

    /**
     * Show a list of api bpjsker options
     */
    public function rajabiller_api_bpjskes()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.bpjsinq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);
                //nomor
                $nobpjs = Array2XML::sanitize($_POST['nobpjs']);

                //periode tagihan
                $periodepembayaran = Array2XML::sanitize($_POST['periodepembayaran']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323 '; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($nobpjs) || empty($periodepembayaran)) {
                    $html .= 'nobpjs dan periode tagihan diisi.';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nobpjs), //nobpjs

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($periodepembayaran),
                                        //periode tagihan

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //"<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'NOMINALADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>hanya untuk BPJS Mandiri</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 1200), 2, ',', '.');
                        $biaya = number_format(Array2XML::sanitize(1200), 2, ',', '.');
                        $jumlahTotalByr = $a['NOMINAL'] + $a['NOMINALADMIN'] + 0 - 400;
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['NOMINALADMIN'] + 0 - 400), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(400), 2, ',', '.');
                        $petunjuk = "Bank BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai Nominal Total Bayar";
                        $garansi = "Telegram / whatsapp ke 0856 336 3188";
                        $member = "$a[IDPELANGGAN1]";
                        $html .= "
							<table  style='width:100%'>
							<tr>
								<th colspan='2'>DAFTAR TAGIHAN BPJS KESEHATAN</th>
</tr>
<tr>
								<th colspan='2'> </th>
							</tr>
							<tr>
								<td id='left-td'>Nama Pelanggan</td>
								<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

							</tr>

							<tr>
								<td id='left-td'>Nomor BPJS</td>
								<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>
							</tr>
							<tr>
								<td id='left-td'>Periode Bulan</td>
								<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
							</tr>
							<tr>
								<td id='left-td'>Tanggal Tagihan</td>
								<td id='right-td'>{$tgl}</td>
							</tr>
							<tr>
								<td id='left-td'>tagihan</td>
								<td id='right-td'>Rp. {$rupiah} </td>
							</tr>
							<tr>
								<td id='left-td'>Biaya Admin</td>
								<td id='right-td'>Rp. {$biaya}</td>
							</tr>


							<tr>
								<td id='left-td'>Total tagihan BPJS</td>
								<td id='right-td'>Rp. {$total} </td>
							</tr>

							<tr>
								<td id='left-td'>Nomor</td>
								<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
							</tr>

							</table>
							<form action='https://pilihbayar.com/pembayaran-bpjs/' method='POST'>
							    <input type='hidden' name='head-tagihan-bpjskes' value='1'>
								<input type='hidden' name='tagihan-bpjskes-periode' value='{$periodepembayaran}'>
								<input type='hidden' name='tagihan-bpjskes-nominal' value='{$a['NOMINAL']}'>
								<input type='hidden' name='tagihan-bpjskes-nobpjs' value='{$nobpjs}'>
								<input type='hidden' name='tagihan-bpjskes-nobpjs' value='{$nobpjs}'>
								<input type='hidden' name='tagihan-bpjskes-ref1' value='{$a['REF1']}'>
								<input type='hidden' name='tagihan-bpjskes-ref2' value='{$a['REF2']}'>
								<input type='hidden' name='tagihan-bpjskes-ref3' value='{$a['REF3']}'>
								<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
							</form>


						";

                    }
                }
            } else {
                $html .= '  <div id="contact-area">
							<h2 style="text-align: right"> BPJS Kesehatan </h2><br>
							<form method="post" action="" autocomplete="off">
							<input type="hidden" name="kodeproduk" id="kodeproduk" value="ASRBPJSKS" required />
								<input type="text" name="nobpjs" id="NOBPJS" placeholder="No BPJSKes" required />

								<select name="periodepembayaran" id="periodepembayaran" required>
								<option value="">Pilih Jumlah Bulan Bayar</option>
								<option value="1">1 bulan</option> <option value="2">2 bulan</option>  <option value="3">3 bulan</option>
								<option value="4">4 bulan</option> <option value="5">5 bulan</option>
								<option value="6">6 bulan</option> <option value="7">7 bulan</option>
								<option value="8">8 bulan</option>
								<option value="9">9 bulan</option> <option value="10">10 bulan</option>
								<option value="11">11 bulan</option> <option value="12">12 bulan</option>
							</select>
								<input type="hidden" name="ref1" id="ref1" value="0" required />
								<input type="submit" name="submit" value="SEND" class="submit-button" />
							</form>
							<div style="clear: both;"></div>
						</div>
				';
            }
            //include WPDEPOSIT_PATH . '/views/api/frontend/rajabiller_form.php';

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show payment api bpjsker options
     */
    public function rajabiller_api_paybpjs()
    {

        $html = '';
        if (is_user_logged_in()) {
            #var_dump($_POST);
            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false && !isset($_POST['head-tagihan-bpjskes'])) {

                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                //method rajabiller untuk
                $method = 'rajabiller.bpjspay';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //No bpjs
                $nobpjs = Array2XML::sanitize($_POST['nobpjs']);

                //periode bulan
                $periodebulan = Array2XML::sanitize($_POST['periodebulan']);

                //no hp
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //nominal
                $nominal = Array2XML::sanitize($_POST['nominal']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref1
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //ref2
                $ref2 = Array2XML::sanitize($_POST['ref2']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < $nominal + 500) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($ref2)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nobpjs), //no bpjs

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($periodebulan),
                                        // periodebulan

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // no hp

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nominal), // nominal

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref2), //ref2

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPEL1',
                        'IDPEL2',
                        'IDPEL3',
                        'NAMAPELANGGAN',
                        'PERIODE',
                        'NOMINAL',
                        'NOMINALADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                        'CATATAN',
                        'CATATANVALUE',
                        'NOHP',
                        'NOHPVALUE',
                        'NOREFERENSI',
                        'NOREFERENSIVALUE',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= "<b>" . Array2XML::sanitize($a['KETERANGAN']) . '</b><br><br>';
                    } else {

                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $penjumlahan = $a['NOMINAL'] + $a['NOMINALADMIN'] + 500;
                        $html .= "
                                <style type='text/css'>
                                @media print
                                {
                                body * { visibility: hidden; }
                                table.table_pembayaran_tagihan * { visibility: visible; }
                                table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
                                }
                                </style>

                                <table  style='width:100%' class='table_pembayaran_tagihan'>								<tr>
                                                                    <th colspan='2'>Bukti Pembayaran tagihan</th>
                                </tr>
                                <tr>
                                                                    <th colspan='2'>Nama Loket : $this->wpusername</th>
                                </tr>
                                <tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Periode Bulan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODE']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Nomor BPJS</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPEL1']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>Pembayaran</td>
									<td id='right-td'>Rp.{$penjumlahan}</td>
								</tr>
<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>



								<tr>
									<td id='left-td'>No Transaksi</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>



								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
							";

                        //cut deposit from user
                        $marginAdmin = 100; //keuntungan admin
                        $marginProvider = 400; //keuntungan provider
                        $decrementVal = $a['NOMINAL'] + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'ID ' . $a['IDPEL1'] . $a['NAMAPELANGGAN'] . $penjumlahan . $a['KETERANGAN'] . $a['URLSTRUK'];
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                    }

                }
            } else {
                //populate all the tagihan value
                $nominal = isset($_POST['tagihan-bpjskes-nominal']) ? $_POST['tagihan-bpjskes-nominal'] : '';
                $periode = isset($_POST['tagihan-bpjskes-periode']) ? $_POST['tagihan-bpjskes-periode'] : '';
                $nobpjs = isset($_POST['tagihan-bpjskes-nobpjs']) ? $_POST['tagihan-bpjskes-nobpjs'] : '';
                $ref1 = isset($_POST['tagihan-bpjskes-ref1']) ? $_POST['tagihan-bpjskes-ref1'] : 0;
                $ref2 = isset($_POST['tagihan-bpjskes-ref2']) ? $_POST['tagihan-bpjskes-ref2'] : 0;
                $ref3 = isset($_POST['tagihan-bpjskes-ref3']) ? $_POST['tagihan-bpjskes-ref3'] : 0;

                //empty the tagihan flag
                unset($_POST['head-tagihan-bpjskes']);

                $html .= '  <div id="contact-area">
							<h2 style="text-align: right">Pembayaran BPJS</h2><br>
							<form method="post" action="" autocomplete="off">
							 <input type="hidden" name="kodeproduk" id="kodeproduk" value="ASRBPJSKS"  required />
								<label for="nobpjs">No. BPJS</label>
								<input type="text" name="nobpjs" id="nobpjs" placeholder="nobpjs"  value="' . $nobpjs . '" required />
								<br/>
								<label for="periodebulan">Periode (Bulan)</label>
								<input type="text" name="periodebulan" id="periodebulan" placeholder="periode bulan"  value="' . $periode . '" required  />
								<br/>
								<label for="nohp">No Handphone</label>
								<input type="hidden" name="nohp" id="nohp" value="08563363188"  required />
								<br/>
								<label for="nominal">Nominal Pembayaran</label>
								<input type="text" name="nominal" id="nominal" placeholder="Nominal"  value="' . $nominal . '" required />

								<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"  required   />
								<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '"  required />
								<input type="hidden" name="ref3" id="ref3"  placeholder="No Ref" value="' . $ref3 . '"  required />

								<input type="submit" name="submit" value="SEND" class="submit-button" />
							</form>
							<div style="clear: both;"></div>
						</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show payment api PDAM , PLN and Telkom options
     */
    public function rajabiller_api_payment()
    {
        $html = '';
        if (is_user_logged_in()) {
            $_helpersClass = new Helpers();
            $_helpersClass::cdebug('debug', $_POST);

            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                if (isset($_POST['head-tagihan'])) {
                    //populate all the tagihan PDAM value
                    if ($_POST['head-tagihan'] == 1) {
                        $nominal = isset($_POST['tagihan-pdam-nominal']) ? $_POST['tagihan-pdam-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pdam-idpelanggan1']) ? $_POST['tagihan-pdam-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pdam-ref1']) ? $_POST['tagihan-pdam-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pdam-ref2']) ? $_POST['tagihan-pdam-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pdam-ref3']) ? $_POST['tagihan-pdam-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pdam-kodeproduk']) ? $_POST['tagihan-pdam-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pdam']);

                    }

                    //populate all the tagihan PLN value
                    if ($_POST['head-tagihan'] == 2) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pln']);

                    }

                    //populate all the tagihan Telkom value
                    if ($_POST['head-tagihan'] == 3) {
                        $nominal = isset($_POST['tagihan-telkom-nominal']) ? $_POST['tagihan-telkom-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-telkom-idpelanggan1']) ? $_POST['tagihan-telkom-idpelanggan1'] : '';
                        $idpelanggan2 = isset($_POST['tagihan-telkom-idpelanggan2']) ? $_POST['tagihan-telkom-idpelanggan2'] : '';
                        $ref1 = isset($_POST['tagihan-telkom-ref1']) ? $_POST['tagihan-telkom-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-telkom-ref2']) ? $_POST['tagihan-telkom-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-telkom-ref3']) ? $_POST['tagihan-telkom-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-telkom-kodeproduk']) ? $_POST['tagihan-telkom-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan Pascabayar value
                    if ($_POST['head-tagihan'] == 4) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan TV value
                    if ($_POST['head-tagihan'] == 5) {
                        $nominal = isset($_POST['tagihan-tv-nominal']) ? $_POST['tagihan-tv-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-tv-idpelanggan1']) ? $_POST['tagihan-tv-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-tv-ref1']) ? $_POST['tagihan-tv-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-tv-ref2']) ? $_POST['tagihan-tv-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-tv-ref3']) ? $_POST['tagihan-tv-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-tv-kodeproduk']) ? $_POST['tagihan-tv-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }
                    $rawHtml = '<div id="contact-area">
    								<h2 style="text-align: right">Pembayaran Tagihan</h2><br>
    								<form method="post" action="" autocomplete="off">
    									<label for="kodeproduk">Kode Produk</label>
    									<select name="kodeproduk" id="kodeproduk" required>
    										<option value="">Pilih </option>
    										<option value="WAAETRA">AETRA Jakarta</option>
    										<option value="WAPLYJ">PALYJA Jakarta</option>
                                            <option value="WABEKASI">Kota Bekasi</option>
    										<option value="WABULELENG">Buleleng Bali</option>
    										<option value="WASLMN">Sleman Yogyakarta</option>
    										<option value="WAKABBDG">KAB. Bandung</option>
    										<option value="WABDG">Kota Bandung</option>
    										<option value="WABOGOR">Kab Bogor</option>
    										<option value="WAJAMBI">Kota Jambi</option>
    										<option value="WABYMS">Kab. Banyumas</option>
    										<option value="WABYL">Kab Boyolali</option>
    										<option value="WABREBES">Kab Brebes</option>
    										<option value="WACLCP">Kab Cilacap</option>
    										<option value="WAGROBGAN">Kab Grobogan</option>
    										<option value="WAJPR">Kab Jepara</option>
    										<option value="WAKARANGA">Kab Karanganyar</option>
    										<option value="WAKBMN">Kab Kebumen</option>
    										<option value="WAKNDL">Kab Kendal</option>
                                            <option value="WABATANG">Kab Batang</option>
    										<option value="WAMGLG">Kab Magelang</option>
    										<option value="WAKPKLNGAN">Kab Pekalongan</option>
    										<option value="WAPBLINGGA">Kab Purbalingga(jateng)</option>
    										<option value="WAPURWORE">Kab Purworejo</option>
    										<option value="WAREMBANG">Kab Rembang</option>
    										<option value="WAKABSMG">Kab Semarang</option>
    										<option value="WASMG">Kota Semarang</option>
    										<option value="WASRAGEN">Kab Sragen</option>
    										<option value="WATEMANGG">Kab Temanggung</option>
    										<option value="WAWONOGIRI">Kab Wonogiri</option>
    										<option value="WAWONOSB">Kab Wonosobo</option>
    										<option value="WASLTIGA">Kab Salatiga</option>
    										<option value="WAKOSOLO">Kota Surakarta</option>
    										<option value="WABGK">Kab Bangkalan</option>
    										<option value="WABJN">Kab Bojonegoro</option>
    										<option value="WABONDO">Kab Bondowoso</option>
    										<option value="WAJMBR">Kab Jember</option>
    										<option value="WAKABMLG">Kab Malang</option>
                                            <option value="WAMLG">Kota Malang</option>
    										<option value="WAMJK">Kab Mojokerto</option>
    										<option value="WAPASU">Kab Pasuruan</option>
    										<option value="WAPROLING">Kab Probolinggo</option>
    										<option value="WASDA">Kab Sidoarjo</option>
    										<option value="WASITU">Kab Situbondo</option>
    										<option value="WATUBAN">Kab Tuban</option>
    										<option value="WASBY">Kota Surabaya</option>
    										<option value="WAMADIUN">Kota Madiun</option>
    										<option value="WANGAWI">Kab Ngawi</option>
    										<option value="WAKUNING">Kab Kuningan</option>
                                            <option value="WAPONOR">PDAM PONOROGO</option>
    										<option value="WAKUBURAYA">Kab Kuburaya(kalbar)</option>
    										<option value="WAPONTI">Kota pontianak</option>
    										<option value="WATAPIN">Kab Tapin(kalsel)</option>
    										<option value="WAIBANJAR">Kab Banjarbaru(kalsel)</option>
    										<option value="WAGROGOT">Kota Tanahgrogot Kaltim</option>
    										<option value="WALMPNG">Kota Bandarlampung</option>
    										<option value="WAGIRIMM">Kota Mataram</option>
    										<option value="WALOMBOKT">Kab LombokTengah</option>
    										<option value="WAMANADO">Kota Manado</option>
    										<option value="WAPLMBNG">Kota Palembang</option>
                                            <option value="WAMEDAN">Kota Medan Sumatra Utara</option>
                                            <option value="WADEPOK">Kota DEPOK jawa barat</option>
                                            <option value="WAKABBKS">KAB BEKASI</option>
                                            <option value="WAKOPASU"> KOTA PASURUAN (JATIM)</option>
                                            <option value="WAKLUNGK"> KAB. KLUNGKUNG</option>
                                            <option value="WASAMPANG">  KAB. SAMPANG (JATIM)</option>
                                            <option value="WASLTIGA">   KOTA SALATIGA (JATENG)</option>
                                            <option value="WAKOBOGOR">Kota Bogor</option>
                                            <option value="WAKLATEN">Kab Klaten</option>
                                            <option value="WAKRWNG">KAb Karawang</option>
                                            <option value="WABALIKPPN">Kota Balikpapan</option>
                                            <option value="WAMAKASAR">Kota Makasar</option>
                                            <option value="ASRBPJSTK">BPJS KETENAGAKERJAAN</option>
                                            <option value="WAPBLINGGA">Kab Purbalingga</option>
                                            <option value="WAKPROGO">Kab Kulon Progo</option>
                                            <option value="WABATAM">ATB BATAM</option>
                                            <option value="WAMAGETAN">Kab Magetan</option>
                                            <option value="WAKOPROB">KOta Probolinggo</option>
                                            <option value="WALMJNG">Kab Lumajang</option>
                                            <option value="WABYMS">Kab Banyumas</option>
                                            <option value="WAMGLG">KAb Magelang</option>
                                            <option value="WASLMN">Kab Sleman DIY</option>
    										<option value="PLNPRAH">TOKEN</option>
    										<option value="PLNPASCH">Tagihan Listrik</option>
    										<option value="PLNNONH">Non Taglis</option>
    										<option value="TELEPON">Telkom/Flexi</option>
    										<option value="SPEEDY">Speedy</option>
    										<option value="HPTSEL">Telkomsel</option>
    										<option value="HPXL">XL Eksplore</option>
    										<option value="HPMTRIX">Indosat (Matrix) 	</option>
    										<option value="HPESIA">Esia (Postpaid) 	</option>
    										<option value="HPFREN">FREN, MOBI, HEPI (POSTPAID)</option>
    										<option value="HPSMART">SMARTFREN (POSTPAID)</option>
    										<option value="HPTHREE">THREE (Postpaid)</option>
    										<option value="FNADIRAH">AdiraMotor</option>
                                            <option value="FNBIMA">BIMA FINANCE</option>
                                            <option value="FNHCI">Home Credit Indonesia</option>
                                            <option value="FNCLMB">COLUMBIA</option>
                                            <option value="FNADIRAP">Adiralainnya</option>
                                            <option value="FNBAF">BAF</option> <option value="FNWOM">WOMFinance</option>
    										<option value="ASRJWS">Jiwasraya</option>
    										<option value="ASRTOKIOS">TOKIO MARINE </option>
    										<option value="ASRTOKIO">TOKIO MARINE allbill</option>
    										<option value="TVINDVS">IndoVision</option> <option value="TVINDVS">Top TV</option>  <option value="TVINDVS">Oke Vision</option> <option value="TVTLKMV">Transv Vision</option> <option value="TVTLKMV">Telkom vision</option> <option value="TVTLKMV">Yes TV</option> <option value="TVNEX">Nex Media</option> <option value="TVTOPAS">Topas TV</option>
    										<option value="TVORANGE">Orange TV</option> <option value="TVBIG">BIG TV</option> <option value="TVINNOV">Innovate TV</option>
                                            <option value="TVKV50">K VISION (50.000)</option>
                                            <option value="TVKV75">K VISION (75.000)</option>
                                            <option value="TVKV100">K VISION (100.000)</option>
                                            <option value="TVKV125">K VISION (125.000)</option>
                                            <option value="TVKV150">K VISION (150.000)</option>
                                            <option value="TVKV175">K VISION (175.000)</option>
                                            <option value="TVKV200">K VISION (200.000)</option>
                                            <option value="TVKV250">K VISION (250.000)</option>
                                            <option value="TVKV300">K VISION (300.000)</option>
                                            <option value="TVKV500">K VISION (500.000)</option>
                                            <option value="TVKV750">K VISION (750.000)</option>
                                            <option value="TVKV1000">K VISION (1.000.000)</option>
                                            <option value="TVSKYFAM1">SKYNINDO TV FAMILY 1 BLN (40.000)</option>
                                            <option value="TVSKYFAM3">SKYNINDO TV FAMILY 3 BLN (120.000)</option>
                                            <option value="TVSKYFAM6">SKYNINDO TV FAMILY 6 BLN (240.000)</option>
                                            <option value="TVSKYFAM12">SKYNINDO TV FAMILY 12 BLN (480.000)</option>
                                            <option value="TVSKYDEL1">SKYNINDO TV DELUXE 1 BLN (80.000)</option>
                                            <option value="TVSKYDEL3">SKYNINDO TV DELUXE 3 BLN (240.000)</option>
                                            <option value="TVSKYDEL6">SKYNINDO TV DELUXE 6 BLN (480.000)</option>
                                            <option value="TVSKYDEL12">SKYNINDO TV DELUXE 12 BLN (960.000)</option>
                                            <option value="TVSKYMAN1">SKYNINDO TV MANDARIN 1 BLN (140.000)</option>
                                            <option value="TVSKYMAN3">SKYNINDO TV MANDARIN 3 BLN (420.000)</option>
                                            <option value="TVSKYMAN6">SKYNINDO TV MANDARIN 6 BLN (840.000)</option>
                                            <option value="TVSKYMAN12">SKYNINDO TV MANDARIN 12 BLN (1.680.000)</option>
                                            <option value="TVGEN25">GENFLIX (25.000)</option>
                                            <option value="TVGEN50">GENFLIX (50.000)</option>
                                            <option value="TVGEN100"> GENFLIX (50.000)</option>
                                            <option value="GAS"> PERTAGAS</option>
                                            <option value="PGN"> PGN</option>
                                            <option value="PKBBANTEN">PajaKKENDARAAN BANTEN</option>
    									</select>
    									<br/>

    									<label for="idpelanggan1">ID Pelanggan 1</label>
    										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan"  value="' . $idpelanggan1 . '" required />
    									<br/>
    									<label for="idpelanggan2">-</label>
    										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value=""   />
    									<br/>
    									<label for="idpelanggan3">-</label>
    										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
    									<br/>
    									<label for="nominal">Nominal</label>
    										<input type="text" name="nominal" id="nominal" placeholder="Nominal" value="' . $nominal . '" required />
    									<br/>

    									<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"   />
    									<label for="ref2">No Referensi</label>
    										<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '" required   />
    									<br/>
    									<input type="hidden" name="ref3" id="ref3" value="' . $ref3 . '"  />
    									<input type="submit" name="submit" value="Bayar" class="btn btn-success" />

    								</form>
    								<div style="clear: both;"></div>

    							</div>';

                    $html .= str_replace('value="' . $selectedKode . '"', 'value="' . $selectedKode . '" selected', $rawHtml);
                } else {
                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < 12000) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    #print_r($_POST);
                    //method rajabiller untuk
                    $method = 'rajabiller.pay';

                    //kode produk
                    $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                    //id pelanggan
                    $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                    //id pelanggan
                    $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                    //id pelanggan
                    $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                    //nominal
                    $nominal = Array2XML::sanitize($_POST['nominal']);

                    //User ID SP Anda
                    $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                    //PIN ID SP Anda
                    $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                    //ref
                    $ref1 = Array2XML::sanitize($_POST['ref1']);

                    //ref
                    $ref2 = Array2XML::sanitize($_POST['ref2']);

                    //ref
                    $ref3 = Array2XML::sanitize($_POST['ref3']);

                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < $nominal + 500) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    if (empty($kodeproduk)) {
                        $html .= 'harus diisi';
                    } else {

                        //generate ke XML
                        $tes_xml = array(
                            'methodName' => array(
                                '@value' => $method,
                                //nama method

                            ),
                            'params' => array(
                                'param' => array(

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($kodeproduk), //kode produk

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan1),
                                            //id pelanggan 1

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan2),
                                            //id pelanggan 2

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan3),
                                            //id pelanggan 3

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($nominal), // nominal

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($uid), //User ID Anda

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($pin), //Pin Anda

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref1), //ref1

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref2), //ref2

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref3), //ref3

                                        ),
                                    ),
                                ),
                            ),
                        );

                        $xml = Array2XML::createXML('methodCall', $tes_xml);

                        //jika  tidak ingin melihat request hilangkan kode dibawah
                        //lihat request xml yg akan dikirim
                        $send = $xml->saveXML();

                        //Alamat URL yang di hit ke rajabiller
                        $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_VERBOSE, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_REFERER, $url);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/text',
                        ));
                        $data = curl_exec($ch);

                        if ($data === false) {
                            printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                            rewind($verbose);
                            $verboseLog = stream_get_contents($verbose);
                            $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                        }

                        $errno = curl_errno($ch);
                        $error = curl_error($ch);

                        if ($errno > 0) {
                            $result = 'null';
                        } else {
                            $result = $data;
                        }

                        //close connection
                        curl_close($ch);

                        //jika tidak ingin melihat response, hilangkan kode dibawah
                        #echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                        //
                        $dom = new DOMDocument;
                        //result
                        $dom->loadXML($result);

                        //pengambilan string dari node <string></string> pada response xml rajabiller
                        $arrays = $dom->getElementsByTagName('string');

                        // membuat array untuk inisiasi masing2 string xml
                        $key = array(
                            'KODEPRODUK',
                            'WAKTU(YYYYMMDDHHIISS)',
                            'IDPELANGGAN1',
                            'IDPELANGGAN2',
                            'IDPELANGGAN3',
                            'NAMAPELANGGAN',
                            'PERIODETAGIHAN',
                            'NOMINAL',
                            'BIAYAADMIN',
                            'UID',
                            'PIN',
                            'REF1',
                            'REF2',
                            'REF3',
                            'STATUS',
                            'KETERANGAN',
                            'SALDOTERPOTONG',
                            'SISASALDO',
                            'URLSTRUK',
                        );
                        //

                        $i = 0;
                        foreach ($arrays as $array) {
                            $a[$key[$i++]] = $array->nodeValue;
                        }

                        if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                            //salah
                            $html .= '<b>Something went wrong!</b><br>';
                            $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';

                        } else {
                            //echopre($a);
                            $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                            $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                            $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                            $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                            $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                            $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                            $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                            $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                            $tgl = date("j F Y, g:i a", $mydate);
                            $userId = $userModel;
                            $member = $userId;
                            $penjumlahan = number_format(Array2XML::sanitize($a['NOMINAL'] + 3000), 2, ',', '.');
                            $html .= "
        								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
        								<tr>
        									<th colspan='2'>Bukti Pembayaran tagihan </th>
</tr>
<tr>
									<th colspan='2'>Nama Loket : $this->wpusername</th>
</tr>
<tr>
        									<th colspan='2'> </th>
        								</tr>
        								<tr>
        									<td id='left-td'>Nama Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>ID Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

        								</tr>
<tr>
        									<td id='left-td'>ID Pelanggan2</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>Periode Bulan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tanggal Tagihan</td>
        									<td id='right-td'>{$tgl}</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Biaya Admin</td>
        									<td id='right-td'>Rp. 3000</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Pembayaran</td>
        									<td id='right-td'>Rp.{$penjumlahan}</td>
        								</tr>
        								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

        								<tr>
        									<td id='left-td'>No Transaksi</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Khusus Token</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
        								</tr>


        								</table>

        								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
        							";
                            //cut deposit from user
                            $marginAdmin = 450; //keuntungan admin
                            $marginProvider = 50; //keuntungan provider
                            $decrementVal = $a['NOMINAL'] + $marginAdmin + $marginProvider;
                            $userModel->decrementRegularBalance($decrementVal);

                            //save transaction in wpdeposit transaction table
                            $userId = $userModel->getId();
                            $itemId = 0;
                            $amount = $decrementVal;
                            $addon = '';
                            $message = 'ID ' . $a['IDPELANGGAN1'] . $a['NAMAPELANGGAN'] . $penjumlahan . $a['KETERANGAN'] . $a['URLSTRUK'];
                            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        } //if status  == 00

                    } //if not empty kode produk

                } //if not bayar tagihan

            } //empty post

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        } //if user not login
        echo $html;
    }

    /**
     * Show api Inquiry PDAM options
     * Payment goes to : rajabiller_api_payment
     */
    public function rajabiller_api_inquirypdamkedua()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                //method rajabiller untuk inquiry tagihan
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan1
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //id pelanggan2
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //id pelanggan3
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref1
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'id pelanggan';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kodeproduk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //idpelanggan1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //idpelanggan2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //idpelanggan3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    // echo "<hr><b>Cek Tagihan  :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />";  //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> error</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 1400 + 0), 2, ',', '.');
                        $biaya = number_format(Array2XML::sanitize(1400), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] + 0 - 400), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(400), 2, ',', '.');
                        $petunjuk = "Bank BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai Nominal Total Bayar";
                        $garansi = "Telegram / whatsapp ke 0856 336 3188";

                        $format = "kab or kota / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $html .= "
								<table  style='width:100%'>
								<tr>
									<th colspan='2'>TAGIHAN DETAIL</th>
</tr>
<tr>
<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>ID pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Periode Bulan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin</td>
									<td id='right-td'>Rp. {$biaya}</td>
								</tr>


								<tr>
									<td id='left-td'>Total tagihan </td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action='https://pilihbayar.com/pembayaran-multi/' method='POST'>
									<input type='hidden' name='head-tagihan' value='1'>
									<input type='hidden' name='tagihan-pdam-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pdam-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pdam-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pdam-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pdam-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pdam-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>

							";

                    }
                }
            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left">Tagihan PDAM </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>






<option value="GAS"> PERTAGAS</option>
<option value="PGN"> PGN</option>
<option value="WAAETRA">PDAM AETRA JKT</option>
<option value="WAPLYJ">PALYJA JKT</option>

<option value="WAKOKEDIRI">Kota Kediri</option>
<option value="WAJMBR">Kab Jember</option>
<option value="WASDA">Kab Sidoarjo</option>
<option value="WAKABMLG">Kab Malang</option>
<option value="WAMLG">Kota Malang</option>
<option value="WABGK">Kab bangkalan madura</option>
<option value="WASAMPANG">Kab Sampang madura</option>
<option value="WABWANGI">Kab Banyuwangi</option>
<option value="WABJN">Kab Bojonegoro</option>
<option value="WABONDO">Kab Bondowoso</option>
<option value="WAKOPROB">Kota Probolinggo</option>
<option value="WALMJNG">Kab Lumajang</option>
<option value="WAMJK">Kab Mojokerto</option>
<option value="WAPASU">Kab Pasuruan</option>
<option value="WASITU">Kab situbondo</option>
<option value="WAKOPASU">Kota Pasuruan</option>
<option value="WAPASU">Kab Pasuruan</option>
<option value="WABJN">Kab Bojonegoro</option>
<option value="WAGARUT">Kab GARUT</option>
<option value="WASBY">Kota Surabaya</option>
<option value="WAMADIUN">KOTA MADIUN</option>
<option value="WAMAGETAN">Kab Magetan</option>
<option value="WANGAWI">Kab Ngawi</option>
<option value="WAPONOR">Kab Ponorogo</option>
<option value="WAKOKEDIRI">Kota Kediri</option>
<option value="WABYMS">Kab Banyumas</option>
<option value="WAMGLG">Kab Magelang</option>
<option value="WACLCP">Kab CILACAP</option>
<option value="WAPBLINGGA">Kab Purbalingga</option>
<option value="WASMG">Kota Semarang</option>
<option value="WAPURWORE">Kab Purworejo</option>
<option value="WAKOSOLO">Kota SURAKARTA/SOLO</option>
<option value="WAWONOGIRI">KAB WONOGIRI</option>

<option value="WASLMN">Kab Sleman DIY</option>
<option value="WAYOGYA">Kota Yogyakarta</option>
<option value="WAWONOSB">Kab Wonosobo</option>
<option value="WABOGOR">Kab Bogor</option>
<option value="WAKOBGR">KOTA BOGOR</option>
<option value="WADEPOK">Kota DEPOK</option>
<option value="WAKABBKS">KAB BEKASI</option>
<option value="WABDGBAR">Kab Bandung Barat</option>
<option value="WAKABBDG">Kab Bandung</option>
<option value="WABDG">Kota Bandung</option>
<option value="WAKUNING">Kab Kuningan</option>


<option value="WAMEDAN">Kota Medan</option>
<option value="WAPLMBNG">Kota Palembang</option>
<option value="WALMPNG">Kota Bandar Lampung</option>
<option value="WABATAM">ATB BATAM</option>
<option value="WATAPIN">Kab Tapin Kalsel</option>

<option value="WABANJAR">Kota BAnjarmasin</option>
<option value="WAPONTI">Kota Pontianak</option>
<option value="WASISAM">Kota Samarinda</option>
<option value="WAPBUN">Pangkalan BUn</option>
<option value="WAPOLEW">Polewali Mandar</option>
<option value="WAMANADO">PT AIR MANADO SULUT</option>
<option value="WADPSR">Kota Denpasar bali</option>
<option value="WAJAMBI">Kota Jambi</option>
<option value="WAGIRIMM">Kota Mataram NTB</option>
<option value="WAMEDAN">Kota Medan</option>
<option value="WAPLMBNG">Kota Palembang</option>
<option value="WAMAKASAR">Kota Makasar</option>
<option value="WAJPURA">Kota Jayapura</option>




</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show api Inquiry leasing dll options
     * Payment goes to : rajabiller_api_payment
     */
    public function rajabiller_api_inquirypdamketiga()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                //method rajabiller untuk inquiry tagihan
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan1
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //id pelanggan2
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //id pelanggan3
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref1
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'id pelanggan';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kodeproduk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //idpelanggan1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //idpelanggan2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //idpelanggan3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    // echo "<hr><b>Cek Tagihan  :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />";  //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> error</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 1400 + 0), 2, ',', '.');
                        $biaya = number_format(Array2XML::sanitize(1400), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] + 0 - 400), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(400), 2, ',', '.');
                        $petunjuk = "Bank BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai Nominal Total Bayar";
                        $garansi = "Telegram / whatsapp ke 0856 336 3188";

                        $format = "kab or kota / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $html .= "
								<table  style='width:100%'>
								<tr>
									<th colspan='2'>TAGIHAN DETAIL</th>
</tr>
<tr>
<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>ID pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Periode Bulan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin</td>
									<td id='right-td'>Rp. {$biaya}</td>
								</tr>


								<tr>
									<td id='left-td'>Total tagihan </td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action='https://pilihbayar.com/pembayaran-multi/' method='POST'>
									<input type='hidden' name='head-tagihan' value='1'>
									<input type='hidden' name='tagihan-pdam-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pdam-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pdam-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pdam-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pdam-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pdam-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>

							";

                    }
                }
            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left"> </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>




<option value="FNBIMA">BIMA FINANCE</option>
<option value="FNFIF">FIF </option>
<option value="FNBAF">BAF</option>
<option value="FNWOM">WOM Finance</option>
<option value="FNHCI">Home Credit Indonesia</option>
<option value="SPEEDY">Speedy/IndiHome</option>
<option value="HPTSEL">HALOTelkomsel</option>
<option value="HPXL">XL Eksplore</option>
<option value="HPMTRIX">Indosat (Matrix) 	</option>
    										<option value="HPESIA">Esia (Postpaid) 	</option>
    										<option value="HPFREN">FRENMOBIHEPI (POSTPAID)</option>
    										<option value="HPSMART">SMARTFREN (POSTPAID)</option>
    										<option value="HPTHREE">THREE (Postpaid)</option>

    										<option value="TVINDVS">IndoVision</option> <option value="TVINDVS">Top TV</option>  <option value="TVINDVS">Oke Vision</option> <option value="TVTLKMV">Transv Vision</option> <option value="TVTLKMV">Telkom vision</option> <option value="TVTLKMV">Yes TV</option> <option value="TVNEX">Nex Media</option> <option value="TVTOPAS">Topas TV</option>
    										<option value="TVORANGE">Orange TV</option> <option value="TVBIG">BIG TV</option> <option value="TVINNOV">Innovate TV</option>
<option value="TVKV50">KVISION (50rb)</option>
<option value="TVKV75">KVISION (75rb)</option>
<option value="TVKV100">KVISION (100rb)</option>




</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show api Inquiry PLN options
     * Payment goes to : rajabiller_api_paymentPLN
     */
    public function rajabiller_api_inquiryPLNkedua()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID  Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID  Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> tagihan sudah dibayar</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 450), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(300), 2, ',', '.');
                        $admin = number_format(Array2XML::sanitize(450), 2, ',', '.');
                        $petunjuk = "Bank ke BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal total bayar";
                        $garansi = "telegram / whatsapp ke 0856 336 3188";
                        $format = " Nama / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $token = " No token / Nominal Token / No Transaksi dan foto bukti transfer";
                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 10px; right: 80px; }
}
</style>


<table  style='width:100%' class='table_pembayaran_tagihan'>

								<tr>
									<th colspan='2'>Tagihan PLN</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Bulan Tagihan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin</td>
									<td id='right-td'>Rp. {$admin}</td>
								</tr>


								<tr>
									<td id='left-td'>Total tagihan PLN</td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action='  https://pilihbayar.com/listrik-pay/  ' method='POST'>
									<input type='hidden' name='head-tagihan' value='2'>
									<input type='hidden' name='tagihan-pln-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pln-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pln-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pln-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pln-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pln-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>



							";

                    }
                }

            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left">Tagihan Listrik </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>
									<option value="PLNPASCB">Tagihan Listrik</option> <option value="PLNPRAB">Token Listrik</option>  								</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show api Inquiry Telkom options
     * Payment goes to : rajabiller_api_payment
     */
    public function rajabiller_api_inqtelkom()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Tagihan sudah dibayar</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 1400), 2, ',', '.');
                        $admin = number_format(Array2XML::sanitize(1400), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(300), 2, ',', '.');
                        $petunjuk = "Bank BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal Total bayar";
                        $garansi = "Telegram / whatsapp ke 0856 336 3188";
                        $format = " Nama / No telepon / total bayar / No Transaksi dan foto bukti transfer";

                        $html .= "
								<table  style='width:100%'>
								<tr>
									<th colspan='2'>Tagihan TELKOM</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Kode area</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Bulan tagihan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin</td>
									<td id='right-td'>Rp. {$admin}</td>
								</tr>


								<tr>
									<td id='left-td'>Total tagihan TELKOM</td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>No Transaksi</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action='https://pilihbayar.com/telkom-pay/' method='POST'>
									<input type='hidden' name='head-tagihan' value='3'>
									<input type='hidden' name='tagihan-telkom-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-telkom-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-telkom-idpelanggan2' value='{$a['IDPELANGGAN2']}'>
									<input type='hidden' name='tagihan-telkom-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-telkom-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-telkom-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-telkom-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>

							";

                    }
                }

            } else {
                $html .= ' <div id="contact-area">
                                <h3 style="text-align: left">Tagihan TELKOM</h3>
                                <br>
                                <form method="post" action="" autocomplete="off">
                                    <select name="kodeproduk" id="kodeproduk" required>
                                        <option value="">Pilih Tagihan</option>
                                        <option value="TELEPON">Telepon</option>




                                    </select>
                                    <input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="kodearea" required />
                                    <input type="text" name="idpelanggan2" id="idpelanggan2" placeholder="Nomortelepon" required />
                                    <input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" required />
                                    <input type="hidden" name="ref1" id="ref1" value="" required />
                                    <input type="submit" name="submit" value="SEND" class="submit-button" />
                                </form>
                                <div style="clear: both;"></div>
                            </div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api pulsa options
     */
    public function rajabiller_api_pulsa()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 52100) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>Bukti Pulsa </th>

</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['STATUS']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 5; //keuntungan admin
                        $marginProvider = 5; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 190);
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHp ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Pulsa dan Paket data II</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih operator</option>

				<option value="AX50H">Axis 50rb</option>


<option value="AXD2H">AXISBRONET 2GB30hr Rp28300 </option>
<option value="AXD3H">AXISBRONET 3GB30hr Rp49300 </option>
<option value="AGUH">AXIS DataGAul unlimited30hr </option>
<option value="AXD3H">AXISBRONET 3GB30hr Rp38300</option>
<option value="AXD5H">AXISBRONET 5GB30hr Rp58200</option>
<option value="B50H">Bolt 50rb</option>


				 <option value="IDEX2H">Isat ExtraData 2GB Rp35650</option>
<option value="ID2H">INDOSATDATA 2G 30hr</option>
<option value="ID3H">INDOSATDATA 3G 30hr </option>
<option value="ID4H">INDOSATDATA 4G 30hr </option>
<option value="ID11H">INDOSATDATA 11G 30hr </option>

				<option value="I30H">Indosat 30rb</option>
				<option value="I50H">Indosat 50rb</option>

		        <option value="TI50H">Indosat transfer  50rb</option>
<option value="I30P">Indosat promo 30RB  </option>
<option value="I50P">Indosat promo 50RB  </option>
		        <option value="CM50H">Smart 50rb</option>


		         <option value="S50H">Telkomsel 50rb</option>
		         <option value="TS50H">Telkomsel transfer  50rb</option>

<option value="S30P">Telkomsel promo 30RB </option>
<option value="S40P">Telkomsel promo 40RB </option>
<option value="S50P">Telkomsel promo 50RB </option>
<option value="SDX15H">Promo telkomsel data Rp49500</option>


<option value="SPT25H">paket telp telkomsel7hr </option>

		         <option value="T50H">Three 50rb</option>


<option value="TD2H">THREE 2GB Rp35200 </option>
<option value="TD3H">THREE 3GB Rp45200 </option>

<option value="TRD125H">Three Kuota++ 1.25GB Rp31350</option>
<option value="WB10H">WIFIBIZNET 10rb500MB </option>
<option value="WB30H">WIFIBIZNET 30rb2GB </option>
			             <option value="XT30H">XL transfer 30rb</option>
			              <option value="XT40H">XL transfer 40rb</option>
			               <option value="XT50H">XL transfer 50rb</option>
			               <option value="XR50H">XL 50rb</option>
			               <option value="XN500H">XLnelp300menit</option>
<option value="XR30P">XL promo 30Rb </option>
<option value="XR50P">XL promo 50Rb </option>
<option value="XDH15H">XLDATA 1,5Gg 30hr </option>


<option value="XDC8H">XLDATA 1G 30hr 36300 </option>
<option value="XDC12H">XLDATA 2g 30hr </option>





				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api zakat options
     * Status : devel
     */
    public function rajabiller_api_zakat()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();
                    $shortcodes->show_payment_interface();
                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 102000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);

                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<table  style='width:100%'>
								<tr>
									<th colspan='2'>BUKTI PULSA</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>NoHP</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 100; //keuntungan admin
                        $marginProvider = 299; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 1000);
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Pulsa dan Paket Data III</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required> <option value="">PILIHAN </option>  <option value="AX100H">Axis 100rb</option>
<option value="AXD5H">AXISBRONET 5GB30hr Rp56300 </option>
<option value="B100H">Bolt 100rb</option>

<option value="IDEX4H">Isat ExtraData 4GB Rp56050</option>
<option value="IDEX6H">Isat ExtraData 6GB Rp70450</option>

<option value="ID7H">INDOSATDATA 7Gg  Rp66700 </option>
<option value="ID9H">INDOSATDATA 9 Gg </option>
<option value="ID13H">INDOSATDATA 13Gg 30hr  </option>
<option value="ID15H">INDOSATDATA 15Gg 30hr  </option>
<option value="I100H">Indosat reg 100</option>
<option value="TI100H">Indosat transfer  100rb</option>
<option value="I100P">Indosat promo 100RB  </option>


<option value="CM100H">Smart 100rb</option>


<option value="S70P">Telkomsel 70rb</option>
<option value="S80P">Telkomsel 80rb</option>
<option value="S900P">Telkomsel 90rb</option>
<option value="S100H">Telkomsel 100rb</option>
<option value="S100P">Telkomsel promo 100rb</option>
<option value="TS100H">Telkomsel transfer  100rb</option>

<option value="SDB5H">TELKOMSEL DATA 4,5G </option>
<option value="SDB10H">TELKOMSEL DATA 8G </option>
<option value="SDB14H">TELKOMSEL DATA 12G </option>

<option value="SD100H">Tseldata 2,5G Rp98500</option>
<option value="SPT50H">Paket Telpon Tsel 100mnit 30hr</option>
<option value="SPT100H">Paket Telpon Tsel 250mnit 30hr</option>

<option value="T100H">Three 100rb</option>

<option value="TD5H">THREE 5GB+10G 4G Rp66200 </option>
<option value="TD6H">THREE 6GB+12GB 4G Rp76200 </option>
<option value="TRD425H">Three Kuota++ 4.25GB Rp79400</option>
<option value="XT75H">XL transfer 75rb</option>
<option value="XT100H">XL transfer 100rb</option>
<option value="XR100H">XL 100rb</option>
<option value="XR100P">XL promo 100rb</option>
<option value="XDC19H">XLDATA 10Gg 30hr</option>
<option value="XD120H">XLDATA 6Gg 30hr </option>





				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api bukti transaksi options
     */
    public function rajabiller_api_transaksi()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 0) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();
                    $shortcodes->show_payment_interface();
                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.cu';

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                // ref1
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //ref2
                $ref2 = Array2XML::sanitize($_POST['ref2']);

                if (empty($ref2)) {
                    $html .= 'tidak boleh kosong';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //uid

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref2), //ref2

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['keterangan']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $penjumlahan = number_format(Array2XML::sanitize($a['NOMINAL'] + 3000), 2, ',', '.');
                        $biaya = number_format(Array2XML::sanitize(3000), 2, ',', '.');
                        $ket = "SUDAH LUNAS";
                        $bukti = "Menyatakan sebagai bukti pembayaran yang sah";
                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 5px; right:80px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>BUKTI PEMBAYARAN</th>
</tr>
<tr>
									<th colspan='2'>Nama Loket : $this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>No Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Bulan Bayar</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>

								<tr>
									<td id='left-td'>Tagihan</td>
									<td id='right-td'>Rp.{$rupiah}</td>
								</tr>
								<tr>
									<td id='left-td'>Admin</td>
									<td id='right-td'>Rp. {$biaya}</td>
								</tr>
								<tr>
									<td id='left-td'>Total Pembayaran</td>
									<td id='right-td'>Rp. {$penjumlahan} </td>
								</tr>
								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>{$ket} </td>
								</tr>

								<tr>
									<td id='left-td'></td>
									<td id='right-td'>{$bukti} </td>
								</tr>
								<tr>
									<td id='left-td'>No Token</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back(-2);'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
							";

                    }
                }
            } else {
                $html .= '<div id="contact-area">
								<h2 style="text-align: right">DATA TRANSAKSI</h2><br>
								<form method="post" action="">
									<input type="hidden" name="ref1" id="ref1" value="0" required />
									<input type="text" name="ref2" id="ref2" placeholder="nomor transaksi" required />
									<input type="submit" name="submit" value="SEND" class="submit-button" />
								</form>
								<div style="clear: both;"></div>
							</div>';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api bukti transaksi options
     */
    public function rajabiller_api_transaksidata()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.game';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 101900) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>Bukti pembayaran</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['STATUS']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 900; //keuntungan admin
                        $marginProvider = 50000; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 0); //saldo provider
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Emoney shopeepay 50K</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih </option>





<option value="SHOP50H">ShopeePay 50K</option>
<option value="OVO50H">OVO 50K</option>
<option value="GJK50H">SaldoGOjek 50K</option>
<option value="DANA50H">DANA 50K</option>
<option value="LINK50H">LINKAJA 50K</option>
<option value="GJD50H">GOPAY DRIVER(GOPAY) 50K</option>





				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show paymentpelen api PLN
     */
    public function rajabiller_api_paymentpelen()
    {
        $html = '';
        if (is_user_logged_in()) {
            $_helpersClass = new Helpers();
            $_helpersClass::cdebug('debug', $_POST);

            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                if (isset($_POST['head-tagihan'])) {
                    //populate all the tagihan PDAM value
                    if ($_POST['head-tagihan'] == 1) {
                        $nominal = isset($_POST['tagihan-pdam-nominal']) ? $_POST['tagihan-pdam-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pdam-idpelanggan1']) ? $_POST['tagihan-pdam-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pdam-ref1']) ? $_POST['tagihan-pdam-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pdam-ref2']) ? $_POST['tagihan-pdam-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pdam-ref3']) ? $_POST['tagihan-pdam-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pdam-kodeproduk']) ? $_POST['tagihan-pdam-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pdam']);

                    }

                    //populate all the tagihan PLN value
                    if ($_POST['head-tagihan'] == 2) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pln']);

                    }

                    //populate all the tagihan Telkom value
                    if ($_POST['head-tagihan'] == 3) {
                        $nominal = isset($_POST['tagihan-telkom-nominal']) ? $_POST['tagihan-telkom-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-telkom-idpelanggan1']) ? $_POST['tagihan-telkom-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-telkom-ref1']) ? $_POST['tagihan-telkom-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-telkom-ref2']) ? $_POST['tagihan-telkom-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-telkom-ref3']) ? $_POST['tagihan-telkom-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-telkom-kodeproduk']) ? $_POST['tagihan-telkom-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan Pascabayar value
                    if ($_POST['head-tagihan'] == 4) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan TV value
                    if ($_POST['head-tagihan'] == 5) {
                        $nominal = isset($_POST['tagihan-tv-nominal']) ? $_POST['tagihan-tv-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-tv-idpelanggan1']) ? $_POST['tagihan-tv-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-tv-ref1']) ? $_POST['tagihan-tv-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-tv-ref2']) ? $_POST['tagihan-tv-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-tv-ref3']) ? $_POST['tagihan-tv-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-tv-kodeproduk']) ? $_POST['tagihan-tv-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }
                    $rawHtml = '<div id="contact-area">
    								<h2 style="text-align: right">Pembayaran Tagihan</h2><br>
    								<form method="post" action="" autocomplete="off">
    									<label for="kodeproduk">Kode Produk</label>
    									<select name="kodeproduk" id="kodeproduk" required>
    										<option value="">Pilih </option>



    										<option value="PLNPRAH">TOKEN</option>
    										<option value="PLNPASCH">Tagihan Listrik</option>
    										<option value="PLNNONH">Tambah Daya</option>
<option value="PLNNONH">Pasang Baru</option>
<option value="PLNNONH">Cicilan pasang Listrik</option>

    									</select>
    									<br/>

    									<label for="idpelanggan1">ID Pelanggan 1</label>
    										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan"  value="' . $idpelanggan1 . '" required />
    									<br/>
    									<label for="idpelanggan2">ID Pelanggan 2</label>
    										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value=""  />
    									<br/>
    									<label for="idpelanggan3">ID Pelanggan 3</label>
    										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
    									<br/>
    									<label for="nominal">Nominal</label>
    										<input type="text" name="nominal" id="nominal" placeholder="Nominal" value="' . $nominal . '" required />
    									<br/>

    									<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"   />
    									<label for="ref2">No Referensi</label>
    										<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '" required   />
    									<br/>
    									<input type="hidden" name="ref3" id="ref3" value="' . $ref3 . '"  />
    									<input type="submit" name="submit" value="Bayar" class="btn btn-success" />
                                        <button type="button" id="bpjs-back" onclick="window.history.back();" class="btn btn-default">BACK</button>
    								</form>
    								<div style="clear: both;"></div>

    							</div>';

                    $html .= str_replace('value="' . $selectedKode . '"', 'value="' . $selectedKode . '" selected', $rawHtml);
                } else {
                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < 12000) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    #print_r($_POST);
                    //method rajabiller untuk
                    $method = 'rajabiller.pay';

                    //kode produk
                    $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                    //id pelanggan
                    $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                    //id pelanggan
                    $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                    //id pelanggan
                    $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                    //nominal
                    $nominal = Array2XML::sanitize($_POST['nominal']);

                    //User ID SP Anda
                    $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                    //PIN ID SP Anda
                    $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                    //ref
                    $ref1 = Array2XML::sanitize($_POST['ref1']);

                    //ref
                    $ref2 = Array2XML::sanitize($_POST['ref2']);

                    //ref
                    $ref3 = Array2XML::sanitize($_POST['ref3']);

                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < $nominal + 1990) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    if (empty($kodeproduk)) {
                        $html .= 'harus diisi';
                    } else {

                        //generate ke XML
                        $tes_xml = array(
                            'methodName' => array(
                                '@value' => $method,
                                //nama method

                            ),
                            'params' => array(
                                'param' => array(

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($kodeproduk), //kode produk

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan1),
                                            //id pelanggan 1

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan2),
                                            //id pelanggan 2

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan3),
                                            //id pelanggan 3

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($nominal), // nominal

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($uid), //User ID Anda

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($pin), //Pin Anda

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref1), //ref1

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref2), //ref2

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref3), //ref3

                                        ),
                                    ),
                                ),
                            ),
                        );

                        $xml = Array2XML::createXML('methodCall', $tes_xml);

                        //jika  tidak ingin melihat request hilangkan kode dibawah
                        //lihat request xml yg akan dikirim
                        $send = $xml->saveXML();

                        //Alamat URL yang di hit ke rajabiller
                        $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_VERBOSE, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_REFERER, $url);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/text',
                        ));
                        $data = curl_exec($ch);

                        if ($data === false) {
                            printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                            rewind($verbose);
                            $verboseLog = stream_get_contents($verbose);
                            $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                        }

                        $errno = curl_errno($ch);
                        $error = curl_error($ch);

                        if ($errno > 0) {
                            $result = 'null';
                        } else {
                            $result = $data;
                        }

                        //close connection
                        curl_close($ch);

                        //jika tidak ingin melihat response, hilangkan kode dibawah
                        #echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                        //
                        $dom = new DOMDocument;
                        //result
                        $dom->loadXML($result);

                        //pengambilan string dari node <string></string> pada response xml rajabiller
                        $arrays = $dom->getElementsByTagName('string');

                        // membuat array untuk inisiasi masing2 string xml
                        $key = array(
                            'KODEPRODUK',
                            'WAKTU(YYYYMMDDHHIISS)',
                            'IDPELANGGAN1',
                            'IDPELANGGAN2',
                            'IDPELANGGAN3',
                            'NAMAPELANGGAN',
                            'PERIODETAGIHAN',
                            'NOMINAL',
                            'BIAYAADMIN',
                            'UID',
                            'PIN',
                            'REF1',
                            'REF2',
                            'REF3',
                            'STATUS',
                            'KETERANGAN',
                            'SALDOTERPOTONG',
                            'SISASALDO',
                            'URLSTRUK',
                        );
                        //

                        $i = 0;
                        foreach ($arrays as $array) {
                            $a[$key[$i++]] = $array->nodeValue;
                        }

                        if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                            //salah
                            $html .= '<b>Something went wrong!</b><br>';
                            $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';

                        } else {
                            //echopre($a);
                            $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                            $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                            $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                            $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                            $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                            $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                            $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                            $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                            $tgl = date("j F Y, g:i a", $mydate);
                            $admin = number_format(Array2XML::sanitize($a['BIAYAADMIN'] - 2000), 2, ',', '.');
                            $rupiahtagihan = number_format(Array2XML::sanitize(1000), 2, ',', '.');
                            $penjumlahan = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 2000), 2, ',', '.');
                            $html .= "
        								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 5px;right:80px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
        								<tr>
        									<th colspan='2'>Bukti Pembayaran tagihan</th>
</tr>
<tr>
									<th colspan='2'>Nama Loket : $this->wpusername</th>
</tr>
<tr>
        									<th colspan='2'> </th>
        								</tr>
        								<tr>
        									<td id='left-td'>Nama Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>ID Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

        								</tr>
<tr>
        									<td id='left-td'>ID Pelanggan2</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>Periode Bulan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tanggal Tagihan</td>
        									<td id='right-td'>{$tgl}</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tagihan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NOMINAL']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Biaya Admin</td>
        									<td id='right-td'>Rp.{$admin}</td>
        								</tr>

        								<tr>
        									<td id='left-td'>Pembayaran</td>
        									<td id='right-td'>Rp.{$penjumlahan}</td>
        								</tr>
        								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

        								<tr>
        									<td id='left-td'>No Transaksi</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Khusus Token</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
        								</tr>


        								</table>

        								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
        							";
                            //cut deposit from user
                            $marginAdmin = 1800; //keuntungan admin
                            $marginProvider = 190; //keuntungan provider
                            $decrementVal = $nominal + $marginAdmin + $marginProvider;
                            $userModel->decrementRegularBalance($decrementVal);

                            //save transaction in wpdeposit transaction table
                            $userId = $userModel->getId();
                            $itemId = 0;
                            $amount = $decrementVal;
                            $addon = '';
                            $message = 'ID' . $a['IDPELANGGAN1'] . $a['NAMAPELANGGAN'] . $a['KETERANGAN'] . $a['URLSTRUK'];
                            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        } //if status  == 00

                    } //if not empty kode produk

                } //if not bayar tagihan

            } //empty post

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        } //if user not login
        echo $html;
    }
    /**
     * Show api Inquiry Telkomselbebas options
     * Payment goes to : rajabiller_api_paymentbebasadmin
     */
    public function rajabiller_api_inqtelkomselbebas()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 26100) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);

                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>BUKTI PULSA</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>NoHP</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 5; //keuntungan admin
                        $marginProvider = 4; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 41);
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'noHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Pulsa dan Paket Data I</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required> <option value="">PILIHAN </option>

<option value="AX15H">Axis 15rb</option>
<option value="AX25H">Axis 25rb</option>
<option value="AXD1H">AXISBRONET 1GB30hr Rp21850</option>
<option value="AXD2H">AXISBRONET 2GB30hr Rp28500</option>

<option value="B25H">Bolt 25rb</option>

<option value="I20H">Indosat 20rb</option>
<option value="I25H">Indosat 25rb</option>

<option value="IS25H">Indosat sms 50</option>


<option value="TI20H">Indosat transfer  20</option>
<option value="TI25H">Indosat transfer  25</option>


<option value="I20P">Indosat promo 20RB  </option>
<option value="I25P">Indosat PROMO 25RB </option>
<option value="ID1H">ISAT data 1G+Apps 30hr </option>


<option value="CM20H">Smart 20000</option>
<option value="CM25H">Smart 25000</option>


<option value="S15H">Telkomsel 15rb</option>
<option value="S20H">Telkomsel 20rb</option>
<option value="S25H">Telkomsel 25rb</option>


<option value="TS20H">Telkomsel transfer  20</option>
<option value="TS25H">Telkomsel transfer  25</option>


<option value="S20P">Telkomsel promo 20RB </option>
<option value="S25P">Telkomsel promo 25RB </option>

<option value="SPT5H">Paket Telpontsel 15Mnt Alloprtr 1hari</option>
<option value="SPT10H">Paket Telpontsel 30Mnt+170mnt Alloprtr 3hari</option>
<option value="SPT20H">Paket Telpontsel 40MntAlloprtr 7hari</option>


<option value="T20H">Three 20rb</option>
<option value="T25H">Three 25rb</option>
<option value="TD1H">THREE 1GB+1GB 4G Rp21200</option>
<option value="TRD300H">Three Kuota++ 300MB Rp10800</option>
<option value="TRD650H">Three Kuota++ 650MB Rp20200</option>

<option value="XT15H">XL transfer 15rb</option>
<option value="XT20H">XL transfer 20rb</option>
<option value="XT25H">XL transfer 25rb</option>

<option value="XR15H">XL 15rb</option>
<option value="XR25H">XL  25rb</option>

<option value="XR15P">XL promo 15RB </option>
	<option value="XR25P">XL promo 25RB </option>


				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api Inquiry Telkomselbebas options
     * Payment goes to : rajabiller_api_paymentbebasadmin
     */
    public function rajabiller_api_pulsa5ribu()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 6050) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 6100) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);

                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>BUKTI PULSA</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>NoHP</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 5; //keuntungan admin
                        $marginProvider = 4; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 41);
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'noHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Pulsa dan Paket Data I</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required> <option value="">PILIHAN </option>  <option value="AX5H">Axis 5rb</option>
<option value="I5H">Indosat 5rb</option>
<option value="IS5H">Indosat sms 5rb</option>
<option value="TI5H">Indosat transfer  5rb</option>
<option value="I5P">Indosat PROMO 5Rb </option>
<option value="CM5H">Smart 5rb</option>
<option value="S5H">Telkomsel 5rb</option>
<option value="TS5H">Telkomsel transfer 5rb</option>
<option value="S5P">Telkomsel promo 5Rb  </option>
<option value="T1H">Three 1rb</option>
<option value="T5H">Three 5rb</option>
<option value="TRD20H">Three Kuota++ 20MB Rp3rb </option>
<option value="TRD80H">Three Kuota++ 80MB Rp6rb</option>
<option value="XT5H">XL transfer 5rb</option>
<option value="XR5H">XL 5rb</option>
<option value="XR5P">XL Promo 5Rb </option>

				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api Inquiry Telkomselbebas options
     * Payment goes to : rajabiller_api_paymentbebasadmin
     */
    public function rajabiller_api_pulsa10ribu()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 11100) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 11300) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);

                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>BUKTI PULSA</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>NoHP</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 5; //keuntungan admin
                        $marginProvider = 4; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 41);
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'noHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Pulsa dan Paket Data I</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required> <option value="">PILIHAN </option>  <option value="AX10H">Axis 10rb</option>
<option value="I10H">Indosat 10rb</option>
<option value="IS10H">Indosat sms 10rb</option>
<option value="TI10H">Indosat transfer  10rb</option>

<option value="I10P">Indosat promo 10RB  </option>
<option value="CM10H">Smart 10rb</option>
<option value="S10H">Telkomsel 10rb</option>
<option value="TS10H">Telkomsel transfer  10rb</option>
<option value="S10P">Telkomsel promo 10Rb  </option>
<option value="T10H">Three 10rb</option>
<option value="TRD20H">Three Kuota++ 20MB 3rb </option>
<option value="TRD80H">Three Kuota++ 80MB 6rb</option>
<option value="TRD300H">Three Kuota++ 300MB 10800</option>

<option value="XT10H">XL transfer 10rb</option>
<option value="XR10H">XL 10rb</option>

<option value="XR10P">XL promo 10Rb </option>

				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api pulsa options
     */
    public function rajabiller_api_halotelkomsel()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.game';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 201900) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>Bukti pembayaran</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['STATUS']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 200000; //keuntungan admin
                        $marginProvider = 920; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 0); //saldo provider
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">E Money</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih </option>


<option value="OVO200H">GRAB OVO 200K</option>
<option value="GJD200H">Driver Gojek/gopay 200K</option>
<option value="GJK200H">Gojek/gopay 200K</option>
<option value="SHOP200H">ShopeePay 200K</option>
<option value="DANA200H">DANA 200K</option>
<option value="LINK200H">LINKAJA 200K</option>







				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api pulsa options
     */
    public function rajabiller_api_paketdata()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';
                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.pulsa';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 101100) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }
                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);

                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>BUKTI PULSA</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>NoHP</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>

								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 150; //keuntungan admin
                        $marginProvider = 59; //keuntungan provider
                        $nominal = $a['SALDOTERPOTONG'];
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">Paket data</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih </option>

		        <option value="AXD1H">AXISbronet 3Gb Rp22K</option>
		        <option value="AXD2H">AXISbronet 2Gb Rp29K</option>
		        <option value="AXD3H">AXISbronet 3Gb Rp39K</option>
		        <option value="AXD5H">AXISbronet 5Gb Rp54K</option>

<option value="AGUH">AXIS Unlimited Rp36K</option>
<option value="IDFN4H">INDOSAT Freedom 3Gb Rp27K</option>
<option value="IDFN8H">INDOSAT Freedom 6Gb Rp36K</option>
<option value="IDFN14H">INDOSAT Freedom 11Gb Rp50K</option>

<option value="IDFN20H">INDOSAT Freedom 16Gb Rp69K</option>
<option value="IDFN30H">INDOSAT Freedom 24Gb Rp98K</option>


<option value="SDB3H">Tseldata 1Gb Rp.47kK</option>
<option value="SD50H">Telkomsel1,5G 50k</option>
<option value="SDX3H">Tseldata 3Gb Rp.61K</option>
<option value="SDB5H">Tseldata 4Gb+60mnit Rp.70K</option>
<option value="SMD75H">Tseldata+sosmed unlimited Rp.76K</option>
<option value="SDB10H">Tseldata 10Gb+100mnit Rp.95K</option>
<option value="SDB12H">Tseldata 12Gb Rp.97K</option>

<option value="TD1H">Three data 2Gb Rp.21K</option>

<option value="TD2H">Three data 5Gb Rp.34K</option>
<option value="TD3H">Three data 9Gb Rp.49K</option>
<option value="TD4GH">Three data 8Gb Rp.54K</option>
<option value="TD3H">Three data 9Gb Rp.31K</option>
<option value="TD6H">Three data 18Gb Rp.39K</option>
<option value="XD60H">XL Data 3Gb Rp.57K</option>
<option value="XDC12H">XL Data 5Gb Rp.55K</option>
<option value="XDC19H">XL Data 10Gb Rp.82K</option>

<option value="XDH3H">XL Data 3Gb Rp.57K</option>
<option value="XDH6H">XL Data 6Gb Rp.92K</option>






				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api Inquiry PLN options
     * Payment goes to : rajabiller_api_paymentPLN
     */
    public function rajabiller_api_inquiryplnketiga()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID  Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID  Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> tagihan sudah dibayar</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 1000), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(1000), 2, ',', '.');
                        $admin = number_format(Array2XML::sanitize(1000), 2, ',', '.');
                        $petunjuk = "Bank ke BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal total bayar";
                        $garansi = "telegram / whatsapp ke 0856 336 3188";
                        $format = " Nama / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $token = " No token / Nominal Token / No Transaksi dan foto bukti transfer";
                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 10px; right: 80px; }
}
</style>


<table  style='width:100%' class='table_pembayaran_tagihan'>

								<tr>
									<th colspan='2'>Tagihan PLN</th>
</tr>
<tr>
									<th colspan='2'>Loket :$this->wpusername </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Bulan Tagihan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin Listrik</td>
									<td id='right-td'>Rp. {$admin}</td>
								</tr>

<tr>

								<tr>
									<td id='left-td'>Total tagihan PLN</td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action=' https://pilihbayar.com/pembayaran-cicilan-listrik/ ' method='POST'>
									<input type='hidden' name='head-tagihan' value='2'>
									<input type='hidden' name='tagihan-pln-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pln-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pln-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pln-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pln-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pln-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>



							";

                    }
                }

            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left">Tagihan Listrik </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>
									 <option value="PLNNONH">Tambah Daya</option>
<option value="PLNNONH">Pasang Baru</option>
<option value="PLNNONH">Cicilan pasang/daya Listrik</option>
									</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show paymentpelen api PLN
     */
    public function rajabiller_api_paymentbebasadmin()
    {
        $html = '';
        if (is_user_logged_in()) {
            $_helpersClass = new Helpers();
            $_helpersClass::cdebug('debug', $_POST);

            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                if (isset($_POST['head-tagihan'])) {
                    //populate all the tagihan PDAM value
                    if ($_POST['head-tagihan'] == 1) {
                        $nominal = isset($_POST['tagihan-pdam-nominal']) ? $_POST['tagihan-pdam-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pdam-idpelanggan1']) ? $_POST['tagihan-pdam-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pdam-ref1']) ? $_POST['tagihan-pdam-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pdam-ref2']) ? $_POST['tagihan-pdam-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pdam-ref3']) ? $_POST['tagihan-pdam-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pdam-kodeproduk']) ? $_POST['tagihan-pdam-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pdam']);

                    }

                    //populate all the tagihan PLN value
                    if ($_POST['head-tagihan'] == 2) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pln']);

                    }

                    //populate all the tagihan Telkom value
                    if ($_POST['head-tagihan'] == 3) {
                        $nominal = isset($_POST['tagihan-telkom-nominal']) ? $_POST['tagihan-telkom-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-telkom-idpelanggan1']) ? $_POST['tagihan-telkom-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-telkom-ref1']) ? $_POST['tagihan-telkom-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-telkom-ref2']) ? $_POST['tagihan-telkom-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-telkom-ref3']) ? $_POST['tagihan-telkom-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-telkom-kodeproduk']) ? $_POST['tagihan-telkom-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan Pascabayar value
                    if ($_POST['head-tagihan'] == 4) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan TV value
                    if ($_POST['head-tagihan'] == 5) {
                        $nominal = isset($_POST['tagihan-tv-nominal']) ? $_POST['tagihan-tv-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-tv-idpelanggan1']) ? $_POST['tagihan-tv-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-tv-ref1']) ? $_POST['tagihan-tv-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-tv-ref2']) ? $_POST['tagihan-tv-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-tv-ref3']) ? $_POST['tagihan-tv-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-tv-kodeproduk']) ? $_POST['tagihan-tv-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }
                    $rawHtml = '<div id="contact-area">
    								<h2 style="text-align: right">Pembayaran Tagihan</h2><br>
    								<form method="post" action="" autocomplete="off">
    									<label for="kodeproduk">Kode Produk</label>
    									<select name="kodeproduk" id="kodeproduk" required>
    										<option value="">Pilih </option>


<option value="PLNPRAB">Token listrik</option>
    										<option value="PLNPASCB">Tagihan LISTRIK</option>
    										<option value="PLNPRAH">TOKEN</option>
    										<option value="PLNPASCH">Tagihan Listrik</option>
    										<option value="PLNNONH">Tambah Daya</option>
<option value="PLNNONH">Pasang Baru</option>
<option value="PLNNONH">Cicilan pasang Listrik</option>

    									</select>
    									<br/>

    									<label for="idpelanggan1">No pelanggan</label>
    										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan"  value="' . $idpelanggan1 . '" required />
    									<br/>
    									<label for="idpelanggan2"></label>
    										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value=""  />
    									<br/>
    									<label for="idpelanggan3"></label>
    										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
    									<br/>
    									<label for="nominal">Jumlah Tagihan/Token (hapus angka 0 masukkan nilai token)</label>
    										<input type="text" name="nominal" id="nominal" placeholder="Nominal" value="' . $nominal . '" required />
    									<br/>

    									<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"   />
    									<label for="ref2">No Referensi</label>
    										<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '" required   />
    									<br/>
    									<input type="hidden" name="ref3" id="ref3" value="' . $ref3 . '"  />
    									<input type="submit" name="submit" value="Bayar" class="btn btn-success" />

    								</form>
    								<div style="clear: both;"></div>

    							</div>';

                    $html .= str_replace('value="' . $selectedKode . '"', 'value="' . $selectedKode . '" selected', $rawHtml);
                } else {
                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < 12000) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    #print_r($_POST);
                    //method rajabiller untuk
                    $method = 'rajabiller.pay';

                    //kode produk
                    $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                    //id pelanggan
                    $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                    //id pelanggan
                    $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                    //id pelanggan
                    $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                    //nominal
                    $nominal = Array2XML::sanitize($_POST['nominal']);

                    //User ID SP Anda
                    $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                    //PIN ID SP Anda
                    $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                    //ref
                    $ref1 = Array2XML::sanitize($_POST['ref1']);

                    //ref
                    $ref2 = Array2XML::sanitize($_POST['ref2']);

                    //ref
                    $ref3 = Array2XML::sanitize($_POST['ref3']);

                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < $nominal + 500) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    if (empty($kodeproduk)) {
                        $html .= 'harus diisi';
                    } else {

                        //generate ke XML
                        $tes_xml = array(
                            'methodName' => array(
                                '@value' => $method,
                                //nama method

                            ),
                            'params' => array(
                                'param' => array(

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($kodeproduk), //kode produk

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan1),
                                            //id pelanggan 1

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan2),
                                            //id pelanggan 2

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan3),
                                            //id pelanggan 3

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($nominal), // nominal

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($uid), //User ID Anda

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($pin), //Pin Anda

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref1), //ref1

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref2), //ref2

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref3), //ref3

                                        ),
                                    ),
                                ),
                            ),
                        );

                        $xml = Array2XML::createXML('methodCall', $tes_xml);

                        //jika  tidak ingin melihat request hilangkan kode dibawah
                        //lihat request xml yg akan dikirim
                        $send = $xml->saveXML();

                        //Alamat URL yang di hit ke rajabiller
                        $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_VERBOSE, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_REFERER, $url);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/text',
                        ));
                        $data = curl_exec($ch);

                        if ($data === false) {
                            printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                            rewind($verbose);
                            $verboseLog = stream_get_contents($verbose);
                            $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                        }

                        $errno = curl_errno($ch);
                        $error = curl_error($ch);

                        if ($errno > 0) {
                            $result = 'null';
                        } else {
                            $result = $data;
                        }

                        //close connection
                        curl_close($ch);

                        //jika tidak ingin melihat response, hilangkan kode dibawah
                        #echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                        //
                        $dom = new DOMDocument;
                        //result
                        $dom->loadXML($result);

                        //pengambilan string dari node <string></string> pada response xml rajabiller
                        $arrays = $dom->getElementsByTagName('string');

                        // membuat array untuk inisiasi masing2 string xml
                        $key = array(
                            'KODEPRODUK',
                            'WAKTU(YYYYMMDDHHIISS)',
                            'IDPELANGGAN1',
                            'IDPELANGGAN2',
                            'IDPELANGGAN3',
                            'NAMAPELANGGAN',
                            'PERIODETAGIHAN',
                            'NOMINAL',
                            'BIAYAADMIN',
                            'UID',
                            'PIN',
                            'REF1',
                            'REF2',
                            'REF3',
                            'STATUS',
                            'KETERANGAN',
                            'SALDOTERPOTONG',
                            'SISASALDO',
                            'URLSTRUK',
                        );
                        //

                        $i = 0;
                        foreach ($arrays as $array) {
                            $a[$key[$i++]] = $array->nodeValue;
                        }

                        if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                            //salah
                            $html .= '<b>Something went wrong!</b><br>';
                            $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';

                        } else {
                            //echopre($a);
                            $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                            $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                            $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                            $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                            $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                            $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                            $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                            $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                            $tgl = date("j F Y, g:i a", $mydate);
                            $admin = number_format(Array2XML::sanitize($a['BIAYAADMIN']), 2, ',', '.');
                            $potongan = number_format(Array2XML::sanitize($a['NOMINAL'] + 450), 2, ',', '.');
                            $penjumlahan = $a['NOMINAL'] + $a['BIAYAADMIN'];
                            $html .= "
        								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 5px;right:80px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
        								<tr>
        									<th colspan='2'>Bukti Pembayaran tagihan</th>
</tr>
<tr>
									<th colspan='2'>Loket : $this->wpusername</th>
</tr>
<tr>
        									<th colspan='2'> </th>
        								</tr>
        								<tr>
        									<td id='left-td'>Nama Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>ID Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

        								</tr>
<tr>
        									<td id='left-td'>ID Pelanggan2</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>Periode Bulan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tanggal Tagihan</td>
        									<td id='right-td'>{$tgl}</td>
        								</tr>
        								<tr>
        									<td id='left-td'> Tagihan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NOMINAL']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Biaya Admin</td>
        									<td id='right-td'>{$admin}</td>
        								</tr>

        								<tr>
        									<td id='left-td'>Pembayaran</td>
        									<td id='right-td'>Rp.{$penjumlahan}</td>
        								</tr>
        								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>


        								<tr>
        									<td id='left-td'>Nomor Token</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
        								</tr>


        								</table>

        								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
        							";
                            //cut deposit from user
                            $marginAdmin = 0; //keuntungan admin
                            $marginProvider = 450; //keuntungan provider
                            $decrementVal = $nominal + $marginAdmin + $marginProvider;
                            $userModel->decrementRegularBalance($decrementVal);

                            //save transaction in wpdeposit transaction table
                            $userId = $userModel->getId();
                            $itemId = 0;
                            $amount = $decrementVal;
                            $addon = '';
                            $message = 'ID' . $a['IDPELANGGAN1'] . $a['NAMAPELANGGAN'] . $penjumlahan . $a['KETERANGAN'] . $a['REF3'] . $a['URLSTRUK'];
                            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        } //if status  == 00

                    } //if not empty kode produk

                } //if not bayar tagihan

            } //empty post

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        } //if user not login
        echo $html;
    }

    public function rajabiller_api_inquiry_pln_old()
    {
        $html = '';

        if (is_user_logged_in()) {

            $html .= '
								<style>
								/* Style inputs, select elements and textareas */
                                input[type=text], select, textarea{
                                  width: 100%;
                                  padding: 12px;
                                  border: 1px solid #ccc;
                                  border-radius: 4px;
                                  box-sizing: border-box;
                                  resize: vertical;
                                }

                                /* Style the label to display next to the inputs */
                                label {
                                  padding: 12px 12px 12px 0;
                                  display: inline-block;
                                }

                                /* Style the submit button */
                                input[type=submit] {
                                  background-color: #4CAF50;
                                  color: white;
                                  padding: 12px 20px;
                                  border: none;
                                  border-radius: 4px;
                                  cursor: pointer;
                                  float: right;
                                }

                                /* Style the container */
                                .container-x {
                                  border-radius: 5px;
                                  background-color: #f2f2f2;
                                  padding: 20px;
                                }

                                /* Floating column for labels: 25% width */
                                .col-25 {
                                  float: left;
                                  width: 25%;
                                  margin-top: 6px;
                                }

                                /* Floating column for inputs: 75% width */
                                .col-75 {
                                  float: left;
                                  width: 75%;
                                  margin-top: 6px;
                                }
                                .row{
                                    padding:0 10px;
                                }
                                /* Clear floats after the columns */
                                .row:after {
                                  content: "";
                                  display: table;
                                  clear: both;
                                }

                                /* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
                                @media screen and (max-width: 600px) {
                                  .col-25, .col-75, input[type=submit] {
                                    width: 100%;
                                    margin-top: 0;
                                  }
                                }
								</style>
								<div class="container-x">
                                  <form method="post" action="" autocomplete="off">
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="fname">ID Pelanggan</label>
                                      </div>
                                      <div class="col-75">
                                        <input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-25">
                                        <label for="kodeproduk">Jenis Layanan</label>
                                      </div>
                                      <div class="col-75">
                                        <select name="kodeproduk" id="kodeproduk" required>
        									<option value="">Pilih </option>
        									<option value="PLNPASCH">Listrik</option>
        									<option value="PLNPRAH">Token</option>
    									</select>
                                      </div>
                                    </div>
                                    <div class="row">
                                      <input type="submit" name="submit" value="SEND" class="submit-button" />
                                    </div>
                                  </form>
                                </div>
						';

            if (empty($_POST) === false) {

                $controller = new UserController;

                if ($controller->getBalanceInfo() < 12000) {

                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;

                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inqpln';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID  Anda
                $uid = 'SP61417';
                //PIN ID  Anda
                $pin = '232323';
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    $result = ($errno > 0) ? 'null' : $data;

                    curl_close($ch);

                    $dom = new DOMDocument;
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = [
                        'PLNPASCH' => [
                            'KODE_PRODUK_VALUE',
                            'WAKTU_VALUE',
                            'IDPEL1_VALUE',
                            'IDPEL2_VALUE',
                            'IDPEL3_VALUE',
                            'NAMA_VALUE',
                            'PERIODE_VALUE',
                            'JML_BULAN_VALUE',
                            'NOMINAL_VALUE',
                            'TARIF_VALUE',
                            'DAYA_VALUE',
                            'REF_VALUE',
                            'STAN_AWAL_VALUE',
                            'STAN_AKHIR_VALUE',
                            'INFOTEKS_VALUE',
                            'ADMIN_VALUE',
                            'UID_VALUE',
                            'PIN_VALUE',
                            'REF1_VALUE',
                            'REF2_VALUE',
                            'REF3_VALUE',
                            'STATUS_VALUE',
                            'KETERANGAN_VALUE',
                            'SALDO_TERPORONG_VALUE',
                            'SISA_SALDO_VALUE',
                            'URL_VALUE',
                        ],
                        'PLNPRAH' => [
                            'KODE_PRODUK_VALUE',
                            'WAKTU_VALUE',
                            'IDPEL1_VALUE',
                            'IDPEL2_VALUE',
                            'IDPEL3_VALUE',
                            'NAMA_VALUE',
                            'NOMINAL_VALUE',
                            'TARIF_VALUE',
                            'DAYA_VALUE',
                            'REF_VALUE',
                            'MATERAI_VALUE',
                            'PPN_VALUE',
                            'PPJ_VALUE',
                            'ANGSURAN_VALUE',
                            'POWER_PURCHASE_VALUE',
                            'KWH_VALUE',
                            'TOKEN_VALUE',
                            'INFOTEKS_VALUE',
                            'ADMIN_VALUE',
                            'UID_VALUE',
                            'PIN_VALUE',
                            'REF1_VALUE',
                            'REF2_VALUE',
                            'REF3_VALUE',
                            'STATUS_VALUE',
                            'KETERANGAN_VALUE',
                            'SALDO_TERPOTONG',
                            'SISA_SALDO',
                            'URL_STRUK_VALUE',
                        ],
                    ];

                    $i = 0;
                    foreach ($arrays as $idx => $array) {
                        $a[$key[$kodeproduk][$i++]] = $array->nodeValue;
                    }

                    echo "<pre>";
                    print_r($a);
                    echo "</pre>";

                    // $rupiah     = number_format(Array2XML::sanitize($a['NOMINAL']) , 2, ',', '.');
                    // $year       = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 0, 4);
                    // $month      = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 4, 2);
                    // $date       = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 6, 2);
                    // $hour       = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 8, 2);
                    // $min        = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 10, 2);
                    // $sec        = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']) , 12, 2);
                    // $mydate     = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                    // $tgl        = date("j F Y, g:i a", $mydate);
                    // $total      = number_format(Array2XML::sanitize($a['NOMINAL'] + 400) , 2, ',', '.');
                    // $promo      = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300) , 2, ',', '.');
                    // $potongan   = number_format(Array2XML::sanitize(1000) , 2, ',', '.');
                    // $admin      = number_format(Array2XML::sanitize(400) , 2, ',', '.');
                    // $petunjuk   = "Bank ke BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal total bayar";
                    // $garansi    = "telegram / whatsapp ke 0856 336 3188";
                    // $format     = " Nama / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                    // $token      = " No token / Nominal Token / No Transaksi dan foto bukti transfer";
                    // $html      .= "";

                }

            } else {
                $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
            }
            echo $html;
        }
    }



    /**
     * Show api Inquiry PLN options
     * Payment goes to : rajabiller_api_paymentPLN
     */
    public function rajabiller_api_inquiryplnempat()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inq';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID  Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID  Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'IDPELANGGAN1',
                        'IDPELANGGAN2',
                        'IDPELANGGAN3',
                        'NAMAPELANGGAN',
                        'PERIODETAGIHAN',
                        'NOMINAL',
                        'BIAYAADMIN',
                        'UID',
                        'PIN',
                        'REF1',
                        'REF2',
                        'REF3',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',
                        'URLSTRUK',
                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> tagihan sudah dibayar</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL'] + 400), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(1000), 2, ',', '.');
                        $admin = number_format(Array2XML::sanitize(400), 2, ',', '.');
                        $petunjuk = "Bank ke BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal total bayar";
                        $garansi = "telegram / whatsapp ke 0856 336 3188";
                        $format = " Nama / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $token = " No token / Nominal Token / No Transaksi dan foto bukti transfer";
                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 10px; right: 80px; }
}
</style>


<table  style='width:100%' class='table_pembayaran_tagihan'>

								<tr>
									<th colspan='2'>Tagihan PLN</th>
</tr>
<tr>
									<th colspan='2'>Loket :$this->wpusername </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Bulan Tagihan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin Listrik</td>
									<td id='right-td'>Rp. {$admin}</td>
								</tr>

<tr>

								<tr>
									<td id='left-td'>Total tagihan PLN</td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2']) . "</td>
								</tr>

								</table>
								<form action=' https://pilihbayar.com/bayar-listrik-admin-3000/ ' method='POST'>
									<input type='hidden' name='head-tagihan' value='2'>
									<input type='hidden' name='tagihan-pln-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pln-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pln-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pln-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pln-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pln-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>



							";

                    }
                }

            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left">Tagihan Listrik </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>
									 <option value="PLNPASCH">Listrik Admin Rp3000</option>
									 <option value="PLNPRAH">Token Admin Rp3000</option>


									</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    /**
     * Show paymentpelen api PLN empat
     */
    public function rajabiller_api_paymentplnempat()
    {
        $html = '';
        if (is_user_logged_in()) {
            $_helpersClass = new Helpers();
            $_helpersClass::cdebug('debug', $_POST);

            //only proceed if post not empty and flag isset propperly
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                if (isset($_POST['head-tagihan'])) {
                    //populate all the tagihan PDAM value
                    if ($_POST['head-tagihan'] == 1) {
                        $nominal = isset($_POST['tagihan-pdam-nominal']) ? $_POST['tagihan-pdam-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pdam-idpelanggan1']) ? $_POST['tagihan-pdam-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pdam-ref1']) ? $_POST['tagihan-pdam-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pdam-ref2']) ? $_POST['tagihan-pdam-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pdam-ref3']) ? $_POST['tagihan-pdam-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pdam-kodeproduk']) ? $_POST['tagihan-pdam-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pdam']);

                    }

                    //populate all the tagihan PLN value
                    if ($_POST['head-tagihan'] == 2) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-pln']);

                    }

                    //populate all the tagihan Telkom value
                    if ($_POST['head-tagihan'] == 3) {
                        $nominal = isset($_POST['tagihan-telkom-nominal']) ? $_POST['tagihan-telkom-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-telkom-idpelanggan1']) ? $_POST['tagihan-telkom-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-telkom-ref1']) ? $_POST['tagihan-telkom-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-telkom-ref2']) ? $_POST['tagihan-telkom-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-telkom-ref3']) ? $_POST['tagihan-telkom-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-telkom-kodeproduk']) ? $_POST['tagihan-telkom-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan Pascabayar value
                    if ($_POST['head-tagihan'] == 4) {
                        $nominal = isset($_POST['tagihan-pln-nominal']) ? $_POST['tagihan-pln-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-pln-idpelanggan1']) ? $_POST['tagihan-pln-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-pln-ref1']) ? $_POST['tagihan-pln-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-pln-ref2']) ? $_POST['tagihan-pln-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-pln-ref3']) ? $_POST['tagihan-pln-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-pln-kodeproduk']) ? $_POST['tagihan-pln-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }

                    //populate all the tagihan TV value
                    if ($_POST['head-tagihan'] == 5) {
                        $nominal = isset($_POST['tagihan-tv-nominal']) ? $_POST['tagihan-tv-nominal'] : '';
                        $idpelanggan1 = isset($_POST['tagihan-tv-idpelanggan1']) ? $_POST['tagihan-tv-idpelanggan1'] : '';
                        $ref1 = isset($_POST['tagihan-tv-ref1']) ? $_POST['tagihan-tv-ref1'] : 0;
                        $ref2 = isset($_POST['tagihan-tv-ref2']) ? $_POST['tagihan-tv-ref2'] : 0;
                        $ref3 = isset($_POST['tagihan-tv-ref3']) ? $_POST['tagihan-tv-ref3'] : 0;
                        $selectedKode = isset($_POST['tagihan-tv-kodeproduk']) ? $_POST['tagihan-tv-kodeproduk'] : '';
                        //unset($_POST['head-tagihan-telkom']);

                    }
                    $rawHtml = '<div id="contact-area">
    								<h2 style="text-align: right">Pembayaran Tagihan</h2><br>
    								<form method="post" action="" autocomplete="off">
    									<label for="kodeproduk">Kode Produk</label>
    									<select name="kodeproduk" id="kodeproduk" required>
    										<option value="">Pilih </option>


<option value="PLNPRAB">Token listrik</option>
    										<option value="PLNPASCB">Tagihan LISTRIK</option>
    										<option value="PLNPRAH">TOKEN</option>
    										<option value="PLNPASCH">Tagihan Listrik</option>
    										<option value="PLNNONH">Tambah Daya</option>
<option value="PLNNONH">Pasang Baru</option>
<option value="PLNNONH">Cicilan pasang Listrik</option>

    									</select>
    									<br/>

    									<label for="idpelanggan1">No pelanggan</label>
    										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan"  value="' . $idpelanggan1 . '" required />
    									<br/>
    									<label for="idpelanggan2"></label>
    										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value=""  />
    									<br/>
    									<label for="idpelanggan3"></label>
    										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="" />
    									<br/>
    									<label for="nominal">Jumlah Tagihan/Token (hapus angka 0 masukkan nilai token)</label>
    										<input type="text" name="nominal" id="nominal" placeholder="Nominal" value="' . $nominal . '" required />
    									<br/>

    									<input type="hidden" name="ref1" id="ref1" value="' . $ref1 . '"   />
    									<label for="ref2">No Referensi</label>
    										<input type="hidden" name="ref2" id="ref2"  placeholder="No Ref" value="' . $ref2 . '" required   />
    									<br/>
    									<input type="hidden" name="ref3" id="ref3" value="' . $ref3 . '"  />
    									<input type="submit" name="submit" value="Bayar" class="btn btn-success" />

    								</form>
    								<div style="clear: both;"></div>

    							</div>';

                    $html .= str_replace('value="' . $selectedKode . '"', 'value="' . $selectedKode . '" selected', $rawHtml);
                } else {
                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < 12000) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    #print_r($_POST);
                    //method rajabiller untuk
                    $method = 'rajabiller.pay';

                    //kode produk
                    $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                    //id pelanggan
                    $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                    //id pelanggan
                    $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                    //id pelanggan
                    $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                    //nominal
                    $nominal = Array2XML::sanitize($_POST['nominal']);

                    //User ID SP Anda
                    $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                    //PIN ID SP Anda
                    $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                    //ref
                    $ref1 = Array2XML::sanitize($_POST['ref1']);

                    //ref
                    $ref2 = Array2XML::sanitize($_POST['ref2']);

                    //ref
                    $ref3 = Array2XML::sanitize($_POST['ref3']);

                    //if deposit < 50k user must be fill their deposit first
                    if ($controller->getBalanceInfo() < $nominal + 450) {
                        echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                        $shortcodes = new WPdepositShortcodes();

                        return;
                    }

                    if (empty($kodeproduk)) {
                        $html .= 'harus diisi';
                    } else {

                        //generate ke XML
                        $tes_xml = array(
                            'methodName' => array(
                                '@value' => $method,
                                //nama method

                            ),
                            'params' => array(
                                'param' => array(

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($kodeproduk), //kode produk

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan1),
                                            //id pelanggan 1

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan2),
                                            //id pelanggan 2

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($idpelanggan3),
                                            //id pelanggan 3

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($nominal), // nominal

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($uid), //User ID Anda

                                        ),
                                    ),
                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($pin), //Pin Anda

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref1), //ref1

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref2), //ref2

                                        ),
                                    ),

                                    array(
                                        'value' => array(
                                            'string' => Array2XML::capital($ref3), //ref3

                                        ),
                                    ),
                                ),
                            ),
                        );

                        $xml = Array2XML::createXML('methodCall', $tes_xml);

                        //jika  tidak ingin melihat request hilangkan kode dibawah
                        //lihat request xml yg akan dikirim
                        $send = $xml->saveXML();

                        //Alamat URL yang di hit ke rajabiller
                        $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                        $ch = curl_init();
                        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                        curl_setopt($ch, CURLOPT_VERBOSE, true);
                        curl_setopt($ch, CURLOPT_POST, true);
                        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                        curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($ch, CURLOPT_URL, $url);
                        curl_setopt($ch, CURLOPT_REFERER, $url);
                        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/text',
                        ));
                        $data = curl_exec($ch);

                        if ($data === false) {
                            printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                            rewind($verbose);
                            $verboseLog = stream_get_contents($verbose);
                            $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                        }

                        $errno = curl_errno($ch);
                        $error = curl_error($ch);

                        if ($errno > 0) {
                            $result = 'null';
                        } else {
                            $result = $data;
                        }

                        //close connection
                        curl_close($ch);

                        //jika tidak ingin melihat response, hilangkan kode dibawah
                        #echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                        //
                        $dom = new DOMDocument;
                        //result
                        $dom->loadXML($result);

                        //pengambilan string dari node <string></string> pada response xml rajabiller
                        $arrays = $dom->getElementsByTagName('string');

                        // membuat array untuk inisiasi masing2 string xml
                        $key = array(
                            'KODEPRODUK',
                            'WAKTU(YYYYMMDDHHIISS)',
                            'IDPELANGGAN1',
                            'IDPELANGGAN2',
                            'IDPELANGGAN3',
                            'NAMAPELANGGAN',
                            'PERIODETAGIHAN',
                            'NOMINAL',
                            'BIAYAADMIN',
                            'UID',
                            'PIN',
                            'REF1',
                            'REF2',
                            'REF3',
                            'STATUS',
                            'KETERANGAN',
                            'SALDOTERPOTONG',
                            'SISASALDO',
                            'URLSTRUK',
                        );
                        //

                        $i = 0;
                        foreach ($arrays as $array) {
                            $a[$key[$i++]] = $array->nodeValue;
                        }

                        if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                            //salah
                            $html .= '<b>Something went wrong!</b><br>';
                            $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';

                        } else {
                            //echopre($a);
                            $rupiah = number_format(Array2XML::sanitize($a['NOMINAL']), 2, ',', '.');
                            $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                            $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                            $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                            $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                            $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                            $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                            $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                            $tgl = date("j F Y, g:i a", $mydate);
                            $admin = number_format(Array2XML::sanitize($a['BIAYAADMIN']), 2, ',', '.');
                            $potongan = number_format(Array2XML::sanitize(1000), 2, ',', '.');
                            $penjumlahan = $a['NOMINAL'] + $a['BIAYAADMIN'];
                            $html .= "
        								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 5px;right:80px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
        								<tr>
        									<th colspan='2'>Bukti Pembayaran tagihan</th>
</tr>
<tr>
									<th colspan='2'>Loket : $this->wpusername</th>
</tr>
<tr>
        									<th colspan='2'> </th>
        								</tr>
        								<tr>
        									<td id='left-td'>Nama Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NAMAPELANGGAN']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>ID Pelanggan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN1']) . "</td>

        								</tr>
<tr>
        									<td id='left-td'>ID Pelanggan2</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['IDPELANGGAN2']) . "</td>

        								</tr>
        								<tr>
        									<td id='left-td'>Periode Bulan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['PERIODETAGIHAN']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Tanggal Tagihan</td>
        									<td id='right-td'>{$tgl}</td>
        								</tr>
        								<tr>
        									<td id='left-td'> Tagihan</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['NOMINAL']) . "</td>
        								</tr>
        								<tr>
        									<td id='left-td'>Biaya Admin</td>
        									<td id='right-td'>{$admin}</td>
        								</tr>

        								<tr>
        									<td id='left-td'>Pembayaran</td>
        									<td id='right-td'>Rp.{$penjumlahan}</td>
        								</tr>
        								<tr>
									<td id='left-td'>Status Pembayaran</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>


        								<tr>
        									<td id='left-td'>Nomor Token</td>
        									<td id='right-td'>" . Array2XML::sanitize($a['REF3']) . "</td>
        								</tr>


        								</table>

        								<button id='bpjs-back' onclick='window.print();'>CETAK</button>
        							";
                            //cut deposit from user
                            $marginAdmin = 100; //keuntungan admin
                            $marginProvider = 300; //keuntungan provider
                            $decrementVal = $nominal + $marginAdmin + $marginProvider;
                            $userModel->decrementRegularBalance($decrementVal);

                            //save transaction in wpdeposit transaction table
                            $userId = $userModel->getId();
                            $itemId = 0;
                            $amount = $decrementVal;
                            $addon = '';
                            $message = 'ID' . $a['IDPELANGGAN1'] . $a['NAMAPELANGGAN'] . $penjumlahan . $a['KETERANGAN'] . $a['REF3'] . $a['URLSTRUK'];
                            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        } //if status  == 00

                    } //if not empty kode produk

                } //if not bayar tagihan

            } //empty post

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        } //if user not login
        echo $html;
    }

    /**
     * Show api game online options
     */
    public function rajabiller_api_gameonline()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.game';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 101900) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>Bukti pembayaran</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['STATUS']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 900; //keuntungan admin
                        $marginProvider = 100025; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 0); //saldo provider
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">E Money</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih </option>





<option value="SHOP100H">ShopeePay 100K</option>
<option value="OVO100H">SaldoGrabOVO 100K</option>
<option value="GJK100H">SaldoGOjek 100K</option>
<option value="DANA100H">DANA 100K</option>
<option value="GJD100H">GOPAY DRIVER(GOPAY) 100K</option>
<option value="LINK100H">LINKAJA 100K</option>





				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

/**
 * Show api game online options
 */
    public function rajabiller_api_shopee()
    {
        $html = '';
        $_helpersClass = new Helpers();
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;
                $userModel = new UserModel;
                $transaction = new TransactionModel;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk
                $method = 'rajabiller.game';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //noHP
                $nohp = Array2XML::sanitize($_POST['nohp']);

                //User ID SP Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID SP Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);
                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 101900) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                if (empty($nohp)) {
                    $html .= 'harus diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($nohp), // nohp

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODEPRODUK',
                        'WAKTU(YYYYMMDDHHIISS)',
                        'NOHP',
                        'UID',
                        'PIN',
                        'SN',
                        'REF1',
                        'REF2',
                        'STATUS',
                        'KETERANGAN',
                        'SALDOTERPOTONG',
                        'SISASALDO',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    $a['STATUS'] = '00';
                    if ($a['STATUS'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b>Something went wrong!</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);

                        $html .= "
								<style type='text/css'>
@media print
{
body * { visibility: hidden; }
table.table_pembayaran_tagihan * { visibility: visible; }
table.table_pembayaran_tagihan { position: absolute; top: 40px; left: 30px; }
}
</style>
        								<table  style='width:100%' class='table_pembayaran_tagihan'>
								<tr>
									<th colspan='2'>Bukti pembayaran</th>
</tr>
<tr>
									<th colspan='2'>$this->wpusername</th>
</tr>
<tr>
									<th colspan='2'> </th>
								</tr>
								<tr>
									<td id='left-td'>Kode Produk</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KODEPRODUK']) . "</td>

								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NOHP']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>SN</td>
									<td id='right-td'>" . Array2XML::sanitize($a['SN']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>status</td>
									<td id='right-td'>" . Array2XML::sanitize($a['STATUS']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Keterangan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['KETERANGAN']) . "</td>
								</tr>
								</table>
								<button id='bpjs-back' onclick='window.history.back();'>BACK</button>
								<button id='bpjs-back' onclick='window.print();'>CETAK</button>

							";

                        //cut deposit from user
                        $marginAdmin = 900; //keuntungan admin
                        $marginProvider = 500025; //keuntungan provider
                        $nominal = ($a['SALDOTERPOTONG'] + 0); //saldo provider
                        $decrementVal = $nominal + $marginAdmin + $marginProvider;
                        $userModel->decrementRegularBalance($decrementVal);

                        //save transaction in wpdeposit transaction table
                        $userId = $userModel->getId();
                        $itemId = 0;
                        $amount = $decrementVal;
                        $addon = '';
                        $message = 'NoHP ' . $nohp;
                        $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

                        $_helpersClass::cdebug('debug', 'testing');
                    }
                }

            } else {

                $html .= '
					<div id="contact-area">
				<h2 style="text-align: right">E Money</h2><br>
				<form method="post" action="" autocomplete="off">

				<select name="kodeproduk" id="kodeproduk" required>
				<option value="">Pilih </option>





<option value="SHOP500H">ShopeePay 500K</option>
<option value="OVO500H">OVO 500K</option>
<option value="GJK500H">SaldoGOjek 500K</option>
<option value="DANA500H">DANA 500K</option>
<option value="LINK500H">LINKAJA 500K</option>






				</select>



					<input type="text" name="nohp" id="nohp" placeholder="Nomor HP"  required />

					<input type="hidden" name="ref1" id="ref1" value="0"  required   />

					<input type="submit" name="submit" value="SEND" class="submit-button" />
				</form>
				<div style="clear: both;"></div>
			</div>
				';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }
        echo $html;
    }

    /**
     * Show api Inquiry PLN options
     * Payment goes to : rajabiller_api_paymentPLN
     */
    public function rajabiller_api_leasingsiapbayar()
    {
        $html = '';
        if (is_user_logged_in()) {
            if (empty($_POST) === false) {
                $controller = new UserController;

                //if deposit < 50k user must be fill their deposit first
                if ($controller->getBalanceInfo() < 12000) {
                    echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Segera Topup Saldo deposit anda untuk bisa bertransaksi dengan lancar,klik->isi saldo deposit setelah transfer ke rek mohon konfirmasi di WA 0856 336 3188</h3>';

                    $shortcodes = new WPdepositShortcodes();

                    return;
                }

                //method rajabiller untuk cek saldo
                $method = 'rajabiller.inqpln';

                //kode produk
                $kodeproduk = Array2XML::sanitize($_POST['kodeproduk']);

                //id pelanggan
                $idpelanggan1 = Array2XML::sanitize($_POST['idpelanggan1']);

                //periode tagihan
                $idpelanggan2 = Array2XML::sanitize($_POST['idpelanggan2']);

                //periode tagihan
                $idpelanggan3 = Array2XML::sanitize($_POST['idpelanggan3']);

                //User ID  Anda
                $uid = 'SP61417'; //Array2XML::sanitize($_POST['uid']);
                //PIN ID  Anda
                $pin = '232323'; //Array2XML::sanitize($_POST['pin']);
                //ref
                $ref1 = Array2XML::sanitize($_POST['ref1']);

                if (empty($idpelanggan1)) {
                    $html .= 'kode area dan telepon diisi';
                } else {

                    //generate ke XML
                    $tes_xml = array(
                        'methodName' => array(
                            '@value' => $method,
                            //nama method

                        ),
                        'params' => array(
                            'param' => array(

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($kodeproduk), //kode produk

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan1),
                                        //id pelanggan 1

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan2),
                                        //id pelanggan 2

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($idpelanggan3),
                                        //id pelanggan 3

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($uid), //User ID Anda

                                    ),
                                ),
                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($pin), //Pin Anda

                                    ),
                                ),

                                array(
                                    'value' => array(
                                        'string' => Array2XML::capital($ref1), //ref1

                                    ),
                                ),
                            ),
                        ),
                    );

                    $xml = Array2XML::createXML('methodCall', $tes_xml);

                    //jika  tidak ingin melihat request hilangkan kode dibawah
                    //lihat request xml yg akan dikirim
                    $send = $xml->saveXML();

                    //Alamat URL yang di hit ke rajabiller
                    $url = 'https://rajabiller.fastpay.co.id/transaksi/index.php';

                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_VERBOSE, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $send);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_REFERER, $url);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                        'Content-Type: application/text',
                    ));
                    $data = curl_exec($ch);

                    if ($data === false) {
                        printf("cUrl error (#%d): %s<br>\n", curl_errno($ch), htmlspecialchars(curl_error($ch)));
                        rewind($verbose);
                        $verboseLog = stream_get_contents($verbose);
                        $html .= "Verbose information:\n<pre>" . htmlspecialchars($verboseLog) . "</pre>\n";
                    }

                    $errno = curl_errno($ch);
                    $error = curl_error($ch);

                    if ($errno > 0) {
                        $result = 'null';
                    } else {
                        $result = $data;
                    }

                    //close connection
                    curl_close($ch);

                    //jika tidak ingin melihat response, hilangkan kode dibawah
                    //echo "<hr><b>Cek Tagihan BPJS Kesehatan :</b> <br /><br />" . nl2br(htmlentities($result)) . "<br /><br />"; //lihat response dari server rajabiller berupa xml
                    //
                    $dom = new DOMDocument;
                    //result
                    $dom->loadXML($result);

                    //pengambilan string dari node <string></string> pada response xml rajabiller
                    $arrays = $dom->getElementsByTagName('string');

                    // membuat array untuk inisiasi masing2 string xml
                    $key = array(
                        'KODE_PRODUK_VALUE',
                        'WAKTU_VALUE',
                        'IDPEL1_VALUE',
                        'IDPEL2_VALUE',
                        'IDPEL3_VALUE',
                        'NAMA_VALUE',
                        'NOMINAL_VALUE',
                        'TARIF_VALUE',
                        'DAYA_VALUE',
                        'REF_VALUE',
                        'MATERAI_VALUE',
                        'PPN_VALUE',
                        'PPJ_VALUE',
                        'ANGSURAN_VALUE',
                        'POWER_PURCHASE_VALUE',
                        'KWH_VALUE',
                        'TOKEN_VALUE',
                        'INFOTEKS_VALUE',
                        'ADMIN_VALUE',
                        'UID_VALUE',
                        'PIN_VALUE',
                        'REF1_VALUE',
                        'REF2_VALUE',
                        'REF3_VALUE',
                        'STATUS_VALUE',
                        'KETERANGAN_VALUE',
                        'SALDO_TERPOTONG',
                        'SISA_SALDO',
                        'URL_STRUK_VALUE',

                    );
                    //

                    $i = 0;
                    foreach ($arrays as $array) {
                        $a[$key[$i++]] = $array->nodeValue;
                    }

                    if ($a['STATUS_VALUE'] !== '00') { //jika status tidak sama dengan 00 (sukses)
                        //salah
                        $html .= '<b> tagihan sudah dibayar</b><br>';
                        $html .= 'String Keterangan: ' . Array2XML::sanitize($a['KETERANGAN_VALUE']) . '<br><br>';
                    } else {
                        //echopre($a);
                        $rupiah = number_format(Array2XML::sanitize($a['NOMINAL_VALUE']), 2, ',', '.');
                        $year = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 0, 4);
                        $month = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 4, 2);
                        $date = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 6, 2);
                        $hour = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 8, 2);
                        $min = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 10, 2);
                        $sec = substr(Array2XML::sanitize($a['WAKTU(YYYYMMDDHHIISS)']), 12, 2);
                        $mydate = strtotime($year . "-" . $month . "-" . $date . " " . $hour . ":" . $min . ":" . $sec);
                        $tgl = date("j F Y, g:i a", $mydate);
                        $total = number_format(Array2XML::sanitize($a['NOMINAL_VALUE'] + 450), 2, ',', '.');
                        $promo = number_format(Array2XML::sanitize($a['NOMINAL'] + $a['BIAYAADMIN'] - 300), 2, ',', '.');
                        $potongan = number_format(Array2XML::sanitize(300), 2, ',', '.');
                        $admin = number_format(Array2XML::sanitize(450), 2, ',', '.');
                        $petunjuk = "Bank ke BRI 0067-010087-52530 a/n smita catur s & Mandiri 171000-1877383 a/n nurbaiti riastini. Bayar sesuai nominal total bayar";
                        $garansi = "telegram / whatsapp ke 0856 336 3188";
                        $format = " Nama / id pelanggan / total bayar / No Transaksi dan foto bukti transfer";
                        $token = " No token / Nominal Token / No Transaksi dan foto bukti transfer";
                        $html .= "
								<style type='text/css'>
                                @media print
                                {
                                body * { visibility: hidden; }
                                table.table_pembayaran_tagihan * { visibility: visible; }
                                table.table_pembayaran_tagihan { position: absolute; top: 20px; left: 10px; right: 80px; }
                                }
                                </style>
                                
                                
                                <table  style='width:100%' class='table_pembayaran_tagihan'>

								<tr>
									<th colspan='2'>Tagihan PLN</th>
                                </tr>
                                <tr>
									<th colspan='2'>$this->wpusername </th>
								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['NAMA_VALUE']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Nama Pelanggan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['IDPEL1_VALUE']) . "</td>

								</tr>
								<tr>
									<td id='left-td'>Bulan Tagihan</td>
									<td id='right-td'>" . Array2XML::sanitize($a['WAKTU_VALUE']) . "</td>
								</tr>
								<tr>
									<td id='left-td'>Tanggal Tagihan</td>
									<td id='right-td'>{$tgl}</td>
								</tr>
								<tr>
									<td id='left-td'>tagihan</td>
									<td id='right-td'>Rp. {$rupiah} </td>
								</tr>
								<tr>
									<td id='left-td'>Biaya Admin</td>
									<td id='right-td'>Rp. {$admin}</td>
								</tr>


								<tr>
									<td id='left-td'>Total tagihan PLN</td>
									<td id='right-td'>Rp. {$total} </td>
								</tr>

								<tr>
									<td id='left-td'>Nomor</td>
									<td id='right-td'>" . Array2XML::sanitize($a['REF2_VALUE']) . "</td>
								</tr>

								</table>
								<form action='  https://pilihbayar.com/listrik-pay/  ' method='POST'>
									<input type='hidden' name='head-tagihan' value='2'>
									<input type='hidden' name='tagihan-pln-kodeproduk' value='{$kodeproduk}'>
									<input type='hidden' name='tagihan-pln-idpelanggan1' value='{$a['IDPELANGGAN1']}'>
									<input type='hidden' name='tagihan-pln-nominal' value='{$a['NOMINAL']}'>
									<input type='hidden' name='tagihan-pln-ref1' value='{$a['REF1']}'>
									<input type='hidden' name='tagihan-pln-ref2' value='{$a['REF2']}'>
									<input type='hidden' name='tagihan-pln-ref3' value='{$a['REF3']}'>
									<button type='submit' value='Bayar Tagihan'>Bayar Tagihan</button>
								</form>



							";

                    }
                }

            } else {
                $html .= '  <div id="contact-area">
									<h2 style="text-align: left">Tagihan Listrik </h2><br>
									<form method="post" action="" autocomplete="off">
									<select name="kodeproduk" id="kodeproduk" required>
									<option value="">Pilih </option>
									  	<option value="PLNPASCH">Tagihan Listrik</option> 							</select>
										<input type="text" name="idpelanggan1" id="idpelanggan1" placeholder="id pelanggan" required />
										<input type="hidden" name="idpelanggan2" id="idpelanggan2" value="00"  required />
										<input type="hidden" name="idpelanggan3" id="idpelanggan3" value="00" required />
										<input type="hidden" name="ref1" id="ref1" value="0" required />
										<input type="submit" name="submit" value="SEND" class="submit-button" />
									</form>
									<div style="clear: both;"></div>
								</div>
						';
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    public function api_siapbayar_cek_saldo()
    {
        siapbayar::get_request();

    }

    public function get_option($wpEl, $post)
    {
        $options = array(
            0 => array(
                'value' => 'PILIH',
                'option' => 'PILIH',
            ),
            array(
                'value' => 'ASBPJSKS',
                'option' => 'BPJS Kesehatan',
            ),
            array(
                'value' => 'PLNPAC',
                'option' => 'Tagihan Listrik',
            ),

            array(
                'value' => 'PAMAET',
                'option' => 'AETRA JAKARTA',
            ),
            array(
                'value' => 'PAMPLJ',
                'option' => 'PALYJA JAKARTA',
            ),

            array(
                'value' => 'PAMBGR',
                'option' => 'KOTA BOGOR',
            ),
            array(
                'value' => 'PAMBTM',
                'option' => 'ATB BATAM',
            ),
            array(
                'value' => 'PAMKBGR',
                'option' => 'KAB BOGOR',
            ),

            array(
                'value' => 'PAMKBBS',
                'option' => 'KAB BREBES',
            ),
            array(
                'value' => 'PAMBLA',
                'option' => 'KAB BLORA',
            ),
            array(
                'value' => 'PAMPLG',
                'option' => 'PDAM KOTA PALEMBANG',
            ),

            array(
                'value' => 'PAMBKS',
                'option' => 'PDAM KOTA BEKASI',
            ),

            array(
                'value' => 'PAMKPWT',
                'option' => 'PDAM KAB BANYUMAS',
            ),
            array(
                'value' => 'PAMKBYL',
                'option' => 'PDAM KAB BOYOLALI',
            ),
            array(
                'value' => 'PAMCMS',
                'option' => 'PDAM CIAMIS',
            ),
            array(
                'value' => 'PAMCBN',
                'option' => 'PDAM CIREBON',
            ),
            array(
                'value' => 'PAMKCLP',
                'option' => 'KAB CILACAP',
            ),
            array(
                'value' => 'PAMSKB',
                'option' => 'PDAM SUKABUMI',
            ),

            array(
                'value' => 'PAMSMD',
                'option' => 'PDAM KAB SUMEDANG',
            ),

            array(
                'value' => 'PAMKBDGBR',
                'option' => 'PDAM BANDUNG BARAT',
            ),
            array(
                'value' => 'PAMKBDG',
                'option' => 'PDAM KAB BANDUNG',
            ),

            array(
                'value' => 'PAMBDG',
                'option' => 'PDAM KOTA BANDUNG',
            ),

            array(
                'value' => 'PAMKPWR',
                'option' => 'PDAM KAB PURWOREJO',
            ),
            array(
                'value' => 'PAMGRT',
                'option' => 'PDAM KAB GARUT',
            ),
            array(
                'value' => 'PAMKKWG',
                'option' => 'KAB KARAWANG',
            ),
            array(
                'value' => 'PAMKPWD',
                'option' => 'PDAM KAB GROBOGAN',
            ),
            array(
                'value' => 'PAMKKRG',
                'option' => 'PDAM KAB KARANGANYAR',
            ),
            array(
                'value' => 'PAMKKBM',
                'option' => 'PDAM KAB KEBUMEN',
            ),
            array(
                'value' => 'PAMKBTG',
                'option' => 'PDAM KAB BATANG',
            ),

            array(
                'value' => 'PAMBLA',
                'option' => 'PDAM KAB BLORA',
            ),

            array(
                'value' => 'PAMKSMN',
                'option' => 'PDAM KAB SLEMAN',
            ),

            array(
                'value' => 'PAMWAT',
                'option' => 'PDAM KAB KULONPROGO',
            ),

            array(
                'value' => 'PAMKWNG',
                'option' => 'PDAM KAB WONOGIRI',
            ),

            array(
                'value' => 'PAMKSKH',
                'option' => 'PDAM KAB SUKOHARJO',
            ),
            array(
                'value' => 'PAMKRBG',
                'option' => 'KAB REMBANG',
            ),
            array(
                'value' => 'PAMKSMG',
                'option' => 'KAB SEMARANG',
            ),
            array(
                'value' => 'PAMSMG',
                'option' => 'KOTA SEMARANG',
            ),
            array(
                'value' => 'PAMKJPA',
                'option' => 'KAB JEPARA',
            ),
            array(
                'value' => 'PAMPTI',
                'option' => 'KAB. PATI',
            ),
            array(
                'value' => 'PAMKTMG',
                'option' => 'KAB TEMANGGUNG',
            ),

            array(
                'value' => 'PAMKKBM',
                'option' => 'PDAM KAB KEBUMEN',
            ),

            array(
                'value' => 'PAMKJPA',
                'option' => 'PDAM KAB JEPARA',
            ),

            array(
                'value' => 'PAMKDR',
                'option' => 'KOTA KEDIRI',
            ),

            array(
                'value' => 'PAMKGSK',
                'option' => 'KAB GRESIK',
            ),

            array(
                'value' => 'PAMKJMR',
                'option' => 'KAB JEMBER',
            ),

            array(
                'value' => 'PAMMGT',
                'option' => 'KAB MAGETAN',
            ),
            array(
                'value' => 'PAMMAD',
                'option' => 'KOTA MADIUN',
            ),
            array(
                'value' => 'PAMPNG',
                'option' => 'KAB PONOROGO',
            ),
            array(
                'value' => 'PAMMLG',
                'option' => 'KOTA MALANG',
            ),
            array(
                'value' => 'PAMKMLG',
                'option' => 'KAB MALANG',
            ),
            array(
                'value' => 'PAMKBDW',
                'option' => 'KAB. BONDOWOSO',
            ),
            array(
                'value' => 'PAMKBGN',
                'option' => 'KAB. BOJONEGORO',
            ),

            array(
                'value' => 'PAMKMJK',
                'option' => ' KAB. MOJOKERTO',
            ),
            array(
                'value' => 'PAMKPBL',
                'option' => '  KAB. PROBOLINGGO',
            ),
            array(
                'value' => 'PAMKSDA',
                'option' => '  KAB. SIDOARJO',
            ),
            array(
                'value' => 'PAMKSIT',
                'option' => '  KAB. SITUBONDO',
            ),
            array(
                'value' => 'PAMPSR',
                'option' => '  KOTA PASURUAN',
            ),
            array(
                'value' => 'PAMJBG',
                'option' => '  KAB. JOMBANG',
            ),

            array(
                'value' => 'PAMKKLN',
                'option' => 'KAB KLATEN',
            ),
            array(
                'value' => 'PAMSKT',
                'option' => 'KOTA SOLO/SURAKARTA',
            ),
            array(
                'value' => 'PAMKPYA',
                'option' => 'PDAM KAB LOMBOK TENGAH',
            ),
            array(
                'value' => 'PAMMTR',
                'option' => 'KOTA MATARAM',
            ),
            array(
                'value' => 'PAMBJB',
                'option' => 'KOTA BANJARBARU',
            ),

            array(
                'value' => 'PAMBDL',
                'option' => 'KOTA BANDAR LAMPUNG',
            ),
            array(
                'value' => 'PAMPBU',
                'option' => 'KAB PANGKALAN BUN',
            ),

            array(
                'value' => 'PAMPLW',
                'option' => 'PDAM POLEWALIMANDAR',
            ),
            array(
                'value' => 'PAMMDN',
                'option' => 'KOTA MEDAN',
            ),

            array(
                'value' => 'PAMBJR',
                'option' => 'KOTA BANJAR',
            ),
            array(
                'value' => 'PAMKIS',
                'option' => 'KOTA KISARAN',
            ),
            array(
                'value' => 'PAMBRB',
                'option' => 'PDAM BARABAI',
            ),
            array(
                'value' => 'PAMBJM',
                'option' => 'KOTA BANJARMASIN',
            ),
            array(
                'value' => 'PAMKPRN',
                'option' => 'KAB BALANGAN',
            ),

            array(
                'value' => 'PAMMND',
                'option' => 'KOTA MANADO',
            ),

        );
        $productcode = isset($post['productcode']) ? $post['productcode'] : false;
        $optionList = '';
        $params = array(
            'default' => (($productcode) ? $productcode : ''),
            'for_table' => false,
        );
        $optionList = $wpEl->select_field($options, 'productcode', 'Kode Produk', $params);
        return $optionList;
    }

    public function api_siapbayar_inq()
    {
        $html = '';
        if (is_user_logged_in()) {
            $userModel = new UserModel;
            $wpelements = new WP_elements();
            $userId = $userModel->getId();
            $form_member = '';
            $inq_response = array();
            $controller = new UserController;

            //if deposit < 50k user must be fill their deposit first
            if ($controller->getBalanceInfo() < 0) {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Saldo deposit anda kurang dari Rp.12.000 , silahkan melakukan deposit.</h3>';
                $shortcodes = new WPdepositShortcodes();
                $shortcodes->show_payment_interface();
                return;
            }

            //only proceed if post not empty and flag isset propperly
            if (!empty($_POST)) {
                $productcode = isset($_POST['productcode']) ? $_POST['productcode'] : '';

                $dtPageByPrefix = Siapbayar::get_page_by_prefix($productcode, $_POST, $userId);
                $form_page = $dtPageByPrefix['page'] . ".php";

                if (isset($dtPageByPrefix['response']) && !empty($dtPageByPrefix['response'])) {
                    $response = $dtPageByPrefix['response'];
                }
                $post = $_POST;
                include WPDEPOSIT_PATH . '/views/inquiry/frontend/' . $form_page;
            } else {
                $post = array();
            }

            $inquiry_option = $this->get_option($wpelements, $post);
            include WPDEPOSIT_PATH . '/views/inquiry/frontend/main_form.php';
            $html .= $inquirylRequest;
            //if deposit < nomimal user must be fill their deposit first
            if ($controller->getBalanceInfo() < 0) {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                $shortcodes = new WPdepositShortcodes();

                return;
            }
        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        echo $html;
    }

    public function api_siapbayar_pay()
    {
        $html = '';
        if (is_user_logged_in()) {

            $userModel = new UserModel;
            $wpelements = new WP_elements();
            $userId = $userModel->getId();
            $form_member = '';
            $pay_response = array();
            $controller = new UserController;
            $transaction = new TransactionModel;

            //if deposit < 50k user must be fill their deposit first
            if ($controller->getBalanceInfo() < 1) {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Saldo deposit anda kurang  , silahkan melakukan deposit.</h3>';
                $shortcodes = new WPdepositShortcodes();
                $shortcodes->show_payment_interface();
                return;
            }

            //only proceed if post not empty and flag isset propperly
            if (!empty($_POST) && isset($_POST['productcode'])) {
                $productcode = $_POST['productcode'];

                if ($productcode !== '') {
                    $dtPageByPrefix = Siapbayar::get_page_by_prefix($productcode, $_POST, $userId);
                    $form_page = $dtPageByPrefix['page'] . ".php";
                    //echo $form_page;die();

                    if (isset($dtPageByPrefix['response']) && !empty($dtPageByPrefix['response'])) {
                        $pay_response = $dtPageByPrefix['response'];

                    }

                    $post = $_POST;
                    include WPDEPOSIT_PATH . '/views/payment/frontend/' . $form_page;
                } else {
                    $post = array();
                    $form_member = '';
                }

            } else {
                $post = array();

            }

            $payment_option = $this->get_option($wpelements, $post);
            include WPDEPOSIT_PATH . '/views/payment/frontend/main_form.php';

            $html .= $paymentlRequest;

            //if deposit < nomimal user must be fill their deposit first
            if ($controller->getBalanceInfo() < 1) {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Saldo deposit anda kurang  , silahkan melakukan deposit dengan minimal transfer deposit Rp 100.000</h3>';
                $shortcodes = new WPdepositShortcodes();
                $shortcodes->show_payment_interface();
                return;
            } else {
                echo "<pre>";
                print_r($pay_response);
                echo "</pre>";

                // //cut deposit from user
                // $marginAdmin = 400; //keuntungan admin
                // $marginProvider = 100; //keuntungan provider
                // $decrementVal = $nominal + $marginAdmin + $marginProvider;
                // $userModel->decrementRegularBalance($decrementVal);
                // //save transaction in wpdeposit transaction table
                // $userId = $userModel->getId();
                // $itemId = 0;
                // $amount = $decrementVal;
                // $addon = '';
                // $message = 'nobukti transaksi ' . $a['refsbinq'];
                // $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);
            }

        } else {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        return $html;
    }

}
