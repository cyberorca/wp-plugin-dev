<?php
require_once WPDEPOSIT_PATH . '/classes/helpers.php';
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/controllers/api/rajabiller.php';
require_once WPDEPOSIT_PATH . '/controllers/api/siapbayar.php';
require_once WPDEPOSIT_PATH . '/controllers/shortcodes.php';
include_once (WPDEPOSIT_PATH . '/models/user.php');
include_once (WPDEPOSIT_PATH . '/models/transaction.php');

class ApiSiapbayarController extends wpdepositAbstractController
{
    /**
     * construct function
     *
     * @return void
     * @author Doni Kuntoro
     *
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function api_siapbayar_cek_saldo()
    {
        siapbayar::get_request();

    }

    public function get_option($wpEl, $post)
    {
        $options = array(
            0 => array(
                'value' => 'GP10',
                'option' => 'Googleplay $10'
            ) ,
            array(
                'value' => 'GP15',
                'option' => 'Googleplay $15'
            ) ,
            array(
                'value' => 'GP25',
                'option' => 'Googleplay $25'
            ) ,
            array(
                'value' => 'GP50',
                'option' => 'Googleplay $500'
            ) ,
            array(
                'value' => 'ITN10',
                'option' => 'itunes $10'
            ) ,
            array(
                'value' => 'ITN15',
                'option' => 'itunes $15'
            ) ,
            array(
                'value' => 'ITN25',
                'option' => 'itunes $25'
            ) ,
            array(
                'value' => 'ITN50',
                'option' => 'itunes $50'
            ) ,

        );
        $productcode = isset($post['productcode']) ? $post['productcode'] : false;
        $optionList = '';
        $params = array(
            'default' => (($productcode) ? $productcode : '') ,
            'for_table' => false
        );
        $optionList = $wpEl->select_field($options, 'productcode', 'Kode Produk', $params);
        return $optionList;
    }

    public function api_siapbayar_inquiry()
    {
        print_r($_REQUEST);
        die();
        
        $html = '';
        if (is_user_logged_in())
        {

            $userModel = new UserModel;
            $wpelements = new WP_elements();
            $userId = $userModel->getId();
            $form_member = '';
            $inq_response = array();
            $controller = new UserController;

            //if deposit < 50k user must be fill their deposit first
            if ($controller->getBalanceInfo() < 0)
            {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Saldo deposit anda kurang dari Rp.12.000 , silahkan melakukan deposit.</h3>';
                $shortcodes = new WPdepositShortcodes();
                $shortcodes->show_payment_interface();
                return;
            }

            //only proceed if post not empty and flag isset propperly
            if (!empty($_POST))
            {
                $productcode = isset($_POST['productcode']) ? $_POST['productcode'] : '';

                $dtPageByPrefix = Siapbayar::get_page_by_prefix($productcode, $_POST, $userId);
                $form_page = $dtPageByPrefix['page'] . ".php";

                if (isset($dtPageByPrefix['response']) && !empty($dtPageByPrefix['response']))
                {
                    $response = $dtPageByPrefix['response'];
                }
                $post = $_POST;
                include WPDEPOSIT_PATH . '/views/inquiry/frontend/' . $form_page;
            }
            else
            {
                $post = array();
            }
            
            $inquiry_option = $this->get_option($wpelements, $post);
            include WPDEPOSIT_PATH . '/views/inquiry/frontend/main_form.php';
            $html .= $inquirylRequest;
            //if deposit < nomimal user must be fill their deposit first
            if ($controller->getBalanceInfo() < $nominal)
            {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">saldo kurang dari minimal saldo silahkan klik isi deposit dibawah ini</h3>';

                $shortcodes = new WPdepositShortcodes();

                return;
            }
        }
        else
        {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        return $html;
    }

    public function api_siapbayar_payment()
    {
        $html = '';
        if (is_user_logged_in())
        {

            $userModel = new UserModel;
            $wpelements = new WP_elements();
            $userId = $userModel->getId();
            $form_member = '';
            $pay_response = array();
            $controller = new UserController;
            $transaction = new TransactionModel;

            //only proceed if post not empty and flag isset propperly
            if (!empty($_POST))
            {
                $productcode = isset($_POST['productcode']) ? $_POST['productcode'] : '';

                $dtPageByPrefix = Siapbayar::get_page_by_prefix($productcode, $_POST, $userId);
                $form_page = $dtPageByPrefix['page'] . ".php";

                if (isset($dtPageByPrefix['response']) && !empty($dtPageByPrefix['response']))
                {
                    $pay_response = $dtPageByPrefix['response'];

                }

                $post = $_POST;
                include WPDEPOSIT_PATH . '/views/payment/frontend/' . $form_page;

            }
            else
            {
                $post = array();

            }

            $payment_option = $this->get_option($wpelements, $post);

            include WPDEPOSIT_PATH . '/views/payment/frontend/main_form.php';
            $html .= $paymentlRequest;
            //if deposit < nomimal user must be fill their deposit first
            if ($controller->getBalanceInfo() < $nominal)
            {
                echo '<h3 style="color:red !important;border:1px solid #f0f0f0;">Saldo deposit anda kurang  , silahkan melakukan deposit dengan minimal deposit Rp 107.000</h3>';
                $shortcodes = new WPdepositShortcodes();
                $shortcodes->show_payment_interface();
                return;
            }

            //cut deposit from user
            $marginAdmin = 500; //keuntungan admin
            $marginProvider = 1000; //keuntungan provider
            $decrementVal = $nominal + $marginAdmin + $marginProvider;
            $userModel->decrementRegularBalance($decrementVal);

            //save transaction in wpdeposit transaction table
            $userId = $userModel->getId();
            $itemId = 0;
            $amount = $decrementVal;
            $addon = '';
            $message = 'nobukti transaksi ' . $a['refsbinq'];
            $transaction->logTransaction($userId, $itemId, $amount, $addon, $message);

        }

        else
        {
            $html .= '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to start transaction.', WPDEPOSIT_NAME) . '</a>';
        }

        return $html;
    }
}

