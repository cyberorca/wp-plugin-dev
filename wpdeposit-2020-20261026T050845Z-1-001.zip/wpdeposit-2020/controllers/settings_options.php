<?php
include_once WPDEPOSIT_PATH . '/controllers/abstract.php';
include_once WPDEPOSIT_PATH . '/models/settings_options.php';

class SettingsOptionsController extends wpdepositAbstractController {

    const MAIL_WITHDRAWAL_REJECTED = 'MAIL_WITHDRAWAL_REJECTED';
    const MAIL_WITHDRAWAL_FINISHED = 'MAIL_WITHDRAWAL_FINISHED';

    public function index()
    {
        global $currencies;
        $wpelements = new WP_elements();
        $pages = array(
		'depth'        => 0,
		'child_of'     => 0,
		'title_li'     => __('Pages'),
		'echo'         => false,
		'sort_column'  => 'menu_order, post_title',
		);
        $paymentModel = new PaymentOptionsModel();
        $paymentOptions = $paymentModel->getOverview();

        include WPDEPOSIT_PATH . '/views/settings/options.php';
    }

    public function updateTestOptionsSettings()
    {
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        $response = $model->updateTestOptionsSettings();
        $response = json_encode( array('success' => true));
        do_action('wpds_update_test_options_settings');
        $wpelements->jsonResponseOutput($response);
    }

    public function updateSettings()
    {
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        $response = $model->updateSettings();
        $response = json_encode( array('success' => true));
        do_action('wpds_update_settings');
        $wpelements->jsonResponseOutput($response);
    }

    public function updateGatewaySettings()
    {
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        foreach($_POST as $key => $value)
        {
            if (!is_array($value) && empty($value)) {
                $response = json_encode( array('success' => false, 'message' => 'The field ' . $key . ' cannot be empty!'));
                $wpelements->jsonResponseOutput($response);
            }
        }
        $success = $model->updateGatewaySettings();
        $response = json_encode( array('success' => $success, 'message' => __('Gateway settings updated.', WPDEPOSIT_NAME)));
        do_action('wpds_update_gateway_settings', $_POST);
        $wpelements->jsonResponseOutput($response);
    }
    
    public function settingAddImage()
    {
        do_action('wpds_setting_add_image_before', $_POST);
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        $success = $model->settingAddImage();
        $response = json_encode( array('success' => $success, 'message' => __('Image succesfully uploaded & saved.', WPDEPOSIT_NAME)));
        do_action('wpds_setting_add_image_after', $_POST);
        $wpelements->jsonResponseOutput($response);
    }

    public function updateMailTemplateSettings()
    {
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        $success = $model->updateMailtemplateSettings();
        $response = json_encode( array('success' => $success, 'message' => __('Mail templates updated.', WPDEPOSIT_NAME)));
        do_action('wpds_update_mail_template_settings', $_POST);
        $wpelements->jsonResponseOutput($response);
    }

    public function getMailTemplates()
    {
        $wpelements = new WP_elements();
        $model = new SettingsOptionsModel();
        include WPDEPOSIT_PATH . '/views/settings/mailtemplates.php';
    }

    public function loadMailTemplate($templateName, $params)
    {
        do_action('wpds_load_mail_templates_before', $templateName, $params);
        $model = new SettingsOptionsModel();
        $template = $model->getTemplateContent($templateName);
        if (is_array($params)) {
           foreach ($params as $key => $param) {
               $template = str_replace(strtoupper($key), $param, $template);
            } 
        }
        do_action('wpds_load_mail_templates_after', $templateName, $params);
        return $template;
    }
    
    public function depositSuccess()
    {
        
    }
    
    public function customViews()
    {
        $themeDir = ABSPATH . 'wp-content/themes/' . get_template() . '/wpdeposit/';
        $depositFormViewPage = 'deposit_form.php';
        $customViewsExist = false;
        if (is_dir($themeDir) && file_exists($themeDir . $depositFormViewPage)) {
            $customViewsExist = true;
        }
        include WPDEPOSIT_PATH . '/views/settings/custom_views.php';
    }
    
    public function createCustomViews()
    {
        $wpelements = new WP_elements();
        $filesCreated = false;
        $templateSourceFolder = WPDEPOSIT_PATH . '/views/';
        $themeDir = ABSPATH . 'wp-content/themes/' . get_template() . '/wpdeposit/';
        $depositFormViewPage = 'deposit_form.php';
        try{
            if (!is_dir($themeDir)) {
                mkdir($themeDir, 0777);
            }
            $depositPageContent = file_get_contents($templateSourceFolder . 'payment/frontend/' . $depositFormViewPage);
            if (!$depositPageContent) {
                throw new Exception('Can\'t get the content of the template for the deposit page.');
            }
            if ($fp = fopen($themeDir . $depositFormViewPage, 'w')) {
                fwrite($fp, $depositPageContent);
                fclose($fp);
                $response = json_encode( array('success' => true));
            }
        } catch(Exception $e){
            $response = json_encode( array('success' => false, 'message' => $e->getMessage()));
        }
        $wpelements->jsonResponseOutput($response);
    }

    public function pointFields()
    {
        $wpelements = new WP_elements();
        try{
            $model = new SettingsOptionsModel();
            $model->savePointFields();
            $response = json_encode( array('success' => true));
        } catch(Exception $e){
            $response = json_encode( array('success' => false, 'message' => $e->getMessage()));
        }
        $wpelements->jsonResponseOutput($response);
    }

    public function testOptions()
    {
        $wpelements = new WP_elements();
        include WPDEPOSIT_PATH . '/views/settings/test_options.php';
    }

    public function testBalance()
    {
        $wpelements = new WP_elements();
        try{
            $amount = 10;
            $userModel = new UserModel();
            if ($_POST['type'] == 'increment') {
                if(WPD_CREDIT_TYPE == 'points') {
                    $userModel->incrementPointsBalance($amount);
                } else {
                    $userModel->incrementBalance($amount);
                }
            } else {
                if(WPD_CREDIT_TYPE == 'points') {
                    $userModel->decrementPointsBalance($amount);
                } else {
                    $userModel->decrementBalance($amount);
                }
            }
            $response = json_encode( array('success' => true, 'message' => the_credit_type_text(true, null, true)));
        } catch(Exception $e){
            $response = json_encode( array('success' => false, 'message' => $e->getMessage()));
        }
        $wpelements->jsonResponseOutput($response);
    }

}