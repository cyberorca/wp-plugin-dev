<?php

require_once WPDEPOSIT_PATH . '/models/abstract.php';
require_once WPDEPOSIT_PATH . '/models/updates.php';

class updatesController extends wpdepositAbstractController {

    public $currentVersion;
    /**
     * construct function
     *
     * @return void
     * */
    public function __construct() {
        $this->currentVersion = get_option(WPDEPOSIT_NAME . '_plugin_version');
    }

    public function checkVersion() {
        //add option to see if content or options are already present in the database (eg: if user already activated the plugin once in the past)
        
        if (!empty($this->currentVersion) && $this->currentVersion != '') {
            if($this->currentVersion < WPDEPOSIT_VERSION)
            {
                $model = new updatesModel();
            	if($model->updateDb($this->currentVersion, WPDEPOSIT_VERSION)){
                    update_option(WPDEPOSIT_NAME . '_plugin_version', WPDEPOSIT_VERSION);
                }	
            }
        } else {
            self::firstInstall();
        }
    }

    public function firstInstall() {
        $model = new updatesModel();
        $model->firstInstall();
        
        //create standard pages
        $this->createDepositPages();
    }
    
    public function createDepositPages() {
        global $user_ID;
        $pages = array( 
            array(
                'name' => 'deposit',
                'title' => 'Deposit',
                'content' => '[wpdeposit_payment_interface]',
                'child' => array(
                    array( 'name' => 'deposit_history', 'title' => 'Your deposit history', 'content' => '[wpdeposit_deposit_history]' ),
                    array( 'name' => 'deposit_transactions', 'title' => 'WPdeposit transactions', 'content' => '[wpdeposit_transactions]' ),
                    array( 'name' => 'deposit_withdrawals', 'title' => 'WPdeposit withdrawals', 'content' => '[wpdeposit_withdrawals]' ),
                    array( 'name' => 'deposit_donate', 'title' => 'Donate', 'content' => '[wpdeposit_donate_to_user]' ),
                    array( 'name' => 'deposit_success', 'title' => 'Deposit success page', 'content' => 'Your deposit was successfull.' ),
                    array( 'name' => 'deposit_open', 'title' => 'Deposit open page', 'content' => 'Your deposit is still open and in progress.' ),
                    array( 'name' => 'deposit_failure', 'title' => 'Deposit failure', 'content' => 'Your deposit failed. Please contact the administrator.' ),
                    array( 'name' => 'deposit_expired', 'title' => 'Deposit expired page', 'content' => 'Your deposit expired.' ),
                    array( 'name' => 'deposit_cancel', 'title' => 'Deposit cancel', 'content' => 'We are sorry to see you cancelled your deposit' ),
                    array( 'name' => 'deposit_cancel', 'title' => 'Deposit cancel', 'content' => 'We are sorry to see you cancelled your deposit' ),
                    array( 'name' => 'withdrawals', 'title' => 'Withdrawals', 'content' => '[wpdeposit_withdrawals]' ),
                )
            )
        );

        $template = array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_author' => $user_ID
        );

        foreach( $pages as $page ) {
            $exists = get_page_by_title( $page['name'] );

            if( !$exists ) {
                $my_page = array(
                    'post_name' => $page['name'],
                    'post_title' => $page['title'],
                    'post_content' => $page['content']
                );
                $my_page = array_merge( $my_page, $template );

                $pageId = wp_insert_post( $my_page );

                //if there is any child page, create them by {$id} as 'post_parent'
                if( isset( $page['child'] ) ) {
                    foreach( $page['child'] as $child ) {
                        $child_page = array(
                            'post_name' => $child['name'],
                            'post_title' => $child['title'],
                            'post_content' => $child['content'],
                            'post_parent' => $pageId
                        );
                        $child_page = array_merge( $child_page, $template );
                        $id = wp_insert_post( $child_page );
                    }
                }
            }
        }
    }

    /**
     * This function checks if the admin properly updated to the new point system
     */
    public function checkPointConvertion()
    {
        $converted = get_option(WPDEPOSIT_NAME . '_new_points_conversion');
        if(WPD_CREDIT_TYPE == 'points' && (empty($converted) || !$converted)) {
            add_action( 'admin_notices', array($this, 'my_admin_notice') );
        }
    }

    public function my_admin_notice() {
        ?>
        <div class="error">
            <?php
            $message = _( 'It looks like you are using points. We have a new exchange option, you must {url}update first{url_close} before you proceed!', WPDEPOSIT_NAME );
            $message = str_replace('{url}', '<a href="' . get_bloginfo('url') . '/wp-admin/admin.php?page=wpdeposit_plugin#convert_points" class="convert-points">', $message);
            $message = str_replace('{url_close}', '</a>', $message);
            ?>
            <p><?php '<strong>WPDEPOSIT:</strong> ' . $message; ?></p>
        </div>
    <?php
    }

}
