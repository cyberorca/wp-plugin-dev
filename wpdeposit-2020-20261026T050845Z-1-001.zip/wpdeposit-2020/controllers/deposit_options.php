<?php
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/controllers/settings_options.php';
require_once WPDEPOSIT_PATH . '/models/deposit_options.php';

class DepositOptionsController extends wpdepositAbstractController {

    /**
     * construct function
     *
     * @return void
     * @author Christophe Debruel
     * */
    public function __construct() {
        parent::__construct();
    }

    /**
     * function to check if payment was already made using the unique id returned by the payment gateway (to prevent multiple deposit on page refresh)
     *
     * @return void
     * @author Christophe Debruel
     * */
    public function checkPayment($taxId) {
        do_action('wpds_check_payment_before', $taxId);
        $model = new DepositOptionsModel();
        $result = $model->getPaymentDetailsByUniqueId($taxId);
        do_action('wpds_check_payment_after', $taxId);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function processPayment($params) {
        do_action('wpds_process_payment_before', $params);
        $settings = new SettingsOptionsController();
        $model = new DepositOptionsModel();
        if (!$model->updateUserDeposits($params, true)) {
            return false;
        }
        $settings->depositSuccess();
        do_action('wpds_process_payment_after', $params);
        return true;
    }

    public function completePayment($params)
    {
        do_action('wpds_complete_payment_before', $params);
        $settings = new SettingsOptionsController();
        $model = new DepositOptionsModel();
        if (!$model->completePayment($params)) {
            return false;
        }
        do_action('wpds_complete_payment_after', $params);
        return true;
    }

    public function cancelPayment($params)
    {
        do_action('wpds_cancel_payment_before', $params);
        $settings = new SettingsOptionsController();
        $model = new DepositOptionsModel();
        if (!$model->cancelPayment($params)) {
            return false;
        }
        do_action('wpds_cancel_payment_after', $params);
        return true;
    }

    public function getDepositDetail($uid)
    {
        do_action('wpds_get_deposit_detail_before', $uid);
        $model = new DepositOptionsModel();
        $row = $model->getPaymentDetailsByUniqueId($uid);
        do_action('wpds_get_deposit_detail_after', $row);
        return $row;
    }

    public function getDepositHistory() {
        do_action('wpds_get_deposit_history_before');
        $model = new DepositOptionsModel();
        $rows = $model->getDepositHistory();
        do_action('wpds_get_deposit_history_after');
        return $rows;
    }

    public function getCompleteHistory() {
        $wpelements = new WP_elements();
        try {
            $model = new DepositOptionsModel();
            if(isset($_POST['filter_keyword']) && !empty($_POST['filter_keyword']) && isset($_POST['search_in']) && !empty($_POST['search_in']))
            {
//                if (!Validation_class::check_alphanumeric($_POST['filter_keyword'])) {
//                    throw new Exception('Keyword has invalid charachters. Only letters and numbers.');
//                }
                if (!Validation_class::check_text($_POST['search_in'], '_-')) {
                    throw new Exception('"Search in" has invalid charachters. Only letters and numbers.');
                }
                $filterKeywords = $_POST['filter_keyword'];
                $searchIn = $_POST['search_in'];
                $feedback = '<h3>' . __('Search results for', WPDEPOSIT_NAME) . ': ' . $filterKeywords . '</h3>';
                if($searchIn == 'users'){
                    $rows = $model->getDepositHistoryByUsername($filterKeywords);
                } elseif ($searchIn == 'unique_code') {
                    $rows = $model->getDepositHistoryByUniqueCode($filterKeywords);
                }
            } else {
                $rows = $model->getDepositHistory();
            }
        } catch(Exception $e) {
            $feedback = '<div class="">' . $e->getMessage() . '</div>';
        }
        include WPDEPOSIT_PATH . '/views/deposit/deposit_list.php';
    }

    public function depositFailedMail() {
        do_action('wpds_deposit_failed_mail_before');
        $settings = new SettingsOptionsController();
        $headers = "From:" . get_bloginfo('adminmail') . "\r\n";
        $mailmessage = $settings->loadMailTemplate(WPDEPOSIT_NAME . '_error_mail_content', array(
            'username' => $this->_user->display_name,
            'sitename' => get_bloginfo('name'),
                ));
        /**
         * use wp_mail?
         */
        mail($this->_user->user_email, "Your deposit failed", $mailmessage, $headers);
        do_action('wpds_deposit_failed_mail_after');
    }

    public function depositSuccessMail() {
        do_action('wpds_deposit_success_mail_before');
        $settings = new SettingsOptionsController();
        $headers = "From:" . get_bloginfo('adminmail') . "\r\n";
        $mailmessage = $settings->loadMailTemplate(WPDEPOSIT_NAME . '_error_mail_content', array(
            'username' => $depositcash->$username,
            'amount' => $amount,
            'siteurl' => $siteurl,
            'adminmail' => $adminmail,
            'sitename' => $sitename,
                ));
        mail($payer_email, "Your deposit", $mailmessage, $headers);
        do_action('wpds_deposit_success_mail_after');
    }

    public function markDepositCompleted()
    {
        do_action('wpds_mark_deposit_complete_before');
        $wpelements = new WP_elements();
        $model = new DepositOptionsModel();
        $unique_code = wp_kses($_POST['unique_code'],array());
        $details = $model->getPaymentDetailsByUniqueId($unique_code);
        $params = array(
                'userid' => $details->userid,
                'unique_code' => $unique_code,
                'amount' => $details->amount,
        );
        $success = $model->markDepositCompleted($params);
        $response = json_encode( array('success' => $success, 'message' => 'Deposit marked as completed.'));
        do_action('wpds_mark_deposit_complete_after');
        $wpelements->jsonResponseOutput($response);
    }

    public function markDepositSuspend()
    {
        do_action('wpds_mark_deposit_suspend_before');
        $wpelements = new WP_elements();
        $model = new DepositOptionsModel();
        $success = $model->markDepositSuspend();
        $response = json_encode( array('success' => $success, 'message' => 'Deposit marked as pending.'));
        do_action('wpds_mark_deposit_suspend_after');
        $wpelements->jsonResponseOutput($response);
    }
    
    public function donate_to_user_interface()
    {
        $wpelements = new WP_elements();
        include WPDEPOSIT_PATH . '/views/deposit/donate_to_user.php';
        return $donate;
    }

}
