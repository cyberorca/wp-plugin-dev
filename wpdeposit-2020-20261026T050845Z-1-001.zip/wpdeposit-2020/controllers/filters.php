<?php

class WPdepositFilters extends wpdepositAbstractController {

	public function __construct()
	{
		add_filter( 'manage_users_columns', array($this, 'addCustomColumnHeading') );
		add_filter( 'manage_users_custom_column', array($this, 'addCustomColumnContent'), 10, 3 );
	}

	public function addCustomColumnHeading($column)
	{
		$column['deposit'] = 'Deposit balance';
		return $column;
	}

	public function addCustomColumnContent($val, $column_name, $user_id )
	{
		$user = new UserModel($user_id);
		$return = '';

		switch ($column_name) {
			case 'deposit' :
				$balance = (int) $user->getBalance();
				return the_credit_type_text(true, $balance, true);
				break;

			default:
				break;
		}

		return $return;
	}

}
