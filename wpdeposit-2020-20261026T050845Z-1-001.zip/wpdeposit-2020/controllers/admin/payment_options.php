<?php
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/models/payment_options.php';

/**
 * Payment options controller
 */
class PaymentOptionsController extends wpdepositAbstractController {

    /**
     * @var WP_elements 
     */
    protected $_wpelements = null;

    public function __construct() {
        parent::__construct();
        $this->_wpelements = new WP_elements();
    }
    
    /**
     * Add a payment option via ajax
     * @return string json string
     */
    public function add() {
        $model = new PaymentOptionsModel();
        do_action('wpds_add_payment_option_before');
        $data = array(
            'price' => isset($_POST['price']) ? $_POST['price'] : null,
            'bonus' => isset($_POST['bonus']) ? $_POST['bonus'] : null,
            'default_convertion' => isset($_POST['default_convertion']) ? $_POST['default_convertion'] : 0,
        );
        if (!isset($data['price']) || !Validation_class::check_is_float($data['price'])) {
            $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
            $this->_wpelements->jsonResponseOutput($response);
        }
	    if (!isset($data['bonus']) || !Validation_class::check_is_float($data['bonus'])) {
            $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
            $this->_wpelements->jsonResponseOutput($response);
        }
        if (WPD_SHOW_POINT_FIELDS) {
            $data['points'] = (isset($_POST['points'])) ? $_POST['points'] : null;
            if (!isset($data['points']) || !Validation_class::check_is_float($data['points'])) {
                $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
                $this->_wpelements->jsonResponseOutput($response);
            }
        }

        $success = $model->add($data);

        $response = json_encode(array('success' => $success));
        do_action('wpds_add_payment_option_after');
        $this->_wpelements->jsonResponseOutput($response);
    }
    
    /**
     * Edit a payment option via ajax
     * @return string json string
     */
    public function edit() {
        $model = new PaymentOptionsModel();
        do_action('wpds_edit_payment_option_before');
        $data = array(
            'price' => isset($_POST['price']) ? $_POST['price'] : null,
            'bonus' => isset($_POST['bonus']) ? $_POST['bonus'] : null,
            'default_convertion' => isset($_POST['default_convertion']) ? $_POST['default_convertion'] : 0,
        );
        
        if (!isset($data['price']) || !Validation_class::check_is_float($data['price'])) {
            $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
            $this->_wpelements->jsonResponseOutput($response);
        }
	    if (!isset($data['bonus']) || !Validation_class::check_is_float($data['bonus'])) {
		    $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
		    $this->_wpelements->jsonResponseOutput($response);
	    }
        if (WPD_SHOW_POINT_FIELDS) {
            $data['points'] = (isset($_POST['points'])) ? $_POST['points'] : null;

            if (!isset($data['points']) || !Validation_class::check_is_float($data['points'])) {
                $response = json_encode(array('success' => false, 'message' => 'Validation failed, please corret the form'));
                $this->_wpelements->jsonResponseOutput($response);
            }
        }
        $id = (int) isset($_POST['id']) ? $_POST['id'] : null;
        if (!$id || $id < 1) {
            $response = json_encode(array('success' => false, 'message' => 'Id not set'));
            $this->_wpelements->jsonResponseOutput($response);
        }
        
        $success = $model->edit($id, $data);

        $response = json_encode(array('success' => $success));
        do_action('wpds_edit_payment_option_after');
        $this->_wpelements->jsonResponseOutput($response);
    }
    
    /**
     * Delete a payment option via ajax
     * @return string json string
     */
    public function delete() {
        $model = new PaymentOptionsModel();
        do_action('wpds_delete_payment_option_before');
        $id = (int) isset($_POST['id']) ? $_POST['id'] : null;
        if (!$id || $id < 1) {
            $response = json_encode(array('success' => false, 'message' => 'Id not set'));
            $this->_wpelements->jsonResponseOutput($response);
        }
        $success = $model->delete($id);
        $response = json_encode(array('success' => $success));
        do_action('wpds_delete_payment_option_after');
        $this->_wpelements->jsonResponseOutput($response);
    }

    /**
     * Show a overview with payment options
     */
    public function index() {
        $model = new PaymentOptionsModel();
        do_action('wpds_show_payment_options_before');
        $paymentOptions = $model->getOverview();
        include WPDEPOSIT_PATH . '/views/payment/backend/index.php';
        do_action('wpds_show_payment_options_after');
    }
    
    /**
     * Get a single payment option
     * @return string json string
     */
    public function getPaymentOption() {
        $id = (int) isset($_GET['id']) ? $_GET['id'] : null;
        if (!$id || $id < 1) {
            $response = json_encode(array('success' => false, 'message' => 'Id not set'));
            $this->_wpelements->jsonResponseOutput($response);
        }

        $model = new PaymentOptionsModel();
        $moneyOption = $model->getForId($id);

        $response = json_encode(array('success' => true, 'record' => $moneyOption));
        $this->_wpelements->jsonResponseOutput($response);
    }

	public function getPaymentOptionByAmount($amount)
	{
		$model = new PaymentOptionsModel();
		return $model->getByAmount($amount);
	}

	public function getPaymentOptionByPoints($points)
	{
		$model = new PaymentOptionsModel();
		return $model->getByPoints($points);
	}
    /**
     * Show a list of payment options
     */
    public function getPaymentOptions() {
        $model = new PaymentOptionsModel();
        $paymentOptions = $model->getOverview();
        include WPDEPOSIT_PATH . '/views/payment/backend/list.php';
        exit;
    }
    
    /**
     * Show a list of payment gateways
     */
    public function getPaymentGateways() {
        $gateways = new WPD_Payment_Gateways();
        $paymentGatewayList = $gateways->generateAdminHtml();
        include WPDEPOSIT_PATH . '/views/settings/gateway_list.php';
    }
    
    /**
     * Show a list of payment options
     */
    public function depositMoneyInterface() {
        if (is_user_logged_in()) {
            $model = new PaymentOptionsModel();
            $paymentOptions = $model->getOverview();
            $gateways = new WPD_Payment_Gateways();
            $paymentGatewayList = $gateways->generateFrontendHtml();
            include WPDEPOSIT_PATH . '/views/payment/frontend/list_inputs.php';
        } else {
            echo '<a href="' . wp_login_url(get_permalink()) . '" title="Login">' . __('Please login to deposit money on your account.', WPDEPOSIT_NAME) . '</a>';
        }
    }
    
    /**
     * Forward to the right gateway
     */
    public function forwardToGateway() {
	
        do_action('wpds_forward_gateway_before');
        $custom_amount = false;
        if (!isset($_POST['deposit_amount']) || !Validation_class::check_is_float($_POST['deposit_amount'])) {
            if (!Validation_class::check_is_float($_POST['deposit_custom_amount'])) {
                $response = json_encode(array('success' => false, 'message' => 'The specified deposit amount is incorrect (only numeric values)!'));
                $this->_wpelements->jsonResponseOutput($response);
            }
            if (!isset($_POST['deposit_custom_amount'])) {
                //error
                $response = json_encode(array('success' => false, 'message' => 'You did not select or provide a custom deposit amount!'));
                $this->_wpelements->jsonResponseOutput($response);
            } elseif(DEPOSIT_LIMIT_AMOUNT > 0 && $_POST['deposit_custom_amount'] > DEPOSIT_LIMIT_AMOUNT) {
                $response = json_encode(array('success' => false, 'message' => 'The specified deposit amount exceeds the limit. The maximum deposit limit is ' . the_credit_type_text(true, DEPOSIT_LIMIT_AMOUNT, true, false)));
                $this->_wpelements->jsonResponseOutput($response);
            } else {
                $custom_amount = true;
            }
			
        }
        
        if (!isset($_POST['payment_gateway']) || !Validation_class::check_text($_POST['payment_gateway'], '\_')) {
            $response = json_encode(array('success' => false, 'message' => 'You did not select a correct payment gateway or you did not select one at all!'));
            $this->_wpelements->jsonResponseOutput($response);
        }

        if ($custom_amount) {
            $amount = wp_kses($_POST['deposit_custom_amount'], array());
        } else {
            $amount = wp_kses($_POST['deposit_amount'], array());
        }
        
        if (class_exists($_POST['payment_gateway'])) {
            $pgClassName = $_POST['payment_gateway'];
            $pgClass = new $pgClassName();
            $pgMethodName = 'initPaymentProcess';
            if (!method_exists($pgClass, $pgMethodName)) {
                $response = json_encode(array('success' => false, 'message' => 'The payment gateway ' . $pgClassName . ' doesn\'t have a method ' . $pgMethodName . '. It is required!'));
                $this->_wpelements->jsonResponseOutput($response);
            }
            $response = $pgClass->initPaymentProcess($amount);
        } else {
            $response = json_encode(array('success' => false, 'message' => 'You did not select a correct payment gateway!'));
            $this->_wpelements->jsonResponseOutput($response);
        }
		
        $this->_wpelements->jsonResponseOutput($response);
		
    }

    /**
     * Show deposit history
     */
    public function depositHistory() {
        $model = new DepositOptionsModel();
        $rows = $model->getPaymentHistoryByUserId($this->_user->ID);
        include WPDEPOSIT_PATH . '/views/deposit/history.php';
	    return $content;
    }
}