<?php

require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/models/updates.php';

class systemController extends wpdepositAbstractController {

    /**
     * construct function
     *
     * @return void
     * */
    public function __construct() {
        parent::__construct();
    }

    public function index() {
	    $missingTable = $this->dbCheck();
        $pathToLog = WPDEPOSIT_PATH.'/deposit_log.txt';
        $logs = $this->getLogs($pathToLog);
        include WPDEPOSIT_PATH . "/views/system/backend/index.php";
    }

    public static function getLogs($pathToLog)
    {
        $logs = null;
        if (file_exists($pathToLog)) {
            $logs = trim(self::read_backward_line($pathToLog, 50, true));
        }
        return $logs;
    }

    public static function read_backward_line($filename, $lines, $revers = false)
    {
        $offset = -1;
        $c = '';
        $read = '';
        $i = 0;
        $fp = @fopen($filename, "r");
        if ($fp === false) {
            return;
        }
        while( $lines && fseek($fp, $offset, SEEK_END) >= 0 ) {
            $c = fgetc($fp);
            if($c == "\n" || $c == "\r"){
                $lines--;
                if( $revers ){
                    @$read[$i] = @strrev($read[$i]);
                    $i++;
                }
            }
            if($revers) {
                @$read[$i] .= $c;
            } else {
                $read .= $c;
            }
            $offset--;
        }
        fclose ($fp);
        if( $revers ){
            if(@$read[$i] == "\n" || @$read[$i] == "\r") {
                array_pop($read);
            } else {
                @$read[$i] = strrev($read[$i]);
            }
            return implode('',$read);
        }
        return strrev(rtrim($read,"\n\r"));
    }

	public function dbCheck()
	{
		$missingTable = array();
		if(!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix . "deposit_history" . "'")) {
			$missingTable[] = $this->_wpdb->prefix . "deposit_history is missing.";
		}
		if(!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix . "payment_options" . "'")) {
			$missingTable[] = $this->_wpdb->prefix . "payment_options is missing.";
		}
		if(!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix . "wpd_transactions" . "'")) {
			$missingTable[] = $this->_wpdb->prefix . "wpd_transactions is missing.";
		}
		if(!$this->_wpdb->get_var("SHOW TABLES LIKE '" . $this->_wpdb->prefix . "wpd_withdrawals" . "'")) {
			$missingTable[] = $this->_wpdb->prefix . "wpd_withdrawals is missing.";
		}
		if(!$this->_wpdb->get_var("SHOW COLUMNS FROM " . $this->_wpdb->prefix . "payment_options" . " WHERE field = 'bonus'")) {
			$missingTable[] = "bonus column is missing in " . $this->_wpdb->prefix . "payment_options .";
		}
		return $missingTable;
	}

}