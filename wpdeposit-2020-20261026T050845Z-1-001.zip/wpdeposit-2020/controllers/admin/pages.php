<?php
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';


class WPdepositAdminFunctions extends wpdepositAbstractController {

	public function __construct()
	{
		add_menu_page('WPdeposit', 'WPdeposit', 'administrator', WPDEPOSIT_NAME . '_plugin', array($this, 'mainSettings'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Settings', WPDEPOSIT_NAME), __('Settings', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_plugin', array($this, 'mainSettings'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Reward system', WPDEPOSIT_NAME), __('Reward system', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_reward_system', array($this, 'rewardSystem'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Deposits', WPDEPOSIT_NAME), __('Deposits', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_deposits', array($this, 'depositsList'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Payment Options', WPDEPOSIT_NAME), __('Payment Options', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_payment_option_plugin', array($this, 'paymentOptions'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Transactions', WPDEPOSIT_NAME), __('Transactions', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_transactions', array($this, 'transactions'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Withdrawals', WPDEPOSIT_NAME), __('Withdrawals', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_withdrawals', array($this, 'withdrawals'));
		//add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('Add-ons', WPDEPOSIT_NAME), __('Add-ons', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_add_ons', array($this, 'add_ons'));
		add_submenu_page(WPDEPOSIT_NAME . '_plugin', __('System', WPDEPOSIT_NAME), __('System', WPDEPOSIT_NAME), 'administrator', WPDEPOSIT_NAME . '_system', array($this, 'system'));
	}

	/**
	 * Show main settings in tabs
	 *
	 * @return void
	 * */
	public function mainSettings()
	{
		$wpelements = new WP_elements(WPDEPOSIT_VERSION);
		echo $wpelements->openWrapper(__('Main settings', WPDEPOSIT_NAME));
		?>
		<h2 class="nav-tab-wrapper">
			<?php do_action('wpds_add_setting_tab_title_before'); ?>
			<a id="tab_1" class="nav-tab" href="javascript:void(0);"><?php _e('General Settings', WPDEPOSIT_NAME); ?></a>
			<a id="tab_2" class="nav-tab" href="javascript:void(0);"><?php _e('Test options', WPDEPOSIT_NAME); ?></a>
			<a id="tab_3" class="nav-tab" href="javascript:void(0);"><?php _e('Payment Gateway\'s', WPDEPOSIT_NAME); ?></a>
			<a id="tab_4" class="nav-tab" href="javascript:void(0);"><?php _e('Mail Templates', WPDEPOSIT_NAME); ?></a>
			<a id="tab_5" class="nav-tab" href="javascript:void(0);"><?php _e('Money vs ', WPDEPOSIT_NAME); echo POINTS_NAME_PLURAL; ?></a>
			<a id="tab_6" class="nav-tab" href="javascript:void(0);"><?php _e('Custom views', WPDEPOSIT_NAME); ?></a>
			<?php do_action('wpds_add_setting_tab_title_after'); ?>
		</h2>
		<div class="tab_box box_tab_1">
			<?php
			$obj = new SettingsOptionsController();
			$obj->index();
			?>
		</div>
		<div class="tab_box box_tab_2">
			<?php
			$obj = new SettingsOptionsController();
			$obj->testOptions();
			?>
		</div>
		<div class="tab_box box_tab_3">
			<?php
			$obj = new PaymentOptionsController();
			$obj->getPaymentGateways();
			?>
		</div>
		<div class="tab_box box_tab_4">
			<?php
			$obj = new SettingsOptionsController();
			$obj->getMailTemplates();
			?>
		</div>
		<div class="tab_box box_tab_5">
			<?php
			$obj = new PointOptionsController();
			$obj->index();
			?>
		</div>
		<div class="tab_box box_tab_6">
			<?php
			$obj = new SettingsOptionsController();
			$obj->customViews();
			?>
		</div>
		<?php do_action('wpds_add_setting_tab_content'); ?>
		<?php
		echo $wpelements->closeWrapper();
	}


	/**
	 * Show a list of deposits in the backend
	 *
	 * @return void
	 * */
	public function depositsList()
	{
		$wpelements = new WP_elements(WPDEPOSIT_NAME);
		echo $wpelements->openWrapper(__('Deposits', WPDEPOSIT_NAME));
		$obj = new DepositOptionsController();
		$obj->getCompleteHistory();
		echo $wpelements->closeWrapper();
	}

	/**
	 */
	public function rewardSystem()
	{
		$wpelements = new WP_elements();
		echo $wpelements->openWrapper('Rewards');
		$obj = new RewardsController();
		$obj->overviewAdmin();
		echo $wpelements->closeWrapper();
	}

	/**
	 * function to manage the payment options
	 *
	 * @return void
	 * */
	public function paymentOptions()
	{
		$wpelements = new WP_elements();
		echo $wpelements->openWrapper(__('Payment options', WPDEPOSIT_NAME));
		$obj = new PaymentOptionsController();
		$obj->index();
		echo $wpelements->closeWrapper();
	}

	/**
	 */
	public function transactions()
	{
		$wpelements = new WP_elements();
		echo $wpelements->openWrapper('Transactions');
		$obj = new TransactionController();
		$obj->overviewAdmin();
		echo $wpelements->closeWrapper();
	}

	/**
	 */
	public function withdrawals()
	{
		$deposit = new DepositOptionsController();
		$wpelements = new WP_elements();
		echo $wpelements->openWrapper('Withdrawal');
		$obj = new WithdrawalController();
		$obj->overviewAdmin();
		echo $wpelements->closeWrapper();
	}


	/**
	 * backend users balances overview
	 */
	public function system()
	{
		$wpelements = new WP_elements();
		echo $wpelements->openWrapper('System info');
		$obj = new SystemController();
		$obj->index();
		echo $wpelements->closeWrapper();
	}

}