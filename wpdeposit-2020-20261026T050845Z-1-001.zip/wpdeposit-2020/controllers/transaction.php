<?php
include_once(WPDEPOSIT_PATH . '/models/user.php');
include_once(WPDEPOSIT_PATH . '/models/transaction.php');

class TransactionController extends wpdepositAbstractController 
{
    public function overview()
    {
        $userModel = new UserModel();
        $model = new TransactionModel();
        $transactions = $model->getForUser($userModel->getId());
        $cookie_name = 'test';
        if(!isset($_COOKIE[$cookie_name])) {
			include WPDEPOSIT_PATH . '/views/transaction/frontend/overview.php';
		} else {
			echo "Cookie '" . $cookie_name . "' is set!<br>";
			echo "Value is: " . $_COOKIE[$cookie_name];
			include WPDEPOSIT_PATH . '/views/transaction/frontend/overview.php';
		}

    }
    
    public function overviewAdmin()
    {
        $wpelements = new WP_elements();

        try {
            $model = new TransactionModel();
            if(isset($_POST['filter_keyword']) && !empty($_POST['filter_keyword']) && isset($_POST['search_in']) && !empty($_POST['search_in']))
            {
                if (!Validation_class::check_text($_POST['search_in'], '_-')) {
                    throw new Exception('"Search in" has invalid charachters. Only letters and numbers.');
                }
                $filterKeywords = $_POST['filter_keyword'];
                $searchIn = $_POST['search_in'];
                $feedback = '<h3>' . __('Search results for', WPDEPOSIT_NAME) . ': ' . $filterKeywords . '</h3>';
                if($searchIn == 'users'){
                    $transactions = $model->getAllByUsers($filterKeywords);
                } elseif($searchIn == 'type'){
                    $transactions = $model->getAllByType($filterKeywords);
                }
            } else {
                $transactions = $model->getAll();
            }
        } catch(Exception $e) {
            $feedback = '<div class="">' . $e->getMessage() . '</div>';
        }
        include WPDEPOSIT_PATH . '/views/transaction/backend/overview.php';
    }
}
