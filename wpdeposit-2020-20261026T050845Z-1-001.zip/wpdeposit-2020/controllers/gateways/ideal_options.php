<?php

include_once WPDEPOSIT_PATH . '/controllers/settings_options.php';
include_once WPDEPOSIT_PATH . '/controllers/deposit_options.php';

class WPD_Ideal_Gateway extends WPD_Payment_Gateways {
    
    public $_gatewayName = 'ideal';
    
    public $_icon;
    
    public function __construct() {
        include_once WPDEPOSIT_PATH . '/classes/ideal/idealprofessional.cls.php';
        parent::__construct();
    }
    
        
    public function getIcon(){
        $this->_icon = WPDEPOSIT_URL . '/resources/images/ideal.png';
        return $this->_icon;
    }
    
        
    public function getGatewayName(){
        return $this->_gatewayName;
    }

    /**
     * Function to determine if payment is in test mode or not
     * */
    public function payment_action() {
        if (get_option(WPDEPOSIT_NAME . '_test_mode') == 1):
            return "https://test.authorize.net/gateway/transact.dll";
        else:
            return "https://secure.authorize.net/gateway/transact.dll";
        endif;
    }
    

    public function getFormFields()
    {
        $formFields = array(
            'title' => 'iDeal Options',
            'fields' => array(
                array(
                    'type' => 'textfield', 
                    'name' => 'ideal_aquirer', //also used for the id
                    'label' => __('Aquirer', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
                array(
                    'type' => 'textfield', 
                    'name' => 'ideal_merchant_id', //also used for the id
                    'label' => __('Merchant ID', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
                array(
                    'type' => 'textfield', 
                    'name' => 'ideal_private_key', //also used for the id
                    'label' => __('Private key pass', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
                array(
                    'type' => 'uploadfile', 
                    'name' => 'ideal_private_key_file', //also used for the id
                    'label' => __('Private.key file', WPDEPOSIT_NAME),
                    'btn_name' => __('Upload File', WPDEPOSIT_NAME),
                    'extention' => '*.key', //seperate each extention with a comma 
                    'uploadpath' => WPDEPOSIT_PATH . '/classes/ideal/ssl/', //add trailing slash at the end!
                    'extra_options' => array('size' => 30, 'class' => 'upload_field') //extra option for in the field, the class is required
                ),//end of upload field
                                array(
                    'type' => 'uploadfile', 
                    'name' => 'ideal_private_cer', //also used for the id
                    'label' => __('Private.cer file', WPDEPOSIT_NAME),
                    'btn_name' => __('Upload File', WPDEPOSIT_NAME),
                    'extention' => '*.cer', //seperate each extention with a comma 
                    'uploadpath' => WPDEPOSIT_PATH . '/classes/ideal/ssl/', //add trailing slash at the end!
                    'extra_options' => array('size' => 30, 'class' => 'upload_field') //extra option for in the field, the class is required
                ),//end of upload field
            )//end of array fields
        );//end of main array
        
        return apply_filters('wpds_ideal_form_fields', $formFields);
    }
    
        
    public function initPaymentProcess($amount)
    {
        do_action('wpds_ideal_payment_process_init');
        try {
            $response = json_encode(array('success' => true,
                'message' => __('Forwarding you to Paypal', WPDEPOSIT_NAME),
                'processtype' => 'formdialog', //ideal requires user input, therefore a dialog screen
                'dialog_screen_title' => 'iDeal payment process', //ideal requires user input, therefore a dialog screen
                'form' => self::deposit_form($amount),
                'callback' => 'process_ideal_payment',
                'dialog_fields' => array('order_id', 'order_description', 'order_amount', 'order_issuer'), //fields to get value from and pass to the callback
            ));
            $this->_logger->log('[iDEAL] INIT iDEAL payment process - open dialog screen');
        } catch (Exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
        return $response;
    }

    /**
     * function to display the paypal form
     * */
    public function deposit_form($amount) {
        $this->_logger->log('[iDEAL] prepare iDEAL form');
        do_action('wpds_fetch_ideal_deposit_form');
        $oIssuerRequest = new IssuerRequest();

        // Opvragen van order informatie.
        $sOrderId = 'DP_' . time(); // Uniek order ID
        $sOrderDescription = 'Order omschrijving'; // Omschrijving
        $fOrderAmount = $amount; // Bedrag (in decimaal!!)
        // Vraag de lijst met banken op
        $sIssuerOptions = '';
        $aIssuerList = $oIssuerRequest->doRequest();

        // Is er een fout opgetreden?
        if ($oIssuerRequest->hasErrors()) {
            // Je kunt $oIssuerRequest->getErrors() gebruiken om de lijst met opgetreden fouten op te vragen.
            $this->_logger->log('[iDEAL] request issue', 'error');
            print_r($oIssuerRequest->getErrors());
            exit;
        } else {
            foreach ($aIssuerList as $k => $v) {
                $sIssuerOptions .= '<option value="' . $k . '">' . htmlentities($v) . '</option>';
            }
        }
        $amount = number_format($fOrderAmount, 2, '.', '');
        $message = 'Deposit ' . $amount . ' on user account.';
        $form = '';
        if (WPD_CURRENCY != '€') {
            $form .= '<div class="error">You did not select € as currency. iDeal only accepts transactions in €.</div>';
        }
        $form .= '<form action="" method="post">
			<input type="hidden" name="order_id" id="order_id" size="30" value="' . $sOrderId . '" />
			<input type="hidden" name="order_description" id="order_description" value="' . $message . '" />
			<p><label for="order_issuer"><strong>Order ID:</strong></label> ' . $sOrderId . '</p>
			<p><label for="order_issuer"><strong>Order description:</strong></label> ' . $message . '</p>
			<p><label for="order_issuer"><strong>Order amount:</strong></label> <input name="order_amount" id="order_amount" size="30" type="text" value="' . $amount . '" /> 
			<br />
			<small>(iDeal transactions are in € only)</small></p>
			<p>
				<label for="order_issuer"><strong>Choose your bank:</strong></label>
				<select name="order_issuer" id="order_issuer">' . $sIssuerOptions . '</select>
			</p>
		</form>';
        return apply_filters('wpds_ideal_deposit_form', $form);
    }

    /**
     * function to request transaction to iDeal
     * */
    public function transactionRequest() {
        do_action('wpds_ideal_transaction_request');
        $wpelements = new WP_elements();
        // Opvragen van order informatie uit POST data.
        $sOrderId = $_POST['order_id']; // Unieke verwijzing naar de order
        $sOrderDescription = substr($_POST['order_description'], 0, 32); // Maximaal 32 karakters
        $fOrderAmount = $_POST['order_amount']; // Bedrag in EURO'S (2 decimalen)!
        $sIssuerId = $_POST['order_issuer']; // ID van de geselecteerde bank
        // Genereer een zelf op te geven EntranceCode (tot 40 karakters)
        $sEntranceCode = sha1($sOrderId . '_' . date('YmdHis'));
        $oTransactionRequest = new TransactionRequest();
        // Order settings
        $oTransactionRequest->setOrderId($sOrderId);
        $oTransactionRequest->setOrderDescription($sOrderDescription);
        $oTransactionRequest->setOrderAmount($fOrderAmount);

        $oTransactionRequest->setIssuerId($sIssuerId);
        $oTransactionRequest->setEntranceCode($sEntranceCode);
        $sCurrentUrl = strtolower(substr($_SERVER['SERVER_PROTOCOL'], 0, strpos($_SERVER['SERVER_PROTOCOL'], '/')) . '://' . $_SERVER['SERVER_NAME'] . '/') . substr($_SERVER['SCRIPT_NAME'], 1);
        $sReturnUrl = get_bloginfo('url') . '/wp-content/plugins/' . WPDEPOSIT_NAME . '/includes/ideal_transaction.php';
        $oTransactionRequest->setReturnUrl($sReturnUrl);
        $sTransactionId = $oTransactionRequest->doRequest();
        if ($oTransactionRequest->hasErrors()) {
            $this->_logger->log('[iDEAL] transaction request error', 'error');
            print_r($oTransactionRequest->getErrors());
            exit;
        } else {
            // Save order, TransactionID and EntranceCode in database (when required).
            self::storeTemporaryTransaction($sTransactionId, $fOrderAmount);
            $response = json_encode(array('success' => true, 'transaction_url' => $oTransactionRequest->doTransaction()));
            $wpelements->jsonResponseOutput($response);
        }
    }

    public function storeTemporaryTransaction($orderId, $amount) {
        $deposit = new DepositOptionsController();
        $params = array(
            'userid' => $this->_user->ID,
            'txn_id' => $orderId,
            'amount' => $amount,
            'payermail' => $this->_user->user_email,
            'payment_status' => 'pending',
            'status' => 1,
        );
        if (!$deposit->processPayment($params)) {
            $this->_logger->log('[iDEAL] could not add the temporary payment into the database', 'error');
        }
    }

    /**
     * function to process payment
     * */
    public function processPayment() {
        $this->_logger->log('[iDeal] Start process payment');
        $deposit = new DepositOptionsController();
        // Zoek het TransactieID en EntranceCode op in $_GET
        $sTransactionId = $_GET['trxid'];
        $sEntranceCode = $_GET['ec'];

        // Controlleer of de TransactieID/EntranceCode combinatie bestaat in de database, en zoek de bijbehorende order informatie op
        if ($deposit->checkPayment($sTransactionId)) { // Transactie bestaat/geldig
            $transDetails = $deposit->getDepositDetail($sTransactionId);
            $oStatusRequest = new StatusRequest();
            $oStatusRequest->setTransactionId($sTransactionId);
            // Vraag de status van de transactie op (SUCCESS, CANCELLED, FAILURE, OPEN, EXPIRED)
            $sStatus = $oStatusRequest->doRequest();

            if ($oStatusRequest->hasErrors()) {
                $this->_logger->log('[iDeal] status request error', 'error');
                print_r($oStatusRequest->getErrors());
                exit;
            } else {
                $params = array(
                    'userid' => $this->_user->ID,
                    'unique_code' => $sTransactionId,
                    'amount' => $transDetails->amount,
                );
                if (strcasecmp($sStatus, 'SUCCESS') === 0) {
                    // Update betaal status (bijv. in de database).
                    #todo validate first!

                    if ($deposit->completePayment($params)) {
                        do_action('wpds_process_ideal_payment');
                        //#todo verstuur mail
                        return 'success';
                        $this->_logger->log('[iDeal] payment completed');
                    } else {
                        $this->_logger->log('[iDeal] error completing the payment', 'error');
                        return 'failure';
                    }
                } elseif (strcasecmp($sStatus, 'CANCELLED') === 0) {
                    $this->_logger->log('[iDeal] payment cancelled');
                    do_action('wpds_process_ideal_payment_cancelled');
                    $deposit->cancelPayment($params);
                    return 'cancel';
                } elseif (strcasecmp($sStatus, 'FAILURE') === 0) {
                    $this->_logger->log('[iDeal] payment failure');
                    do_action('wpds_process_ideal_payment_failure');
                    $deposit->cancelPayment($params);
                    return 'failure';
                } elseif (strcasecmp($sStatus, 'EXPIRED') === 0) {
                    $this->_logger->log('[iDeal] payment expired');
                    do_action('wpds_process_ideal_payment_expired');
                    $deposit->cancelPayment($params);
                    return 'failure';
                } elseif (strcasecmp($sStatus, 'OPEN') === 0) {
                    $this->_logger->log('[iDeal] payment open');
                    do_action('wpds_process_ideal_payment_open');
                    return 'open';
                }
            }
        } else {
            $deposit->depositFailedMail();
        }
    }

}//end of class


/**
 * Add the gateway to WPdeposit
 * @param array $methods
 * @return string 
 */
function add_ideal_gateway( $gateway ) {
	$gateway[] = 'WPD_Ideal_Gateway';
	return $gateway;
}

add_filter('wpdeposit_payment_gateways', 'add_ideal_gateway' );