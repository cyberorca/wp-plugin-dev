<?php 
include_once  WPDEPOSIT_PATH . '/controllers/settings_options.php';
include_once  WPDEPOSIT_PATH . '/controllers/deposit_options.php';

/**
 * PayPal Payment Gateway
 *
 * Adds PayPal to WPdeposit list of available gateways.
 *
 * @class 		WPD_Paypal_Gateway
 * @extends		WPD_Payment_Gateway
 * @version		1.0.0
 */
class WPD_Paypal_Gateway extends wpdepositAbstractController  {
    
    /**
     * 
     * @var string 
     */
    public $_gatewayName = 'paypal';
    
    /**
     *
     * @var string 
     */
    public $_icon;
    
    /**
     *
     * @var boolean 
     */
    public $_testmode = false;

    /**
     * construct function
     */
    public function __construct() {
        if (get_option(WPDEPOSIT_NAME . '_test_mode') == 1) {
            $this->_testmode = true;
        }
        
        parent::__construct();
    }
    
    /**
     * Function to return the PG icon
     * @return string
     */
    public function getIcon(){
        $this->_icon = WPDEPOSIT_URL . '/resources/images/paypal.png';
        return $this->_icon;
    }
    
    /**
     * Function to return the PG Name
     * @return string
     */
    public function getGatewayName(){
        return $this->_gatewayName;
    }

    /**
     * Function to determine if payment is in test mode or not
     * @return string
     */
    public function payment_action()
    {
        if($this->_testmode):
            return "https://www.sandbox.paypal.com/cgi-bin/webscr";
        else:
            return "https://www.paypal.com/cgi-bin/webscr";
        endif;
    }
    
    public function getFormFields()
    {
        $formFields = array(
            'title' => 'Paypal Options',
            'fields' => array(
                //email field
                array(
                    'type' => 'textfield', 
                    'name' => 'paypal_email', //also used for the id
                    'label' => __('Paypal email', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),//end of array paypal email field
            )//end of array fields
        );//end of main array
        
        return apply_filters('wpds_paypal_form_fields', $formFields);
    }
    
    
    public function initPaymentProcess($amount)
    {
        do_action('wpds_paypal_payment_process_init');
        try {
            $response = json_encode(array('success' => true,
                'message' => __('Forwarding you to Paypal', WPDEPOSIT_NAME),
                'processtype' => 'form',
                'form' => self::deposit_form($amount)
            ));
            $this->_logger->log('[PAYPAL] INIT paypal payment process - Forwarding to gateway');
        } catch (Exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
        return $response;
    }


    /**
     * Function to return the paypal form
     * @param int/float $amount
     * @return string 
     */
    public function deposit_form($amount)
    {
        $this->_logger->log('[PAYPAL] prepare gateway form');
        do_action('wpds_fetch_paypal_deposit_form');
        $paypalemail = get_option(WPDEPOSIT_NAME . '_paypal_email');
        if (empty($paypalemail)) {
                return false;
        }
        $success_page = get_page( get_option(WPDEPOSIT_NAME . '_success_page') );
        $cancel_page = get_page( get_option(WPDEPOSIT_NAME . '_cancel_page') );
        $ipn_page = get_bloginfo('url') . '/wp-content/plugins/' . WPDEPOSIT_NAME . '/includes/paypal_ipn.php';
        $form ='
        <form name="depositform" id="depositform" method="post" action="' . self::payment_action() . '">
                <input type="hidden" name="rm" value="2"/>
                <input type="hidden" name="cmd" value="_xclick"/>
                <input type="hidden" name="business" value="' . $paypalemail . '"/>
                <input type="hidden" name="item_name" value="Deposit cash"/>
                <input type="hidden" name="no_shipping" value="1"/>
                <input type="hidden" name="currency_code" value="' . WPD_CURRENCY_CODE . '">
                <input type="hidden" name="return" value="' . get_bloginfo('url') . '/' . $success_page->post_name . '"/>
                <input type="hidden" name="notify_url" value="' . $ipn_page . '"/>
                <input type="hidden" name="cancel_return" value="' . get_bloginfo('url') . '/' . $cancel_page->post_name . '"/>
                <input type="hidden" name="custom" value="' . $this->_user->ID . '" />
                <input type="hidden" name="amount" value="' . $amount . '" />
        </form>
        ';
        return apply_filters('wpds_paypal_deposit_form', $form);
    }
    

    /**
     * Function to process payment
     **/
    public function processPayment()
    {
        $this->_logger->log('[PAYPAL] Start process payment');
        $deposit = new DepositOptionsController();
        $req = 'cmd=_notify-validate';
        $message = 'Post values:' . "\n";
        foreach ($_POST as $key => $value)
        {
            $message .= '\t\tkey = ' . $key . ' - value ' . $value . "\n";
            // If magic quotes is enabled strip slashes
            if (get_magic_quotes_gpc())
            {
                $_POST[$key] = stripslashes($value);
                $value = stripslashes($value);
            }
            $value = urlencode($value);
            // Add the value to the request parameter
            $req .= "&$key=$value";
        }
        //send email
        $this->_logger->log('[PAYPAL] request $_POST: ' . $req);
        if ($ch = curl_init()) {
            curl_setopt($ch, CURLOPT_URL, self::payment_action());
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            $result = curl_exec($ch);
            curl_close($ch);
        } else {
            $this->_logger->log('[PAYPAL] Curl error: ' .  curl_error($ch), 'error');
        }
        
        if (strcmp ($result, "VERIFIED") == 0)
        {
            $this->_logger->log('[PAYPAL] Payment Verified');
            $message .= 'Payment verified.' . "\n";
            if(!$deposit->checkPayment($_POST['ipn_track_id']))//@todo validate first!
            {
                //@todo validate first!
                $params = array(
                    'userid'	=> $_POST['custom'],
                    'txn_id'	=> $_POST['ipn_track_id'],
                    'amount'	=> $_POST['mc_gross'],
                    'payermail'     => $_POST['payer_email'],
                    'status'        => 1,
                );
                $success = $deposit->processPayment($params);
                if ($success) {
                    $this->_logger->log('[PAYPAL] payment processed successfully');
                    do_action('wpds_process_paypal_payment');
                    $message .= 'payment processed successfully' . "\n";
                } else {
                    $this->_logger->log('[PAYPAL] payment processed failed', 'error');
                    $message .= 'payment processed failed' . "\n";
                }
            } else {
                $this->_logger->log('[PAYPAL] deposit failed, taxid already exists', 'error');
                $message .= 'deposit failed, taxid already exists' . "\n";
                $deposit->depositFailedMail();
            }
        } elseif (strcmp ($result, "INVALID") == 0) {
            $this->_logger->log('[PAYPAL] Payment invalid', 'error');
            $message .= 'ERROR - INVALID ' . $result ."\n";
            do_action('wpds_paypal_payment_invalid');
            $deposit->depositFailedMail();
        }else {
            $this->_logger->log('[PAYPAL] Payment not Verified ', 'error');
            $message .= 'ERROR - NOT VERIFIED ' . $result ."\n";
            do_action('wpds_paypal_payment_not_verified');
        }
    }
	
}//end of class

/**
 * Add the gateway to WPdeposit
 * @param array $gateway
 * @return string 
 */
function wpd_add_paypal_gateway( $gateway ) {
	$gateway[] = 'WPD_Paypal_Gateway';
	return $gateway;
}

add_filter('wpdeposit_payment_gateways', 'wpd_add_paypal_gateway' );