<?php 
/**
 * example Payment Gateway
 *
 * Adds example to WPdeposit list of available gateways.
 *
 * @class 		WPD_example_Gateway
 * @extends		WPD_Payment_Gateway
 * @version		1.0.0
 */
class WPD_example_Gateway extends WPD_Payment_Gateway {
    
    /**
     * 
     * @var string 
     */
    public $_gatewayName = 'example';
    
    /**
     *
     * @var string 
     */
    public $_icon;
    
    /**
     *
     * @var boolean 
     */
    public $_testmode = false;
    
    /**
     * construct function
     */
    public function __construct() {
        if (get_option(WPDEPOSIT_NAME . '_test_mode') == 1) {
            $this->_testmode = true;
        }
        parent::__construct();
    }
    
    /**
     * Function to return the PG icon
     * @return string
     */
    public function getIcon(){
        $this->_icon = WPDEPOSIT_URL . '/resources/images/example.png';
        return $this->_icon;
    }
    
    /**
     * Function to return the PG Name
     * @return string
     */
    public function getGatewayName(){
        return $this->_gatewayName;
    }

    /**
     * Function to determine if payment is in test mode or not
     * @return string
     */
    public function payment_action()
    {
        if($this->_testmode):
            return "https://www.sandbox.example.com";
        else:
            return "https://www.example.com/cgi-bin";
        endif;
    }
    
    public function getFormFields()
    {
        return array(
            'title' => 'example Options',
            'fields' => array(
                
                array(
                    'type' => 'textfield', 
                    'name' => 'test_field', //also used for the id
                    'label' => 'Test field', 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),//end of text field
                
                array(
                    'type' => 'checkbox', 
                    'name' => 'text_checkbox1', //also used for the id
                    'label' => 'Checkbox test 1', 
                    'extra_options' => array('size' => 50, 'class' => 'checkbox_field') //extra option for in the field
                ),//end of checkbox field
                
                array(
                    'type' => 'checkbox', 
                    'name' => 'text_checkbox2', //also used for the id
                    'label' => 'Checkbox test 2',
                    'extra_options' => array('size' => 50, 'class' => 'checkbox_field') //extra option for in the field
                ),//end of checkbox field
                
                array(
                    'type' => 'uploadfile', 
                    'name' => 'ideal_private_key_file', //also used for the id
                    'label' => __('Thumbnail image', WPDEPOSIT_NAME),
                    'btn_name' => __('Upload file', WPDEPOSIT_NAME),
                    'extention' => '*.jpg', //seperate each extention with a comma 
                    'uploadpath' => WPDEPOSIT_PATH . '/classes/ideal/ssl/', //add trailing slash at the end!
                    'extra_options' => array('size' => 30, 'class' => 'upload_field') //extra option for in the field, the class is required
                ),//end of upload field
                
                array(
                    'type' => 'radio', 
                    'name' => 'test_radio',
                    'radio_options' => array(
                        array(
                            'label' => 'Radio 1', 
                            'value' => 'radio1',
                            'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                        ),//end of radio1 radio field
                        array(
                            'label' => 'Radio 2', 
                            'value' => 'radio2',
                            'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                        ),//end of radio1 radio field
                    ),//end of array radio_options
                ),//end of array radio option group
                
                //field under regular title
                array(
                    'type' => 'textarea', 
                    'name' => 'textarea_test_field', //also used for the id
                    'label' => __('Textarea field', WPDEPOSIT_NAME), 
                    'extra_options' => array('cols' => 80, 'rows' => 10, 'class' => 'textarea_field') //extra option for in the field
                ),//end of array example email field
                
                //email field
                array(
                    'type' => 'title', 
                    'text' => __('Extra settings', WPDEPOSIT_NAME), 
                    'headingtype' => 'h2',
                    'extra_options' => array('class' => 'heading_title') //extra option for in the field
                ),
                //field under regular title
                array(
                    'type' => 'textfield', 
                    'name' => 'another_test_field', //also used for the id
                    'label' => __('Another test field', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),//end of array example email field
                
            )//end of array fields
        );//end of main array
    }

            
    public function initPaymentProcess($amount)
    {
        
    }

    /**
     * Function to process payment
     **/
    public function processPayment()
    {
        
    }
	
}//end of class

/**
 * Add the gateway to WPdeposit
 * @param array $gateway
 * @return string 
 */
function add_example_gateway( $gateway ) {
	$gateway[] = 'WPD_example_Gateway';
	return $gateway;
}

add_filter('wpdeposit_payment_gateways', 'add_example_gateway' );