<?php 
include_once  WPDEPOSIT_PATH . '/controllers/settings_options.php';
include_once  WPDEPOSIT_PATH . '/controllers/deposit_options.php';

class WPD_Authorize_Gateway extends WPD_Payment_Gateways {
	    
    public $_gatewayName = 'authorize';
    
    public $_icon;
    
    public function __construct() {
        parent::__construct();
    }
    
        
    public function getIcon(){
        $this->_icon = WPDEPOSIT_URL . '/resources/images/authorizenet.png';
        return $this->_icon;
    }
    
        
    public function getGatewayName(){
        return $this->_gatewayName;
    }
    
    /**
     * Function to determine if payment is in test mode or not
     **/
    public function payment_action()
    {
            if(get_option(WPDEPOSIT_NAME . '_test_mode') == 1):
                    return "https://test.authorize.net/gateway/transact.dll";
            else:
                    return "https://secure.authorize.net/gateway/transact.dll";
            endif;
    }
    
    public function getFormFields()
    {
        $formFields = array(
            'title' => 'Authorize Options',
            'fields' => array(
                array(
                    'type' => 'textfield', 
                    'name' => 'authorize_api_login', //also used for the id
                    'label' => __('api Login ID', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
                array(
                    'type' => 'textfield', 
                    'name' => 'transaction_key', //also used for the id
                    'label' => __('Transaction key', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
            )//end of array fields
        );//end of main array
        
        return apply_filters('wpds_authorize_form_fields', $formFields);
    }

            
    public function initPaymentProcess($amount)
    {
        do_action('wpds_authorize_payment_process_init');
        try {
            $response = json_encode(array('success' => true,
                'message' => __('Forwarding you to Authorize.net', WPDEPOSIT_NAME),
                'processtype' => 'form',
                'form' => self::deposit_form($amount)
            ));
            $this->_logger->log('[AUTHORIZE.NET] INIT authorize.net payment process - Forwarding to gateway');
        } catch (Exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
        return $response;
    }
    
    /**
     * function to display the authorize.net form
     **/
    public function deposit_form($amount)
    {
        $this->_logger->log('[AUTHORIZE.NET] prepare gateway form');
        do_action('wpds_fetch_authorize_deposit_form');
            $authorizeApiLoginID = get_option(WPDEPOSIT_NAME . '_authorize_api_login');
            $authorizeTransactionKey = get_option(WPDEPOSIT_NAME . '_transaction_key');
            //normally this won't be empty because an error will be thrown if the admin forget's to update the settings when selecting authorize.net payment gateway. But let's just check to be sure
            if (empty($authorizeApiLoginID)) {
                $this->_logger->log('[AUTHORIZE.NET] Unable to process the payment. API login ID not set', 'error');
                throw new exception('Unable to process the payment. API login ID not set');
            }
            if (empty($authorizeTransactionKey)) {
                $this->_logger->log('[AUTHORIZE.NET] Unable to process the payment.  Transaction Key not set', 'error');
                throw new exception('Unable to process the payment. Transaction Key not set');
            }
            require_once WPDEPOSIT_PATH . '/lib/anet_php_sdk/AuthorizeNet.php'; // The SDK
            $fp_timestamp = time();
            $fp_sequence = "order_" . time(); // Enter an invoice or other unique number.
            $fingerprint = AuthorizeNetSIM_Form::getFingerprint($authorizeApiLoginID, $authorizeTransactionKey, $amount, $fp_sequence, $fp_timestamp);
            $testMode = (get_option(WPDEPOSIT_NAME . '_test_mode') == 1)? 'true' : 'false';
            $form ='
            <form name="depositform" id="depositform" method="post" action="' . self::payment_action() . '">
                <input type="hidden" name="x_login" value="' . $authorizeApiLoginID . '" />
                <input type="hidden" name="x_fp_hash" value="' . $fingerprint . '" />
                <input type="hidden" name="x_amount" value="' . $amount . '" />
                <input type="hidden" name="x_fp_timestamp" value="' . $fp_timestamp . '" />
                <input type="hidden" name="x_fp_sequence" value="' . $fp_sequence . '" />
                <input type="hidden" name="x_version" value="3.1">
                <input type="hidden" name="x_show_form" value="payment_form">
                <input type="hidden" name="x_test_request" value="' . $testMode . '" />
                <input type="hidden" name="x_method" value="cc">
                <input type="hidden" name="x_userid" value="' . $this->_user->ID . '" />
                <input type="hidden" name="x_relay_response" value="TRUE" />
                <input type="hidden" name="x_relay_url" value="' . get_bloginfo('url') . '/wp-content/plugins/' . WPDEPOSIT_NAME . '/includes/authorize_callback.php" />
            </form>
            ';
            return apply_filters('wpds_authorize_deposit_form', $form);
    }

    /**
     * function to process payment
     *
     * @return void
     * @author Christophe Debruel
     **/
    public function processPayment()
    {
        $this->_logger->log('[AUTHORIZE.NET] Start process payment');
        $deposit = new DepositOptionsController();
        if($_POST['x_response_code'] == 1)
        {
            if(!$deposit->checkPayment($_POST['x_trans_id']))#todo validate first!
            {
                #todo validate first!
                $params = array(
                'userid'	=> $_POST['x_userid'],
                'txn_id'	=> $_POST['x_trans_id'],
                'amount'	=> $_POST['x_amount'],
                'payermail' => $_POST['x_email'],
                'status'        => 1,
                );
                if($deposit->processPayment($params)){
                    $this->_logger->log('[AUTHORIZE.NET] payment process completed');
                    do_action('wpds_process_authorize_payment');
                    return true;
                } else {
                    $this->_logger->log('[AUTHORIZE.NET] could not complete the payment. ');
                    return false;
                }
            } else {
                do_action('wpds_process_authorize_failed');
                $deposit->depositFailedMail();
            }
        } else {
            do_action('wpds_process_authorize_failed');
            $deposit->depositFailedMail();
        }
    }
	
}//end of class


/**
 * Add the gateway to WPdeposit
 * @param array $methods
 * @return string 
 */
function add_authorize_gateway( $gateway ) {
	$gateway[] = 'WPD_Authorize_Gateway';
	return $gateway;
}

add_filter('wpdeposit_payment_gateways', 'add_authorize_gateway' );