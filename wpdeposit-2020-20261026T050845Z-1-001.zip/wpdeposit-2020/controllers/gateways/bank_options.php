<?php

include_once WPDEPOSIT_PATH . '/controllers/settings_options.php';
include_once WPDEPOSIT_PATH . '/controllers/deposit_options.php';

class WPD_Bank_Gateway extends WPD_Payment_Gateways {
    
    public $_gatewayName = 'bank';
    
    public $_icon;
    
    public function __construct() {
        parent::__construct();
    }
    
        
    public function getIcon(){
        $this->_icon = WPDEPOSIT_URL . '/resources/images/bank.png';
        return $this->_icon;
    }
    
        
    public function getGatewayName(){
        return $this->_gatewayName;
    }
    
    
    public function getFormFields()
    {
        $formFields = array(
            'title' => 'Bank Options',
            'fields' => array(
                array(
                    'type' => 'textfield', 
                    'name' => 'bank_iban', //also used for the id
                    'label' => __('IBAN', WPDEPOSIT_NAME), 
                    'extra_options' => array('size' => 50, 'class' => 'input_field') //extra option for in the field
                ),
            )//end of array fields
        );//end of main array
        
        return apply_filters('wpds_bank_form_fields', $formFields);
    }
    
            
    public function initPaymentProcess($amount)
    {
        do_action('wpds_bank_payment_process_init');
        try {
            $params = self::processPayment($amount);
            $response = json_encode(array('success' => true,
                'message' => __('Generating a pdf invoice for your deposit', WPDEPOSIT_NAME),
                'processtype' => 'redirecturl',
                'redirecturl' => WPDEPOSIT_URL . '/includes/generate_invoice.php?tid=' . $params['txn_id']
            ));
            $this->_logger->log('[BANK] INIT bank payment process - forwarding to invoice');
        } catch (Exception $e) {
            $response = json_encode(array('success' => false, 'message' => $e->getMessage()));
        }
        return $response;
    }

    /**
     * function to process payment
     *
     * @return void
     * */
    public function processPayment($amount) {
        $this->_logger->log('[BANK] process payment');
        $deposit = new DepositOptionsController();
        $wpelements = new WP_elements();
        $transactionId = 'DP_' . rand(0000, 9999) . time();

        $params = array(
            'userid' => $this->_user->ID,
            'txn_id' => $transactionId,
            'status' => 0,
            'amount' => $amount,
        );
        if (!$deposit->processPayment($params)) {
            throw new Exception(__('Could not process the payment. Contact the Administrator if you keep getting this message', WPDEPOSIT_NAME));
        }
        do_action('wpds_process_pending_bank_payment');
        $response = json_encode(array('success' => true, 'transaction_id' => $transactionId));
        $to = get_bloginfo('admin_email');
        $subject = get_bloginfo('name').' - ' . __('WPdeposit notice: New deposit via BANK option added', WPDEPOSIT_NAME);
        wp_mail($to, $subject, __('A user has deposited via the BANK option, please complete the transaction in the admin of your wordpress installation (WPdeposit -> Deposits).', WPDEPOSIT_NAME)); 
        return $params;
    }

}

//end of class


/**
 * Add the gateway to WPdeposit
 * @param array $methods
 * @return string 
 */
function add_bank_gateway( $gateway ) {
	$gateway[] = 'WPD_Bank_Gateway';
	return $gateway;
}

add_filter('wpdeposit_payment_gateways', 'add_bank_gateway' );