<?php

if(class_exists('WC_Payment_Gateway')){
    class WC_WPDEPOSIT extends WC_Payment_Gateway {

        public function __construct() {
            $this->id			= 'WPdeposit';
            $this->icon 			= apply_filters('woocommerce_bacs_icon', '');
            $this->has_fields 		= false;
            $this->method_title     = __( 'WPDeposit', 'woocommerce' );
            // Load the form fields.
            $this->init_form_fields();

            // Load the settings.
            $this->init_settings();

            // Define user set variables
            $this->title 			= $this->settings['title'] . ' <small>(Balance: ' . the_credit_type_text(false, null, true) . ')</small>';
            //$this->currency_match	= $this->settings['currency_match'];

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options'));
            //add_action('woocommerce_thankyou_ppay_' . $this->id, array( $this, 'thankyou_page'));

        }

        /**
         * Initialise Gateway Settings Form Fields
         */
        function init_form_fields() {
            $WCCurrentCurrency = get_woocommerce_currency();

            if (WPD_CREDIT_TYPE == 'points') {
                $currencyMessage = 'You have the WPDeposit points system enabled, in WooCommerce, 1 '.$WCCurrentCurrency.' will be 1 point.' ;
            } else {
                $currencyMessage = (WPD_CURRENCY_CODE != $WCCurrentCurrency)? '<span style="color:red;">The WPdeposit and Woocommerce current currency do not match. Please update to match currencies.</span>' : '<span style="color:green;">WPdeposit and Woocommerce selected currencies matches.</span>' ;
            }

            $this->form_fields = array(
                'enabled' => array(
                    'title' => __( 'Enable/Disable', 'woocommerce' ),
                    'type' => 'checkbox',
                    'label' => __( 'Enable WPdeposit', 'woocommerce' ),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __( 'Title', 'woocommerce' ),
                    'type' => 'text',
                    'description' => __( 'Define the title of the payment system.', 'woocommerce' ),
                    'default' => __( 'WPdeposit', 'woocommerce' )
                ),
                'currency_match' => array(
                    'title' => __( 'Currency match', 'woocommerce' ),
                    'type' => 'title',
                    'description' => $currencyMessage,
                    'default' => $currencyMessage
                ),
            );

        } // End init_form_fields()

        /**
         * Admin Panel Options
         * - Options for bits like 'title' and availability on a country-by-country basis
         *
         * @since 1.0.0
         */
        public function admin_options() {
            ?>
            <h3><?php _e('WPdeposit', 'woocommerce'); ?></h3>
            <p><?php _e('Allows your user to deduct points/money they have deposited on your account using the WPDeposit plugin', 'woocommerce'); ?></p>
            <table class="form-table">
                <?php
                // Generate the HTML For the settings form.
                $this->generate_settings_html();
                ?>
            </table><!--/.form-table-->
        <?php
        } // End admin_options()


        /**
         * There are no payment fields for bacs, but we want to show the description if set.
         **/
        function payment_fields() {
            if ($this->description) echo wpautop(wptexturize($this->description));
        }

        function thankyou_page() {
            if ($this->description) echo wpautop(wptexturize($this->description));

            ?><h2><?php _e('Our Details', 'woocommerce') ?></h2><ul class="order_details ppay_details"><?php

            $fields = array(
                'ppay_number'=> __('Numero WPdeposit', 'woocommerce')
            );

            foreach ($fields as $key=>$value) :
                if(!empty($this->$key)) :
                    echo '<li class="'.$key.'">'.$value.': <strong>'.wptexturize($this->$key).'</strong></li>';
                endif;
            endforeach;

            ?></ul><?php
        }

        /**
         * Process the payment and return the result
         **/
        function process_payment( $order_id ) {
            global $woocommerce;
            $userModel = $userModel = new UserModel(UserModel::getCurrentUser()->ID);
            $order = new WC_Order( $order_id );
            if ($userModel->getBalance() <  $order->order_total) {
	            wc_add_notice(__('Payment error:', 'woothemes') . ' You do not have enough balance to checkout your cart. Deposit more money on your account.', 'error');
                return false;
            }
            if (!$userModel->decrementBalance($order->order_total)) {
	            wc_add_notice(__('Payment error:', 'woothemes') . ' Something went wrong when deducting the total price order from your deposits. Contact the site administrator if this persist.', 'error');
                return false;
            }
				// Log transaction
				require_once WPDEPOSIT_PATH .'/models/transaction.php';
				$transactionModel = new TransactionModel();
				$transactionModel->logTransaction($userModel->getId(), $order_id, $order->order_total*-1, 'woocommerce', 'Bought a product');

				// Reduce stock levels
				//$order->reduce_order_stock();

				// Remove cart
				$woocommerce->cart->empty_cart();

				//if all is ok we can update the status
				$order->update_status('completed');

				// Return thankyou redirect
				/*return array(
					'result' 	=> 'success',
					'redirect'	=> add_query_arg('key', $order->order_key, add_query_arg('order', $order->id, get_permalink(woocommerce_get_page_id('thanks'))))
				);*/
		        return array(
			        'result'   => 'success',
			        'redirect' => $this->get_return_url( $order )
		        );
        }

    }
}
