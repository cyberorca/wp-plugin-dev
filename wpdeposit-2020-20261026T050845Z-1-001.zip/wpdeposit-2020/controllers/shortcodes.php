<?php

class WPdepositShortcodes extends wpdepositAbstractController {

	public function __construct()
	{
		//add shortcodes
		add_shortcode(WPDEPOSIT_NAME . '_payment_interface', array($this, 'show_payment_interface'));
		add_shortcode(WPDEPOSIT_NAME . '_deposit_history', array($this, 'show_deposit_history'));
		add_shortcode(WPDEPOSIT_NAME . '_transactions', array($this, 'show_transactions'));
		add_shortcode(WPDEPOSIT_NAME . '_request_withdrawal', array($this, 'request_withdrawal_interface'));
		add_shortcode(WPDEPOSIT_NAME . '_withdrawals', array($this, 'show_withdrawals'));
		add_shortcode(WPDEPOSIT_NAME . '_deposit_balance', array($this, 'show_deposit_balance'));
		add_shortcode(WPDEPOSIT_NAME . '_donate_to_user', array($this, 'donate_to_user_interface'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_bpjskes', array($this, 'form_pilih_bpjskes'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_paybpjs', array($this, 'form_pilih_paybpjs'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqpdam', array($this, 'form_pilih_inqpdam'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqpln', array($this, 'form_pilih_inqpln'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqtelkom', array($this, 'form_pilih_inqtelkom'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqpascabayar', array($this, 'form_pilih_inqpascabayar'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqtvbayar', array($this, 'form_pilih_inqtvbayar'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_paypdam_pln_telkom', array($this, 'form_pilih_payment'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_pulsa', array($this, 'form_pilih_pulsa'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_zakat', array($this, 'form_pilih_zakat'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_transaksi', array($this, 'form_pilih_transaksi'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_transaksidata', array($this, 'form_pilih_transaksidata'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqtelkomselbebas', array($this, 'form_pilih_inqtelkomselbebas'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_payment', array($this, 'form_pilih_payment'));
        add_shortcode(WPDEPOSIT_NAME . '_pilih_halotelkomsel', array($this, 'form_pilih_halotelkomsel'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_gameonline', array($this, 'form_pilih_gameonline'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_leasingsiapbayar', array($this, 'form_pilih_leasingsiapbayar'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_paymentpelen', array($this, 'form_pilih_paymentpelen'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_paymentbebasadmin', array($this, 'form_pilih_paymentbebasadmin'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqpdamkedua', array($this, 'form_pilih_inqpdamkedua'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqpdamketiga', array($this, 'form_pilih_inqpdamketiga'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqplnkedua', array($this, 'form_pilih_inqplnkedua'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqplnketiga', array($this, 'form_pilih_inqplnketiga'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqtelkomkedua', array($this, 'form_pilih_inqtelkomkedua'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqtvbayarkedua', array($this, 'form_pilih_inqtvbayarkedua'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inqplnempat', array($this, 'form_pilih_inqplnempat'));
        add_shortcode(WPDEPOSIT_NAME . '_pilih_paymentplnempat', array($this, 'form_pilih_paymentplnempat'));
        /*Jadi satu dengan api rajabiller*/	    
	    add_shortcode(WPDEPOSIT_NAME . '_pilih_siapbayar_inquiry', array($this, 'form_pilih_siapbayar_inquiry'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_siapbayar_payment', array($this, 'form_pilih_siapbayar_payment'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_pulsa5ribu', array($this, 'form_pilih_pulsa5ribu'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_pulsa10ribu', array($this, 'form_pilih_pulsa10ribu'));

// 		add_shortcode(WPDEPOSIT_NAME . '_pilih_siapbayar_inq', array($this, 'form_pilih_siapbayar_inq'));
		add_shortcode(WPDEPOSIT_NAME . '_pilih_bpjsTK', array($this, 'form_pilih_bpjsTK'));
        add_shortcode(WPDEPOSIT_NAME . '_pilih_paketdata', array($this, 'form_pilih_paketdata'));	
		add_shortcode(WPDEPOSIT_NAME . '_pilih_shopee', array($this, 'form_pilih_shopee'));
		
		add_shortcode(WPDEPOSIT_NAME . '_pilih_inquiry_pln_pra_pasca', array($this, 'show_inquiry_pln'));
		
	}
	
	
	/**
	 * function to register a shortcode to show the payment interface
	 *
	 * @return void
	 * */
	public function show_inquiry_pln()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiry_pln();
	}
	
	/**
	 * function to register a shortcode to show the payment interface
	 *
	 * @return void
	 * */
	public function show_payment_interface($atts = '', $content = '')
	{
		$obj = new PaymentOptionsController();
		$obj->depositMoneyInterface();
	}

	/**
	 * function to register a shortcode to show the deposit history
	 *
	 * @return void
	 * */
	public function show_deposit_history($atts = '', $content = '')
	{
		$obj = new PaymentOptionsController();
		return $obj->depositHistory();
	}

	/**
	 * @return void
	 * */
	public function show_transactions($atts = '', $content = '')
	{
		$obj = new TransactionController();
		$obj->overview();
	}

	/**
	 * @return void
	 * */
	public function show_withdrawals($atts = '', $content = '')
	{
		$obj = new WithdrawalController();
		$obj->overview();
	}

	/**
	 * function to register a shortcode to show the deposit balance
	 *
	 * @return void
	 * */
	public function show_deposit_balance($atts = '', $content = '')
	{
		$obj = new userController();
		$obj->display_deposit_balance();
	}

	/**
	 * function to register a shortcode to show the 'donate to user' page
	 *
	 * @return void
	 * */
	public function donate_to_user_interface($atts = '', $content = '')
	{
		$obj = new DepositOptionsController();
		return $obj->donate_to_user_interface();
	}

	/**
	 * function to register a shortcode to show the 'donate to user' page
	 *
	 * @return void
	 * */
	public function request_withdrawal_interface($atts = '', $content = '')
	{
		$obj = new WithdrawalController();
		return $obj->request_transaction_interface();
	}
	
	/**
	 * function to register a shortcode to show the 'BPSJ Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_bpjskes()
	{
		$obj = new ApiRajabillerController();
		return $obj->rajabiller_api_bpjskes();
	}
	
	/**
	 * function to register a shortcode to show the 'BPJS Payment' page
	 *
	 * @return void
	 * */
	public function form_pilih_paybpjs()
	{
		$obj = new ApiRajabillerController();
		return $obj->rajabiller_api_paybpjs();
	}
	
	/**
	 * function to register a shortcode to show the 'BPSJ Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_paketdata()
	{
		$obj = new ApiRajabillerController();
		return $obj->rajabiller_api_paketdata();
	}
	
	/**
	 * function to register a shortcode to show the 'BPSJ Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_shopee()
	{
		$obj = new ApiRajabillerController();
		return $obj->rajabiller_api_shopee();
	}
	
	
/**
	 * function to register a shortcode to show the 'BPSJ Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_bpjsTK()
	{
		$obj = new ApiRajabillerController();
		return $obj->rajabiller_api_bpjsTK();
	}
	
	
	
	
	/**
	 * function to register a shortcode to show the 'PDAM Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqpdam()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquirypdam();
	}
	
		/**
	 * function to register a shortcode to show the 'PDAM Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqpdamkedua()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquirypdamkedua();
	}
	
	
	
		/**
	 * function to register a shortcode to show the 'PDAM Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqpdamketiga()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquirypdamketiga();
	}
	/**
	 * function to register a shortcode to show the 'PDAM PLN TELKOM Payment' page
	 *
	 * @return void
	 * */
	public function form_pilih_payment()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_payment();
	}
	
	/**
	 * function to register a shortcode to show the 'PLN Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqpln()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryPLN();
	}
	
		/**
	 * function to register a shortcode to show the 'PLN Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqplnkedua()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryPLNkedua();
	}
	
		/**
	 * function to register a shortcode to show the 'PLN Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqplnketiga()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryPLNketiga();
	}





	/**
	 * function to register a shortcode to show the 'Telkom Inquiry' page
	 *
	 * @return void
	 * */
	 
	public function form_pilih_inqplnempat()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryplnempat();
	}


	/**
	 * function to register a shortcode to show the 'Telkom Inquiry' page
	 *
	 * @return void
	 * */
	 
	public function form_pilih_inqtelkom()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inqtelkom();
	}
		/**
	 * function to register a shortcode to show the 'Telkom Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqtelkomkedua()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inqtelkomkedua();
	}
	
	/**
	 * function to register a shortcode to show the 'Pascabayar Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqpascabayar()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryPascabayar();
	}
	
	/**
	 * function to register a shortcode to show the 'Pascabayar Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqtvbayar()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryTVbayar();
	}
	
		/**
	 * function to register a shortcode to show the 'Pascabayar Inquiry' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqtvbayarkedua()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inquiryTVbayarkedua();
	}
	
	/**
	 * function to register a shortcode to show the 'Pulsa' page
	 *
	 * @return void
	 * */
	public function form_pilih_pulsa()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_pulsa();
	}
	
	/**
	 * function to register a shortcode to show the 'Pulsa' page
	 *
	 * @return void
	 * */
	public function form_pilih_pulsa5ribu()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_pulsa5ribu();
	}
	
		/**
	 * function to register a shortcode to show the 'Pulsa' page
	 *
	 * @return void
	 * */
	public function form_pilih_pulsa10ribu()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_pulsa10ribu();
	}
	
	
	
	/**
	 * function to register a shortcode to show the 'Zakat' page
	 *
	 * @return void
	 * */
	public function form_pilih_zakat()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_zakat();
	}
	
	/**
	 * function to register a shortcode to show the 'Transaksi' page
	 *
	 * @return void
	 * */
	public function form_pilih_transaksi()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_transaksi();
	}
	/**
	 * function to register a shortcode to show the 'Transaksidata' page
	 *
	 * @return void
	 * */
	public function form_pilih_transaksidata()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_transaksidata();
	}
	/**
	 * function to register a shortcode to show the 'inqtelkomselbebas' page
	 *
	 * @return void
	 * */
	public function form_pilih_inqtelkomselbebas()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_inqtelkomselbebas();
	}

/**
	 * function to register a shortcode to show the 'paymentbebasadmin' page
	 *
	 * @return void
	 * */
	public function form_pilih_paymentbebasadmin()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_paymentbebasadmin();
	}
	
	/**
	 * function to register a shortcode to show the 'halotelkomsel' page
	 *
	 * @return void
	 * */
	public function form_pilih_halotelkomsel()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_halotelkomsel();
	}
	
	/**
	 * function to register a shortcode to show the 'pembayaransb' page
	 *
	 * @return void
	 * */
	public function form_pilih_gameonline()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_gameonline();
	}

/**
	 * function to register a shortcode to show the 'pembayaransb' page
	 *
	 * @return void
	 * */
	public function form_pilih_leasingsiapbayar()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_leasingsiapbayar();
	}
	
	public function form_pilih_paymentpelen()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_paymentpelen();
	}
	
	/**
	 * function to register a shortcode to show the 'siapbayar_inquiry' page
	 *
	 * @return void
	 * */
	 	public function form_pilih_paymentplnempat()
	{
		$obj = new ApiRajabillerController();
		$obj->rajabiller_api_paymentplnempat();
	}
	
	/**
	 * function to register a shortcode to show the 'siapbayar_inquiry' page
	 *
	 * @return void
	 * */
	 
	 
	 
	 
	public function form_pilih_siapbayar_inquiry(){
         $obj = new ApiRajabillerController();
	    $obj->api_siapbayar_inq();
	}
	
	/**
	 * function to register a shortcode to show the 'siapbayar_payment' page
	 *
	 * @return void
	 * */
	public function form_pilih_siapbayar_payment(){
	   $obj = new ApiRajabillerController();
	   return $obj->api_siapbayar_pay();
	}
	/**
	 * function to register a shortcode to show the 'siapbayarinq' page
	 *
	 * @return void
	 * */
	public function form_pilih_siapbayar_inq(){
	   //$obj = new ApiRajabillerController();
	   //$obj->siapbayar_api_payment();
	}
}