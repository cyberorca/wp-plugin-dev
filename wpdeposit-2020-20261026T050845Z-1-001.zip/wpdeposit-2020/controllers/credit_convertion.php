<?php
include_once(WPDEPOSIT_PATH . '/models/user.php');
include_once(WPDEPOSIT_PATH . '/models/credit_convertion.php');

class CreditConvertionController extends wpdepositAbstractController
{
    public $model;

    public function __construct() {
        $this->model = new CreditConvertionModel();
        parent::__construct();
    }

    public function backupBalance($balanceList) {
        $balanceList = json_encode($balanceList);
        $backupDir = WPDEPOSIT_PATH . '/backup/';
        if (!is_dir($backupDir)) {
            mkdir($backupDir);
        }
        $fp = fopen($backupDir . 'balance_backup_' . time() . '.txt', 'a');
        fwrite($fp, '/*------------------------[BACKUP ON ' . date('d M Y', time()) . ' ]------------------------*/' . "\n");
        fwrite($fp, $balanceList . "\n");
        fclose($fp);
    }

    public function getAllUserWithDeposit($type = null) {
        if($type == null) {
            $type = WPD_CREDIT_TYPE;
        }
        if ($type == 'money') {
            $users = get_users(array('meta_key' => WPDEPOSIT_NAME . '_user_amount'));
        } else {
            $users = get_users(array('meta_key' => WPDEPOSIT_NAME . '_user_points'));
        }
        return $users;
    }

    public function convert_points_to_credits() {
        $wpelements = new WP_elements();
        if(!isset($_POST['convertionRate'])){
            $response = array('success' => false, 'message' => 'No convertion rate provided. Convertion cancelled.');
            $wpelements->jsonResponseOutput($response);
        } else {
            $convertionRate = explode('/', $_POST['convertionRate']);
            $convertionPoints = $convertionRate[0];
            $convertionPrice = $convertionRate[1];
        }
        $userModel = new UserModel();
        $users = $this->getAllUserWithDeposit();
        $backupArray = array();
        foreach($users as $user) {
            $backupArray[] = array(
                'user_id' => $user->ID,
                'points' => $userModel->getBalance($user->ID)
            );
        }
        //backup balances should something happen
        $this->backupBalance($backupArray);
        foreach($backupArray as $userBalance) {
            if ($convertionPoints != $convertionPrice) {
                $convertedCredits = $userBalance['points'] / $convertionPoints;
                $convertedCredits = round($convertedCredits * $convertionPrice);
            } else {
                $convertedCredits = $userBalance['points'];
            }
            //move to credits
            update_user_meta($userModel->getId(), WPDEPOSIT_NAME.$userModel::USER_AMOUNT, $convertedCredits);
            //remove points
            update_user_meta($userModel->getId(), WPDEPOSIT_NAME.$userModel::USER_POINTS, 0);
            //echo '(points: ' . $userBalance['points'] . ' - to: ' . $convertedCredits . ')';
        }
        $response = array('success' => true, 'message' => 'Settings updated');
        $wpelements->jsonResponseOutput(json_encode($response));
    }

    public function convert_credits_to_points() {
        $wpelements = new WP_elements();
        if(!isset($_POST['convertionRate'])){
            $response = array('success' => false, 'message' => 'No convertion rate provided. Convertion cancelled.');
            $wpelements->jsonResponseOutput(json_encode($response));
        } else {
            $convertionRate = explode('/', $_POST['convertionRate']);
            $convertionPoints = $convertionRate[0];
            $convertionPrice = $convertionRate[1];
        }
        $userModel = new UserModel();
        $users = $this->getAllUserWithDeposit('money');

        $backupArray = array();
        foreach($users as $user) {
            //@todo split credits in next version instead of adding them together
            $totalBalance = $userModel->getRegularBalance($user->ID) + $userModel->getRewardBalance();
            $backupArray[] = array(
                'user_id' => $user->ID,
                'credits' => $totalBalance
            );
        }
        //backup balances should something happen
        $this->backupBalance($backupArray);
        foreach($backupArray as $userBalance) {
            if ($convertionPoints != $convertionPrice) {
                $convertedCredits = $userBalance['credits'] / $convertionPrice;
                $convertedCredits = round($convertedCredits * $convertionPoints);
            } else {
                $convertedCredits = $userBalance['credits'];
            }
            //move to credits
            update_user_meta($userBalance['user_id'], WPDEPOSIT_NAME.$userModel::USER_AMOUNT, 0);
            update_user_meta($userBalance['user_id'], WPDEPOSIT_NAME.$userModel::REWARDS_AMOUNT, 0);
            //remove points
            update_user_meta($userBalance['user_id'], WPDEPOSIT_NAME.$userModel::USER_POINTS, $convertedCredits);
            //echo '(credits: ' . $userBalance['credits'] . ' - to: ' . $convertedCredits . ')';
        }
        $response = array('success' => true, 'message' => 'Settings updated');
        $wpelements->jsonResponseOutput(json_encode($response));
    }

}//end of class