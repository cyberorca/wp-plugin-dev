<?php

require_once WPDEPOSIT_PATH . '/controllers/abstract.php';


class Siapbayar extends wpdepositAbstractController {

    private static $PREFIX_REQ = array(
        'LS'=>'leasing_form_member',
        'PL'=>'pln_form_member',
        'PLNT'=>'pln_token_form_member',
	'PLNNON'=>'pln_nontaglist_form_member',
        'KK'=>'kartu_kredit_form_member',
        'HP'=>'pulsa_pascabayar_form_member',
        'AS'=>'asuransi_form_member',
        'TK'=>'tv_kabel_form_member',
        'TELEPON'=>'telepon_form_member',
        'SPEEDY'=>'speedy_form_member',
        'PA'=>'pdam_form_member',
		'CE'=>'cek_saldo_form_member',
        'TB'=>'pulsa_form_member',
        'TM'=>'pulsa_form_member',
        'SG'=>'pulsa_form_member',
        'ASBPJSKS'=>'bpjs_kesehatan_form_member');
	
	private static $ERROR_CODE = array(
		0	=> 'Sukses',
		10	=> 'Member tidak dikenal.',
		11	=> 'PIN salah.',
		12	=> 'Member tidak aktif.',
		13	=> 'IP tidak terdaftar. Kejadian ini akan dicatat sebagai insiden keamanan.',
		20	=> 'Layanan sedang tidak aktif atau tidak dikenali.',
		21	=> 'Data tidak ditemukan.',
		30	=> 'Layanan tidak tersedia.',
		31	=> 'Layanan tidak tersedia untuk member ini.',
		32	=> 'Saldo tidak cukup.',
		33	=> 'Layanan sedang tidak aktif.',
		34	=> 'Layanan sedang tidak aktif.',
		35	=> 'Data inquiry tidak ditemukan.',
		36	=> 'Nominal bayar tidak mencukupi.',
		68	=> 'Transaksi sedang diproses.',
		90	=> 'Layanan sedang tidak aktif.',
		'' 	=> 'Transaksi pending (sedang dalam proses).',
	);
    
	const ID_MEMBER = 'R0330';
    const PIN_MEMBER = '46199754';
    const API_URL = 'https://api.siapbayar.com/v1/json';

    private static $request = array(
                    'CE'=>
                    '{
                      "opcode": "status",
                      "uid": "self::ID_MEMBER",
                      "pin": "PIN_MEMBER",
                      "refca": "REF_CA"
                    }',
                    'pulsa'=> 
                    
                    '{
                      "opcode": "pulsa",
                      "uid": "self::ID_MEMBER",
                      "pin": "PIN_MEMBER",
                      "productcode": "PRODUCT_CODE",
                      "nohp": "NO_HP",
                      "refca": "REF_CA"
                    }',
                    'voucherGames'=>
                    '{
                      "opcode": "game",
                      "uid": "self::ID_MEMBER",
                      "pin": "PIN_MEMBER",
                      "productcode": "PRODUCT_CODE",
                      "nohp": "NO_HP",
                      "refca": "REF_CA"
                    }',
                    'PLNT' =>array( //pln token
                        'inquiry'=>
                            '{
                              "opcode": "inquiry",
                              "uid": "self::ID_MEMBER",
                              "pin": "PIN_MEMBER",
                              "productcode": "PRODUCT_CODE",
                              "accno": "ACCOUNT_NO",
                              "nohp": "NO_HP",
                              "refca": "REF_CA"
                            }',
                        'payment'=>
                            '{
                              "opcode": "payment",
                              "uid": "ID_MEMBER",
                              "pin": "PIN_MEMBER",
                              "productcode": "PRODUCT_CODE",
                              "accno": "ACCOUNT_NO",
                              "nohp": "NO_HP",
                              "nominal": "NOMINAL",
                              "refca": "REF_CA",
                              "refsbinq": "REF_SB_INQUIRY"
                            }'
                    ),
                    'PL'=>array( //pln pascabayar
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }',
                    ),
                    'PLNPAC'=>array( //pln pascabayar
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }',
                    ),
                    'PLNNON'=>array( //pln non
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'Telkom'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'TELEPON'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
			'SPEEDY'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'PA'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'ASBPJSKS'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "billperiode": "BILL_PERIODE",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nohp": "NO_HP",
                          "nominal": "NOMINAL",
                          "billperiode": "BILL_PERIODE",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'AS'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'LS'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'KK'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    'TK'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "inquiry",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "refca": "REF_CA"
                        }',
                        'payment'=>
                        '{
                          "opcode": "payment",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "accno": "ACCOUNT_NO",
                          "nominal": "NOMINAL",
                          "refca": "REF_CA",
                          "refsbinq": "REF_SB_INQUIRY"
                        }'
                    ),
                    
                    'TB'=>array(
                        'inquiry'=>
                        '{
                          "opcode": "pulsa",
                          "uid": "ID_MEMBER",
                          "pin": "PIN_MEMBER",
                          "productcode": "PRODUCT_CODE",
                          "nohp": "NO_HP",
                          "refca": "REF_CA"
                        }',
                        
                    )
        

);
  
    
    public function __construct(){
        parent::__construct();
    }

    private static function create_request($data){
        foreach($data as $k=>$v){
            $data[$k] = self::sanitize($v);
        }
        $data_string = json_encode($data);

        return $data_string;
    }

    private static function sanitize($data){
		return htmlentities(trim($data), ENT_QUOTES, 'UTF-8');
	}

    public static function get_request(){
        $req = self::$request;
        $jsonReq = $req['PLNPraBayar']['inquiry'];
        $sign = array('/ID_MEMBER/','/PIN_MEMBER/','/NO_HP/','/REF_CA/');
        $value = array(self::ID_MEMBER,self::PIN,'081803848515','123112312');
        $formatInq = preg_replace($sign,$value,$jsonReq);
       // $json = json_decode($formatInq,true);
        echo $formatInq;
        print_r($req['PLNPraBayar']);
       // print_r($json);
    }

    public static function send_json_data($data){
	
        $data_string = self::create_request( $data );

        $ch = curl_init( self::API_URL );
        
        curl_setopt( $ch, CURLOPT_CUSTOMREQUEST, "POST" );
        
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $data_string );
        
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true);
        
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data_string))
        );
        
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);

        //execute post
        $result = curl_exec($ch);

        //close connection
        curl_close($ch);
	
        return $result;
    }

    /**
     * output : string
     * */
    public static function get_page_by_prefix( $request_code, $post, $idpel ){
    
        if ( empty( $request_code ) ){
        
        	return '';
        	
        } 
        
        	
        $raw_response = array();
        
        $idx = self::sanitize($request_code);
        
        $req = self::$request;
        
        $ret = array();
        
        $pref = '';
        
        if( in_array( $idx, array( 'TELEPON', 'SPEEDY', 'ASBPJSKS', 'PLNT', 'PULSA', 'PDAM') ) ){
            
            $pref = $idx;
        
        }else{
        
            $pref = substr( $idx, 0, 2 );
        
        }

        $ret['page'] = self::$PREFIX_REQ[$pref];
        
        
        $dtReq = array();
        
        if(isset($_POST['submit_payment'])){
    		$dtReq = json_decode( $req[$pref]['payment'] ,true );
        }else{
        	$dtReq = json_decode( $req[$pref]['inquiry'] ,true );
        }
        
        if($dtReq == NULL) $dtReq = array();
        
        foreach( $dtReq as $k=>$v ){
        
            if( isset( $post[$k] ) ) {
                
                $dtReq[$k] = $post[$k];
                
            }
        }
		 	
        $dtReq['uid'] = self::ID_MEMBER;
        
        $dtReq['pin'] = self::PIN_MEMBER;
        
        
        $dtReq['refca'] = "inq_{$idx}_".$idpel.date('dmYHis');

        if( isset( $post['submit_inquiry'] ) || isset( $post['submit_payment'] ) ){
        
            	$json_response = self::send_json_data($dtReq);
            	
		$raw_response = json_decode($json_response,true);
		
	
		
		
		if( isset( $raw_response['rc'] ) ){
		
			$raw_response['response_msg'] = self::get_error_code(intval($raw_response['rc']));
			
		}
			
            $ret['response'] = $raw_response;
            
        }
        
        
        
        return $ret;
    }
	
    private static function get_error_code($error_code){
    
	return ( isset( self::$ERROR_CODE[$error_code] ) ) ? self::$ERROR_CODE[$error_code] : false; 
	
    }

}
