<?php
require_once WPDEPOSIT_PATH . '/controllers/abstract.php';
require_once WPDEPOSIT_PATH . '/models/point_options.php';

/**
 * Point options controller
 */
class PointOptionsController extends wpdepositAbstractController {

    /**
     * @var WP_elements 
     */
    protected $_wpelements = null;

    public function __construct() {
        parent::__construct();
        $this->_wpelements = new WP_elements();
    }
    
    /**
     * Show a overview with payment options
     */
    public function index() {
        $model = new PointOptionsModel();
        $paymentModel = new PaymentOptionsModel();
        $paymentOptions = $paymentModel->getOverview();
        $depositModel = new DepositOptionsModel();
        $deposits = $depositModel->getAll(1);
        $depositsCount = count($deposits);
        include WPDEPOSIT_PATH . '/views/points/index.php';
    }
    
    public function updateSettings() {
        try {
            do_action('wpds_update_points_settings');
            $model = new PointOptionsModel();
            if(!$model->updateSettings()) {
                throw new Exception(__('Error while saving the money settings. Please check your input again.', WPDEPOSIT_NAME));
            }
            $response = json_encode( array('success' => true, 'message' => __('Settings updated', WPDEPOSIT_NAME)));
            
        } catch (Exception $e) {
            $response = json_encode( array('success' => false, 'message' => $e->getMessage()));
        }
        $this->_wpelements->jsonResponseOutput($response);
    }

}//end of class pointOptionsController