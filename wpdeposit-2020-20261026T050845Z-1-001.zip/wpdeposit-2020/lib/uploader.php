<?php

if (!class_exists('Uploader')) {

    class Uploader
    {

            /**
             * function to upload images
             *
             * @return void
             * @author Christophe Debruel
             **/
            public function upload_image($fileConfig)
            {
                    $files = $fileConfig['files'];
                    $name = $fileConfig['fileName'];
                    $upload_dir = $fileConfig['uploadPath'];
                    $allowedTypes = $fileConfig['allowedFiles'];
                    $size = $fileConfig['maxSize'];

                    if(isset($files) && !empty($files)):

                    $errors = FALSE;

                    $filename = $files[$name]['name'];
                    $rand = time() . '-' . rand(111,999) . '-';
                    $filetmp = $files[$name]['tmp_name'];
                    $filetype = $files[$name]['type'];
                    $filesize = $files[$name]['size'];

                    list($width, $height, $type, $attr) = getimagesize($filetmp);

                    if($width > $fileConfig['maxWidth'] || $height > $fileConfig['maxHeight']):
                            throw new exception("Your image is to large. The allowed maximum size is " . $fileConfig['maxWidth'] . "*" . $fileConfig['maxHeight']);
                    endif;

                    $path = realpath($upload_dir)."/".$rand.$filename;

                    $allowedTypes = explode("|", $allowedTypes);

                            $allowed = false;

                            foreach($allowedTypes as $types):
                                    if($filetype == "image/".$types):
                                            $allowed = true;
                                    endif;
                            endforeach;

                            //if the submitted file is larger then the allowed size, return false
                            if($filesize > $size):
                                    throw new exception("Your image is to big.");
                            endif;

                            if($allowed == true):
                                    if(move_uploaded_file($filetmp,$path)):
                                            $image = explode('/source/', $path);
                                            $image = $image[1];
                                            return $image;
                                    else:
                                            return false;
                                    endif;
                            else:
                                    return false;
                            endif;

                    endif;//end of if files exist and is not empty

        }//end of upload_image()


            /**
             * function to upload zip files
             *
             * @return void
             * @author Christophe Debruel
             **/
            public function upload_zip($fileConfig)
            {
                    $files = $fileConfig['files'];
                    $name = $fileConfig['fileName'];
                    $upload_dir = $fileConfig['uploadPath'];
                    $allowedTypes = $fileConfig['allowedFiles'];
                    $size = $fileConfig['maxSize'];

                    if(isset($files) && !empty($files)):

                    $errors = FALSE;

                    $filename = $files[$name]['name'];
                    $rand = time() . '-' . rand(111,999) . '-';
                    $filetmp = $files[$name]['tmp_name'];
                    $filetype = $files[$name]['type'];
                    $filesize = $files[$name]['size'];

                    $path = $upload_dir.$rand.$filename;

                    $allowedTypes = explode("|", $allowedTypes);

                            $allowed = false;

                            foreach($allowedTypes as $types):
                                    if($filetype == "application/".$types):
                                            $allowed = true;
                                    endif;
                            endforeach;

                            if($allowed == true):
                                    if(move_uploaded_file($filetmp,$path)):
                                            $zip = explode('/source/', $path);
                                            $zip = $zip[1];
                                            return $zip;
                                    else:
                                            return false;
                                    endif;
                            else:
                                    return false;
                            endif;

                    endif;//end of if files exist and is not empty

        }//end of upload_zip()


            /**
             * function to upload batch files containing images
             * Modified version of jeffrey way's zip extract tutorial
             *
             * @return void
             * @author Christophe Debruel
             **/
            public function upload_batch_images($fileConfig)
            {
                    $files = $fileConfig['files'];
                    $name = $fileConfig['fileName'];
                    $upload_dir = $fileConfig['uploadPath'];
                    $allowedTypes = $fileConfig['allowedFiles'];
                    $allowedImgTypes = $fileConfig['allowedImgFiles'];
                    $size = $fileConfig['maxSize'];

                    if(isset($files) && !empty($files)):

                    $errors = FALSE;

                    $filename = $files[$name]['name'];
                    $rand = time() . '-' . rand(111,999) . '-';
                    $filetmp = $files[$name]['tmp_name'];
                    $filetype = $files[$name]['type'];
                    $filesize = $files[$name]['size'];
                    $imgDir = $upload_dir."images-".time();

                    $path = $upload_dir.$rand.$filename;

                    $allowedTypes = explode("|", $allowedTypes);

                            $allowed = false;

                            foreach($allowedTypes as $types):
                                    if($filetype == "application/".$types):
                                            $allowed = true;
                                    endif;
                            endforeach;

                            if($allowed == true):
                                    if(mkdir($imgDir)):
                                            if(move_uploaded_file($filetmp,$path)):
                                                    if(self::openZip($path, $imgDir, $allowedImgTypes)):
                                                            @unlink($path);
                                                            $imgDir = explode('/source/', $imgDir);
                                                            $imgDir = $imgDir[1];
                                                            return $imgDir;
                                                    endif;
                                            else:
                                                    return false;
                                            endif;
                                    endif;
                            else:
                                    return false;
                            endif;

                    endif;//end of if files exist and is not empty
            }



            /**
             * function to extract a zip file on a server
             *
             * Modified version of jeffrey way's zip extract tutorial
             * @return void
             * @author Christophe Debruel
             **/
            public function openZip($file_to_open, $zip_target, $allowedTypes) 
            {
                    $zip = new ZipArchive();
                    if ($zip->open($file_to_open) === true):
                            $allowedTypes = explode("|", $allowedTypes);
                            $extract = array();
                            for($i = 0; $i < $zip->numFiles; $i++) {
                            $filename = $zip->getNameIndex($i);
                            $fileinfo = pathinfo($filename);
                                    foreach($allowedTypes as $types):
                                            if(!empty($fileinfo['extension']) && $fileinfo['extension'] == $types):
                                                    //get rid of annoying mac hidden files!!!!!!!!
                                                    if (!preg_match('/\.\_.*/', $fileinfo['filename'])) {
                                                            $extract[] = $fileinfo['filename'] . '.' . $fileinfo['extension'];
                                                    }
                                            endif;
                                    endforeach;
                        }
                            $zip->extractTo($zip_target, $extract);
                            $zip->close();
                            return true;
                    else:
                            return false;
                    endif;
            }


    }//end of uploader class

}